package com.example;

import java.util.List;

import org.bson.Document;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TablaControlView {
    private final PanelController panelController;
    private final DocumentoService documentoService;

    public TablaControlView(PanelController panelController) {
        this.panelController = panelController;
        this.documentoService = new DocumentoService();
    }

    public void mostrar() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("📋 Centro de Control de Documentos");
        
        // Header moderno con título
        Label lblTitulo = new Label("Centro de Control de Documentos");
        lblTitulo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 32px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 20 0; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 2, 0, 0, 1);"
        );
        
        Label lblSubtitulo = new Label("Gestione todos sus documentos de manera eficiente y segura");
        lblSubtitulo.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 16px; " +
            "-fx-text-fill: #7f8c8d; " +
            "-fx-padding: 0 0 30 0;"
        );
        
        // Botones modernos con iconos y efectos
        Button btnRegistrar = new Button("📄 Registrar Documento");
        btnRegistrar.setPrefWidth(320);
        btnRegistrar.setPrefHeight(80);
        btnRegistrar.setStyle(
            "-fx-background-color: linear-gradient(to right, #27ae60, #2ecc71); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 15; " +
            "-fx-border-radius: 15; " +
            "-fx-padding: 20 30; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        Button btnVer = new Button("📊 Ver Documentos Registrados");
        btnVer.setPrefWidth(320);
        btnVer.setPrefHeight(80);
        btnVer.setStyle(
            "-fx-background-color: linear-gradient(to right, #3498db, #5dade2); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 15; " +
            "-fx-border-radius: 15; " +
            "-fx-padding: 20 30; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        // Efectos hover para los botones
        addModernHoverEffect(btnRegistrar, 
            "linear-gradient(to right, #27ae60, #2ecc71)", 
            "linear-gradient(to right, #2ecc71, #58d68d)");
        addModernHoverEffect(btnVer, 
            "linear-gradient(to right, #3498db, #5dade2)", 
            "linear-gradient(to right, #5dade2, #85c1e9)");
        
        // Contenedor principal moderno
        VBox headerContainer = new VBox(5);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.getChildren().addAll(lblTitulo, lblSubtitulo);
        
        VBox buttonContainer = new VBox(25);
        buttonContainer.setAlignment(Pos.CENTER);
        buttonContainer.getChildren().addAll(btnRegistrar, btnVer);
        
        VBox mainContainer = new VBox(40);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPrefSize(500, 400);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-padding: 40 50; " +
            "-fx-background-radius: 20; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 15, 0, 0, 5);"
        );
        mainContainer.getChildren().addAll(headerContainer, buttonContainer);
        
        // Contenedor de fondo
        javafx.scene.layout.StackPane backgroundPane = new javafx.scene.layout.StackPane();
        backgroundPane.setStyle("-fx-background-color: linear-gradient(135deg, #667eea 0%, #764ba2 100%);");
        backgroundPane.getChildren().add(mainContainer);
        
        Scene scene = new Scene(backgroundPane, 600, 500);
        tablaStage.setScene(scene);
        tablaStage.show();

        btnRegistrar.setOnAction(_ -> {
            tablaStage.close();
            panelController.mostrarFormularioRegistro();
        });
        
        btnVer.setOnAction(_ -> {
            tablaStage.close();
            mostrarDocumentosRegistrados();
        });
        
        // Cerrar conexión cuando se cierre la ventana
        tablaStage.setOnCloseRequest(e -> cerrarConexion());
    }

    public void mostrarDocumentosRegistrados() {
        Stage docsStage = new Stage();
        docsStage.setTitle("📊 Documentos Registrados - Vista Completa");
        
        // Header moderno
        Label lblTitulo = new Label("📊 Documentos Registrados");
        lblTitulo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 28px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 20 0 10 0; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 2, 0, 0, 1);"
        );
        
        Label lblSubtitulo = new Label("Gestione y visualice todos sus documentos registrados");
        lblSubtitulo.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-text-fill: #7f8c8d; " +
            "-fx-padding: 0 0 20 0;"
        );
        
        // Crear la tabla con estilo moderno
        TableView<DocumentoTableRow> table = new TableView<>();
        table.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        table.setStyle(
            "-fx-background-color: white; " +
            "-fx-border-color: #e0e0e0; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 10; " +
            "-fx-background-radius: 10; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 8, 0, 0, 2);"
        );

        // Configurar columnas con estilo moderno
        TableColumn<DocumentoTableRow, String> colVersion = new TableColumn<>("📋 Versión");
        colVersion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getVersion()));
        colVersion.setPrefWidth(100);
        colVersion.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");

        TableColumn<DocumentoTableRow, String> colCodigo = new TableColumn<>("🔖 Código");
        colCodigo.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCodigoDoc()));
        colCodigo.setPrefWidth(120);
        colCodigo.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");
        
        TableColumn<DocumentoTableRow, String> colUsuario = new TableColumn<>("👤 Usuario");
        colUsuario.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getUsuario()));
        colUsuario.setPrefWidth(150);
        colUsuario.setStyle("-fx-alignment: CENTER;");
        
        TableColumn<DocumentoTableRow, String> colnombreDoc = new TableColumn<>("📄 Nombre del Documento");
        colnombreDoc.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNombreDoc()));
        colnombreDoc.setPrefWidth(200);
        
        TableColumn<DocumentoTableRow, String> colFechaEmision = new TableColumn<>("📅 Fecha de Emisión");
        colFechaEmision.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaEmision()));
        colFechaEmision.setPrefWidth(140);
        colFechaEmision.setStyle("-fx-alignment: CENTER;");
        
        TableColumn<DocumentoTableRow, String> colFechaVencimiento = new TableColumn<>("⏰ Fecha de Vencimiento");
        colFechaVencimiento.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaVencimiento()));
        colFechaVencimiento.setPrefWidth(160);
        colFechaVencimiento.setStyle("-fx-alignment: CENTER;");
        
        TableColumn<DocumentoTableRow, String> colFechaRenovacion = new TableColumn<>("🔄 Próxima Renovación");
        colFechaRenovacion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaProximaRenovacion()));
        colFechaRenovacion.setPrefWidth(160);
        colFechaRenovacion.setStyle("-fx-alignment: CENTER;");

        TableColumn<DocumentoTableRow, String> colMotivodeModificacion = new TableColumn<>("📝 Motivo de Modificación");
        colMotivodeModificacion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMotivodeModificacion()));
        colMotivodeModificacion.setPrefWidth(220);
        
        TableColumn<DocumentoTableRow, String> colArchivos = new TableColumn<>("📎 Archivos");
        colArchivos.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCantidadArchivos()));
        colArchivos.setPrefWidth(80);
        colArchivos.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");

        table.getColumns().addAll(colVersion, colCodigo, colUsuario, colnombreDoc, colFechaEmision, colFechaVencimiento, colFechaRenovacion, colMotivodeModificacion, colArchivos);

        // Crear menú contextual moderno
        ContextMenu contextMenu = new ContextMenu();
        MenuItem menuGestionarArchivos = new MenuItem("📁 Gestionar archivos");
        MenuItem menuEliminarDocumento = new MenuItem("🗑️ Eliminar documento");
        
        menuGestionarArchivos.setStyle("-fx-font-family: 'Segoe UI'; -fx-font-size: 14px;");
        menuEliminarDocumento.setStyle("-fx-font-family: 'Segoe UI'; -fx-font-size: 14px;");
        
        menuGestionarArchivos.setOnAction(_ -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                ArchivoManagerDialog archivoManager = new ArchivoManagerDialog(docsStage, selected.getCodigoDoc());
                archivoManager.mostrar();
            }
        });
        
        menuEliminarDocumento.setOnAction(_ -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarDocumento(selected.getCodigoDoc(), table);
            }
        });
        
        contextMenu.getItems().addAll(menuGestionarArchivos, menuEliminarDocumento);
        table.setContextMenu(contextMenu);
        
        // Cargar datos
        cargarDocumentos(table);
        
        // Botones modernos con iconos
        Button btnGestionarArchivos = new Button("📁 Gestionar Archivos");
        btnGestionarArchivos.setPrefWidth(180);
        btnGestionarArchivos.setPrefHeight(45);
        btnGestionarArchivos.setStyle(
            "-fx-background-color: linear-gradient(to right, #f39c12, #f7b731); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnGestionarArchivos.setOnAction(_ -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                ArchivoManagerDialog archivoManager = new ArchivoManagerDialog(docsStage, selected.getCodigoDoc());
                archivoManager.mostrar();
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un documento para gestionar sus archivos.", false, null);
            }
        });
        
        Button btnActualizar = new Button("🔄 Actualizar");
        btnActualizar.setPrefWidth(130);
        btnActualizar.setPrefHeight(45);
        btnActualizar.setStyle(
            "-fx-background-color: linear-gradient(to right, #3498db, #5dade2); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnActualizar.setOnAction(_ -> cargarDocumentos(table));
        
        Button btnEliminar = new Button("🗑️ Eliminar Documento");
        btnEliminar.setPrefWidth(180);
        btnEliminar.setPrefHeight(45);
        btnEliminar.setStyle(
            "-fx-background-color: linear-gradient(to right, #e74c3c, #ec7063); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnEliminar.setOnAction(_ -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarDocumento(selected.getCodigoDoc(), table);
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un documento para eliminar.", false, null);
            }
        });
        
        Button btnCerrar = new Button("❌ Cerrar");
        btnCerrar.setPrefWidth(110);
        btnCerrar.setPrefHeight(45);
        btnCerrar.setStyle(
            "-fx-background-color: linear-gradient(to right, #95a5a6, #bdc3c7); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnCerrar.setOnAction(_ -> docsStage.close());
        
        // Aplicar efectos hover a los botones
        addTableButtonHoverEffect(btnGestionarArchivos, "linear-gradient(to right, #f39c12, #f7b731)", "linear-gradient(to right, #f7b731, #ffd93d)");
        addTableButtonHoverEffect(btnActualizar, "linear-gradient(to right, #3498db, #5dade2)", "linear-gradient(to right, #5dade2, #85c1e9)");
        addTableButtonHoverEffect(btnEliminar, "linear-gradient(to right, #e74c3c, #ec7063)", "linear-gradient(to right, #ec7063, #f1948a)");
        addTableButtonHoverEffect(btnCerrar, "linear-gradient(to right, #95a5a6, #bdc3c7)", "linear-gradient(to right, #bdc3c7, #d5dbdb)");
        
        HBox hboxBotones = new HBox(15, btnGestionarArchivos, btnActualizar, btnEliminar, btnCerrar);
        hboxBotones.setAlignment(Pos.CENTER);
        hboxBotones.setStyle("-fx-padding: 20 0;");
        
        // Layout principal moderno
        VBox headerContainer = new VBox(5);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.getChildren().addAll(lblTitulo, lblSubtitulo);
        
        VBox mainContainer = new VBox(20);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-padding: 25; " +
            "-fx-background-radius: 15; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 12, 0, 0, 4);"
        );
        mainContainer.getChildren().addAll(headerContainer, table, hboxBotones);
        
        // Contenedor de fondo
        javafx.scene.layout.StackPane backgroundPane = new javafx.scene.layout.StackPane();
        backgroundPane.setStyle("-fx-background-color: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -fx-padding: 20;");
        backgroundPane.getChildren().add(mainContainer);
        
        Scene scene = new Scene(backgroundPane, 1450, 750);
        docsStage.setScene(scene);
        docsStage.show();
        
        // Cerrar conexión cuando se cierre la ventana
        docsStage.setOnCloseRequest(_ -> cerrarConexion());
    }
    
    private void cargarDocumentos(TableView<DocumentoTableRow> table) {
        try {
            List<Document> documentos = documentoService.obtenerTodosLosDocumentos();
            ObservableList<DocumentoTableRow> rows = FXCollections.observableArrayList();
            
            for (Document doc : documentos) {
                DocumentoTableRow row = new DocumentoTableRow(
                    obtenerStringSeguro(doc, "version"),
                    obtenerStringSeguro(doc, "codigo"),
                    obtenerStringSeguro(doc, "usuario"),
                    obtenerStringSeguro(doc, "nombreDocumento"),
                    obtenerFechaComoString(doc, "fechaEmision"),
                    obtenerFechaComoString(doc, "fechaVencimiento"),
                    obtenerFechaComoString(doc, "fechaProximaRenovacion"),
                    obtenerStringSeguro(doc, "motivodeModificacion"),
                    obtenerCantidadArchivos(doc)
                );
                rows.add(row);
            }
            
            table.setItems(rows);
        } catch (Exception e) {
            DialogUtils.mostrarAviso(null, "Error al cargar los documentos: " + e.getMessage(), false, null);
            e.printStackTrace();
        }
    }
    
    private String obtenerStringSeguro(Document doc, String campo) {
        Object valor = doc.get(campo);
        return valor != null ? valor.toString() : "";
    }
    
    private String obtenerFechaComoString(Document doc, String campo) {
        Object fecha = doc.get(campo);
        if (fecha == null) {
            return "";
        }
        // Permitir 'nv' o 'NV' como 'No vence' solo para vencimiento y próxima renovación
        if (fecha instanceof String) {
            String fechaStr = ((String) fecha).trim();
            if (fechaStr.equalsIgnoreCase("nv")) {
                return "No Vence";
            }
        }
        // Si es una fecha de Java (Date)
        if (fecha instanceof java.util.Date) {
            java.util.Date date = (java.util.Date) fecha;
            java.time.LocalDate localDate = date.toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();
            return localDate.toString();
        }
        // Si es un LocalDate
        if (fecha instanceof java.time.LocalDate) {
            return fecha.toString();
        }
        // Si es un string
        return fecha.toString();
    }
    
    private String obtenerCantidadArchivos(Document documento) {
        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        if (archivos != null) {
            return String.valueOf(archivos.size());
        }
        return "0";
    }
    
    private void eliminarDocumento(String codigoDoc, TableView<DocumentoTableRow> table) {
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Confirmar eliminación");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText("¿Estás seguro de que deseas eliminar el documento con código '" + codigoDoc + "'?\n" +
                                   "Esta acción también eliminará todos los archivos asociados.");
        
        if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            try {
                if (documentoService.eliminarDocumento(codigoDoc)) {
                    cargarDocumentos(table); // Recargar la tabla
                    DialogUtils.mostrarAviso(null, "Documento eliminado exitosamente.", true, null);
                } else {
                    DialogUtils.mostrarAviso(null, "Error al eliminar el documento.", false, null);
                }
            } catch (Exception e) {
                DialogUtils.mostrarAviso(null, "Error al eliminar el documento: " + e.getMessage(), false, null);
                e.printStackTrace();
            }
        }
    }
    
    public void cerrarConexion() {
        if (documentoService != null) {
            documentoService.cerrarConexion();
        }
    }
    
    // Método estático para mantener compatibilidad con PanelController
    public static void mostrarDocumentosRegistradosEstatico() {
        TablaControlView tablaControlView = new TablaControlView(null);
        tablaControlView.mostrarDocumentosRegistrados();
    }

    // Método auxiliar para efectos hover modernos
    private void addModernHoverEffect(Button button, String normalStyle, String hoverStyle) {
        String baseStyle = 
            "-fx-text-fill: white; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 15; " +
            "-fx-border-radius: 15; " +
            "-fx-padding: 20 30; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; ";

        button.setOnMouseEntered(_ -> button.setStyle(
            "-fx-background-color: " + hoverStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 6); " +
            "-fx-scale-x: 1.02; -fx-scale-y: 1.02;"
        ));

        button.setOnMouseExited(_ -> button.setStyle(
            "-fx-background-color: " + normalStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4);"
        ));
    }

    // Método auxiliar para efectos hover en botones de tabla
    private void addTableButtonHoverEffect(Button button, String normalStyle, String hoverStyle) {
        String baseStyle = 
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; ";

        button.setOnMouseEntered(_ -> button.setStyle(
            "-fx-background-color: " + hoverStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3); " +
            "-fx-scale-x: 1.05; -fx-scale-y: 1.05;"
        ));

        button.setOnMouseExited(_ -> button.setStyle(
            "-fx-background-color: " + normalStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2);"
        ));
    }

        // Clase interna para representar una fila de la tabla
    public static class DocumentoTableRow {
        
        private final String version;
        private final String codigoDoc;
        private final String usuario;
        private final String nombreDoc;
        private final String fechaEmision;
        private final String fechaVencimiento;
        private final String fechaProximaRenovacion;
        private final String motivodeModificacion;
        private final String cantidadArchivos;

        public DocumentoTableRow(String version, String codigoDoc, String usuario, String nombreDoc, String fechaEmision, 
                               String fechaVencimiento, String fechaProximaRenovacion, String cantidadArchivos, String motivodeModificacion) {
            this.version = version;
            this.codigoDoc = codigoDoc;
            this.usuario = usuario;
            this.nombreDoc = nombreDoc;
            this.fechaEmision = fechaEmision;
            this.fechaVencimiento = fechaVencimiento;
            this.fechaProximaRenovacion = fechaProximaRenovacion;
            this.motivodeModificacion = motivodeModificacion;
            this.cantidadArchivos = cantidadArchivos;
        }

        public String getVersion() {
            return version;
        }

        public String getUsuario() {
            return usuario;
        }
        
        public String getNombreDoc() { 
            return nombreDoc; 
        }
        
        public String getFechaEmision() { 
            return fechaEmision; 
        }
        
        public String getFechaVencimiento() { 
            return fechaVencimiento; 
        }
        
        public String getFechaProximaRenovacion() { 
            return fechaProximaRenovacion; 
        }
        
        public String getCantidadArchivos() { 
            return cantidadArchivos; 
        }

        public String getCodigoDoc() { 
            return codigoDoc;
        }

        public String getMotivodeModificacion() {
            return motivodeModificacion;
        }
    }
}