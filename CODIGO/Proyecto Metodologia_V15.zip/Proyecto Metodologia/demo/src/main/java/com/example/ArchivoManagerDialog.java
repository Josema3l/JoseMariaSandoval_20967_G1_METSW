package com.example;

import java.awt.Desktop;
import java.io.File;
import java.util.List;

import org.bson.Document; 
import org.bson.types.ObjectId;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ArchivoManagerDialog {
    private final Stage parentStage;
    private final DocumentoService documentoService;
    private final String codigoDocumento;
    private ListView<String> listViewArchivos;
    private Label infoLabel;
    private Button btnDescargar;
    private Button btnVerificar;
    private Button btnEliminar;
    private Button btnAbrir;

    public ArchivoManagerDialog(Stage parentStage, String codigoDocumento) {
        this.parentStage = parentStage;
        this.documentoService = new DocumentoService();
        this.codigoDocumento = codigoDocumento;
    }

    public void mostrar() {
        Stage archivoStage = new Stage();
        archivoStage.setTitle("📁 Gestión de Archivos - " + codigoDocumento);
        archivoStage.initModality(Modality.APPLICATION_MODAL);
        archivoStage.initOwner(parentStage);
        archivoStage.setWidth(800);
        archivoStage.setHeight(650);
        archivoStage.setResizable(true);

        // Obtener información del documento
        Document documento = documentoService.buscarDocumento(codigoDocumento);
        if (documento == null) {
            DialogUtils.showError("Documento no encontrado.");
            return;
        }

        // Container principal con gradiente moderno
        VBox mainContainer = new VBox();
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #f8f9fa, #e9ecef);
            """);

        // Header con título
        VBox headerBox = new VBox(10);
        headerBox.setPadding(new Insets(30, 30, 20, 30));
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2);");

        Label titulo = new Label("📁 Gestión de Archivos");
        titulo.setStyle("""
            -fx-font-size: 28px;
            -fx-font-weight: bold;
            -fx-text-fill: white;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.3), 2, 0, 1, 1);
            """);

        Label subtitulo = new Label("Documento: " + codigoDocumento);
        subtitulo.setStyle("""
            -fx-font-size: 16px;
            -fx-text-fill: rgba(255,255,255,0.9);
            """);

        infoLabel = new Label();
        infoLabel.setStyle("""
            -fx-font-size: 12px;
            -fx-text-fill: rgba(255,255,255,0.8);
            """);

        headerBox.getChildren().addAll(titulo, subtitulo, infoLabel);

        // Área de contenido principal
        VBox contentBox = new VBox(20);
        contentBox.setPadding(new Insets(30, 40, 30, 40));

        // Lista de archivos moderna
        Label lblArchivos = new Label("📋 Archivos Adjuntos");
        lblArchivos.setStyle("""
            -fx-font-size: 18px;
            -fx-font-weight: bold;
            -fx-text-fill: #2c3e50;
            """);

        listViewArchivos = new ListView<>();
        listViewArchivos.setPrefHeight(250);
        listViewArchivos.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 3, 0, 0, 1);
            -fx-font-size: 14px;
            """);

        // Listener para selección en lista
        listViewArchivos.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            updateButtonStates();
        });

        // Grid de botones modernos
        GridPane buttonGrid = new GridPane();
        buttonGrid.setHgap(15);
        buttonGrid.setVgap(15);
        buttonGrid.setAlignment(Pos.CENTER);

        // Configurar columnas
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHalignment(HPos.CENTER);
        col1.setPrefWidth(180);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setHalignment(HPos.CENTER);
        col2.setPrefWidth(180);
        ColumnConstraints col3 = new ColumnConstraints();
        col3.setHalignment(HPos.CENTER);
        col3.setPrefWidth(180);
        buttonGrid.getColumnConstraints().addAll(col1, col2, col3);

        // Estilo común para botones
        String buttonStyle = """
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 20;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            -fx-pref-width: 160;
            -fx-pref-height: 40;
            """;

        // Botón Agregar
        Button btnAgregar = new Button("📎 Agregar Archivo");
        btnAgregar.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #28a745, #20a144);");
        btnAgregar.setOnMouseEntered(e -> btnAgregar.setStyle(btnAgregar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnAgregar.setOnMouseExited(e -> btnAgregar.setStyle(btnAgregar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnAgregar.setOnAction(e -> agregarArchivo());

        // Botón Descargar
        btnDescargar = new Button("💾 Descargar");
        btnDescargar.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #007bff, #0056b3);");
        btnDescargar.setOnMouseEntered(e -> btnDescargar.setStyle(btnDescargar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnDescargar.setOnMouseExited(e -> btnDescargar.setStyle(btnDescargar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnDescargar.setOnAction(e -> descargarArchivo(documento));

        // Botón Verificar
        btnVerificar = new Button("🔍 Verificar");
        btnVerificar.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #17a2b8, #138496);");
        btnVerificar.setOnMouseEntered(e -> btnVerificar.setStyle(btnVerificar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnVerificar.setOnMouseExited(e -> btnVerificar.setStyle(btnVerificar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnVerificar.setOnAction(e -> verificarArchivo(documento));

        // Botón Abrir
        btnAbrir = new Button("🚀 Abrir");
        btnAbrir.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #fd7e14, #e8590c);");
        btnAbrir.setOnMouseEntered(e -> btnAbrir.setStyle(btnAbrir.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnAbrir.setOnMouseExited(e -> btnAbrir.setStyle(btnAbrir.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnAbrir.setOnAction(e -> abrirArchivo(documento));

        // Botón Eliminar
        btnEliminar = new Button("🗑️ Eliminar");
        btnEliminar.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #dc3545, #c82333);");
        btnEliminar.setOnMouseEntered(e -> btnEliminar.setStyle(btnEliminar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnEliminar.setOnMouseExited(e -> btnEliminar.setStyle(btnEliminar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnEliminar.setOnAction(e -> eliminarArchivo(documento));

        // Botón Actualizar
        Button btnActualizar = new Button("🔄 Actualizar");
        btnActualizar.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #6f42c1, #5a32a3);");
        btnActualizar.setOnMouseEntered(e -> btnActualizar.setStyle(btnActualizar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnActualizar.setOnMouseExited(e -> btnActualizar.setStyle(btnActualizar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnActualizar.setOnAction(e -> {
            Document docActualizado = documentoService.buscarDocumento(codigoDocumento);
            if (docActualizado != null) {
                actualizarListaArchivos(docActualizado);
            }
        });

        // Agregar botones al grid
        buttonGrid.add(btnAgregar, 0, 0);
        buttonGrid.add(btnDescargar, 1, 0);
        buttonGrid.add(btnVerificar, 2, 0);
        buttonGrid.add(btnAbrir, 0, 1);
        buttonGrid.add(btnEliminar, 1, 1);
        buttonGrid.add(btnActualizar, 2, 1);

        // Botón Cerrar centrado
        Button btnCerrar = new Button("❌ Cerrar");
        btnCerrar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #6c757d, #5a6268);
            -fx-text-fill: white;
            -fx-font-size: 16px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 30;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCerrar.setOnMouseEntered(e -> btnCerrar.setStyle(btnCerrar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCerrar.setOnMouseExited(e -> btnCerrar.setStyle(btnCerrar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnCerrar.setOnAction(e -> archivoStage.close());

        HBox closeBox = new HBox();
        closeBox.setAlignment(Pos.CENTER);
        closeBox.setPadding(new Insets(20, 0, 0, 0));
        closeBox.getChildren().add(btnCerrar);

        contentBox.getChildren().addAll(lblArchivos, listViewArchivos, buttonGrid, closeBox);

        // Ensamblar la interfaz
        mainContainer.getChildren().addAll(headerBox, contentBox);

        // Configurar escena
        Scene scene = new Scene(mainContainer, 800, 650);
        archivoStage.setScene(scene);

        // Cargar archivos iniciales
        actualizarListaArchivos(documento);
        updateButtonStates();

        archivoStage.setOnCloseRequest(e -> documentoService.cerrarConexion());
        archivoStage.show();
    }

    private void updateButtonStates() {
        boolean hasSelection = listViewArchivos.getSelectionModel().getSelectedItem() != null;
        btnDescargar.setDisable(!hasSelection);
        btnVerificar.setDisable(!hasSelection);
        btnEliminar.setDisable(!hasSelection);
        btnAbrir.setDisable(!hasSelection);
    }

    private void agregarArchivo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("📎 Seleccionar archivo para adjuntar");
        
        // Configurar filtros de archivos
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Documentos Excel", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp"),
            new FileChooser.ExtensionFilter("Archivos de texto", "*.txt", "*.rtf")
        );
        
        File archivoSeleccionado = fileChooser.showOpenDialog(parentStage);
        if (archivoSeleccionado != null) {
            // Verificar tamaño del archivo (límite de 50MB)
            if (archivoSeleccionado.length() > 50 * 1024 * 1024) {
                DialogUtils.showError("El archivo es demasiado grande. El tamaño máximo permitido es 50MB.");
                return;
            }
            
            // Mostrar indicador de progreso
            ProgressIndicator progressIndicator = new ProgressIndicator();
            progressIndicator.setPrefSize(30, 30);
            Label lblSubiendo = new Label("📤 Subiendo archivo...");
            lblSubiendo.setStyle("-fx-font-size: 14px; -fx-text-fill: #3498db; -fx-font-weight: bold;");
            
            HBox progressBox = new HBox(10, progressIndicator, lblSubiendo);
            progressBox.setAlignment(Pos.CENTER);
            
            // Agregar temporalmente el indicador
            VBox parent = (VBox) listViewArchivos.getParent();
            parent.getChildren().add(parent.getChildren().indexOf(listViewArchivos) + 1, progressBox);
            
            // Tarea asíncrona para subir archivo
            Task<Boolean> uploadTask = new Task<Boolean>() {
                @Override
                protected Boolean call() throws Exception {
                    return documentoService.agregarArchivoADocumento(codigoDocumento, archivoSeleccionado);
                }
                
                @Override
                protected void succeeded() {
                    Platform.runLater(() -> {
                        parent.getChildren().remove(progressBox);
                        if (getValue()) {
                            Document docActualizado = documentoService.buscarDocumento(codigoDocumento);
                            if (docActualizado != null) {
                                actualizarListaArchivos(docActualizado);
                            }
                            DialogUtils.showSuccess("✅ Archivo agregado exitosamente: " + archivoSeleccionado.getName());
                        } else {
                            DialogUtils.showError("❌ Error al agregar el archivo.");
                        }
                    });
                }
                
                @Override
                protected void failed() {
                    Platform.runLater(() -> {
                        parent.getChildren().remove(progressBox);
                        DialogUtils.showError("❌ Error al subir el archivo: " + getException().getMessage());
                    });
                }
            };
            
            Thread uploadThread = new Thread(uploadTask);
            uploadThread.setDaemon(true);
            uploadThread.start();
        }
    }
    private void actualizarListaArchivos(Document documento) {
        listViewArchivos.getItems().clear();
        
        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && !archivos.isEmpty()) {
            for (Document archivo : archivos) {
                String nombre = archivo.getString("nombreOriginal");
                Long tamaño = archivo.getLong("tamaño");
                String info = "📄 " + nombre + " (" + formatFileSize(tamaño) + ")";
                listViewArchivos.getItems().add(info);
            }
            infoLabel.setText("📊 Total de archivos: " + archivos.size());
        } else {
            infoLabel.setText("📊 No hay archivos adjuntos");
        }
    }

    private void descargarArchivo(Document documento) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.showError("Selecciona un archivo para descargar.");
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            ObjectId archivoId = archivo.getObjectId("archivoId");
            String nombreOriginal = archivo.getString("nombreOriginal");

            // Seleccionar carpeta de destino
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("📂 Seleccionar carpeta de destino");
            File carpetaDestino = directoryChooser.showDialog(parentStage);

            if (carpetaDestino != null) {
                String rutaDestino = carpetaDestino.getAbsolutePath() + File.separator + nombreOriginal;
                
                // Mostrar indicador de progreso
                ProgressIndicator progressIndicator = new ProgressIndicator();
                progressIndicator.setPrefSize(25, 25);
                Label lblDescargando = new Label("💾 Descargando archivo...");
                lblDescargando.setStyle("-fx-font-size: 12px; -fx-text-fill: #3498db; -fx-font-weight: bold;");
                
                HBox progressBox = new HBox(10, progressIndicator, lblDescargando);
                progressBox.setAlignment(Pos.CENTER);
                
                VBox parent = (VBox) listViewArchivos.getParent();
                parent.getChildren().add(parent.getChildren().indexOf(listViewArchivos) + 1, progressBox);
                
                // Tarea asíncrona para descargar
                Task<Boolean> downloadTask = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return documentoService.descargarArchivo(archivoId, rutaDestino);
                    }
                    
                    @Override
                    protected void succeeded() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            if (getValue()) {
                                DialogUtils.showSuccess("✅ Archivo descargado exitosamente en:\n" + rutaDestino);
                            } else {
                                DialogUtils.showError("❌ Error al descargar el archivo.");
                            }
                        });
                    }
                    
                    @Override
                    protected void failed() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            DialogUtils.showError("❌ Error al descargar el archivo: " + getException().getMessage());
                        });
                    }
                };
                
                Thread downloadThread = new Thread(downloadTask);
                downloadThread.setDaemon(true);
                downloadThread.start();
            }
        }
    }

    private void verificarArchivo(Document documento) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.showError("Selecciona un archivo para verificar.");
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            String nombre = archivo.getString("nombreOriginal");
            Long tamaño = archivo.getLong("tamaño");
            Object fechaSubida = archivo.get("fechaSubida");

            String info = String.format(
                "📄 Información del Archivo\n\n" +
                "📋 Nombre: %s\n" +
                "📏 Tamaño: %s\n" +
                "📅 Fecha de subida: %s\n" +
                "🔑 ID: %s",
                nombre,
                formatFileSize(tamaño),
                fechaSubida.toString(),
                archivo.getObjectId("archivoId").toString()
            );

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("🔍 Información del archivo");
            alert.setHeaderText("Detalles del archivo seleccionado");
            alert.setContentText(info);
            
            // Aplicar estilo moderno al diálogo
            alert.getDialogPane().setStyle("""
                -fx-background-color: #f8f9fa;
                -fx-font-family: 'Segoe UI';
                """);
            
            alert.showAndWait();
        }
    }

    private void eliminarArchivo(Document documento) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.showError("Selecciona un archivo para eliminar.");
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            String nombreArchivo = archivo.getString("nombreOriginal");
            
            Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmacion.setTitle("🗑️ Confirmar eliminación");
            confirmacion.setHeaderText("¿Eliminar archivo?");
            confirmacion.setContentText("¿Estás seguro de que deseas eliminar el archivo:\n\n📄 " + nombreArchivo + "\n\nEsta acción no se puede deshacer.");
            
            // Aplicar estilo moderno
            confirmacion.getDialogPane().setStyle("""
                -fx-background-color: #f8f9fa;
                -fx-font-family: 'Segoe UI';
                """);

            if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
                ObjectId archivoId = archivo.getObjectId("archivoId");

                // Mostrar indicador de progreso
                ProgressIndicator progressIndicator = new ProgressIndicator();
                progressIndicator.setPrefSize(25, 25);
                Label lblEliminando = new Label("🗑️ Eliminando archivo...");
                lblEliminando.setStyle("-fx-font-size: 12px; -fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                
                HBox progressBox = new HBox(10, progressIndicator, lblEliminando);
                progressBox.setAlignment(Pos.CENTER);
                
                VBox parent = (VBox) listViewArchivos.getParent();
                parent.getChildren().add(parent.getChildren().indexOf(listViewArchivos) + 1, progressBox);
                
                // Tarea asíncrona para eliminar
                Task<Boolean> deleteTask = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        if (documentoService.eliminarArchivo(archivoId)) {
                            // Actualizar la lista de archivos en memoria
                            archivos.remove(selectedIndex);
                            // Actualizar el documento en la base de datos
                            return documentoService.actualizarArchivosDocumento(codigoDocumento, archivos);
                        }
                        return false;
                    }
                    
                    @Override
                    protected void succeeded() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            if (getValue()) {
                                listViewArchivos.getItems().remove(selectedIndex);
                                actualizarListaArchivos(documento);
                                updateButtonStates();
                                DialogUtils.showSuccess("✅ Archivo eliminado exitosamente.");
                            } else {
                                DialogUtils.showError("❌ Error al eliminar el archivo.");
                            }
                        });
                    }
                    
                    @Override
                    protected void failed() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            DialogUtils.showError("❌ Error al eliminar el archivo: " + getException().getMessage());
                        });
                    }
                };
                
                Thread deleteThread = new Thread(deleteTask);
                deleteThread.setDaemon(true);
                deleteThread.start();
            }
        }
    }

    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024.0));
        return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
    }

    private void abrirArchivo(Document documento) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.showError("Selecciona un archivo para abrir.");
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            ObjectId archivoId = archivo.getObjectId("archivoId");
            String nombreOriginal = archivo.getString("nombreOriginal");

            // Mostrar indicador de progreso
            ProgressIndicator progressIndicator = new ProgressIndicator();
            progressIndicator.setPrefSize(25, 25);
            Label lblAbriendo = new Label("🚀 Abriendo archivo...");
            lblAbriendo.setStyle("-fx-font-size: 12px; -fx-text-fill: #fd7e14; -fx-font-weight: bold;");
            
            HBox progressBox = new HBox(10, progressIndicator, lblAbriendo);
            progressBox.setAlignment(Pos.CENTER);
            
            VBox parent = (VBox) listViewArchivos.getParent();
            parent.getChildren().add(parent.getChildren().indexOf(listViewArchivos) + 1, progressBox);

            // Tarea asíncrona para abrir archivo
            Task<Boolean> openTask = new Task<Boolean>() {
                @Override
                protected Boolean call() throws Exception {
                    // Crear archivo temporal
                    File archivoTemp = File.createTempFile("temp_", "_" + nombreOriginal);
                    archivoTemp.deleteOnExit();
                    
                    if (documentoService.descargarArchivo(archivoId, archivoTemp.getAbsolutePath())) {
                        // Abrir con aplicación predeterminada
                        if (Desktop.isDesktopSupported()) {
                            Desktop.getDesktop().open(archivoTemp);
                            return true;
                        }
                    }
                    return false;
                }
                
                @Override
                protected void succeeded() {
                    Platform.runLater(() -> {
                        parent.getChildren().remove(progressBox);
                        if (getValue()) {
                            DialogUtils.showSuccess("✅ Archivo abierto exitosamente.");
                        } else {
                            DialogUtils.showError("❌ No se puede abrir el archivo automáticamente.");
                        }
                    });
                }
                
                @Override
                protected void failed() {
                    Platform.runLater(() -> {
                        parent.getChildren().remove(progressBox);
                        DialogUtils.showError("❌ Error al abrir el archivo: " + getException().getMessage());
                    });
                }
            };
            
            Thread openThread = new Thread(openTask);
            openThread.setDaemon(true);
            openThread.start();
        }
    }
}