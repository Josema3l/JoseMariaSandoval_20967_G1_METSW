package com.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

public class UsuarioService {
    private MongoCollection<Document> usuarioCollection;
    private Map<String, String[]> usuariosCache = new HashMap<>();

    public UsuarioService() {
        try {
            // 1. Configuración de conexión con MongoDB
            String connectionString = "mongodb://localhost:27017";
            MongoClient mongoClient = MongoClients.create(connectionString);
            
            // Usar sistemaUsuarios como nombre de la base de datos
            MongoDatabase database = mongoClient.getDatabase("sistemaUsuarios");
            
            // Usar Usuario como nombre de la colección (singular como indicaste)
            usuarioCollection = database.getCollection("Usuario");

            // 2. Verificar si la colección está vacía y crear admin por defecto
            if (usuarioCollection.countDocuments() == 0) {
                Document adminUser = new Document()
                    .append("usuario", "admin")
                    .append("contrasena", "admin123")
                    .append("rol", "Administradora")
                    .append("correo", "santy.rojas.2005.santylol@gmail.com");
                usuarioCollection.insertOne(adminUser);
            }
            
            // 3. Cargar datos en cache
            cargarUsuariosEnCache();
        } catch (Exception e) {
            System.err.println("Error al conectar con MongoDB: " + e.getMessage());
            throw new RuntimeException("No se pudo conectar a la base de datos", e);
        }
    }

    private void cargarUsuariosEnCache() {
        usuariosCache.clear();
        for (Document doc : usuarioCollection.find()) {
            try {
                // 4. Obtener los valores como strings directamente
                String usuario = doc.getString("usuario");
                String contrasena = doc.getString("contrasena");
                String rol = doc.getString("rol");
                String correo = doc.getString("correo"); // Agregar correo al cache
                
                usuariosCache.put(usuario, new String[]{contrasena, rol, correo != null ? correo : ""});
            } catch (Exception e) {
                System.err.println("Error procesando usuario: " + doc + " - " + e.getMessage());
            }
        }
    }

    public List<String> getTodosLosUsuarios() {
        return new ArrayList<>(usuariosCache.keySet());
    }

    public boolean verificarCredenciales(String usuario, String contrasena) {
        if (usuario == null || contrasena == null) {
            return false;
        }

        Document userDoc = usuarioCollection.find(Filters.eq("usuario", usuario)).first();

        if (userDoc == null) {
            return false; // Usuario no encontrado
        }
        
        // Obtener la contraseña como string directamente
        String contrasenaAlmacenada = userDoc.getString("contrasena");
        
        return contrasenaAlmacenada != null && contrasenaAlmacenada.equals(contrasena);
    }

    public boolean verificarUsuario(String usuario, String contrasena) {
        return verificarCredenciales(usuario, contrasena);
    }

    public String getRol(String usuario) {
        Document doc = usuarioCollection.find(Filters.eq("usuario", usuario)).first();
        return (doc != null) ? doc.getString("rol") : null;
    }

    public String getCorreo(String usuario) {
        Document doc = usuarioCollection.find(Filters.eq("usuario", usuario)).first();
        return (doc != null) ? doc.getString("correo") : null;
    }

    public static boolean esCorreoValido(String correo) {
        if (correo == null || correo.trim().isEmpty()) {
            return false;
        }
        
        // Validación básica de formato de correo electrónico
        String regexCorreo = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return correo.matches(regexCorreo);
    }

    public boolean existeCorreo(String correo) {
        Document doc = usuarioCollection.find(Filters.eq("correo", correo)).first();
        return doc != null;
    }

    public boolean existeUsuario(String usuario) {
        Document doc = usuarioCollection.find(Filters.eq("usuario", usuario)).first();
        return doc != null;
    }

    public String obtenerUsuarioPorCorreo(String correo) {
        Document doc = usuarioCollection.find(Filters.eq("correo", correo)).first();
        return (doc != null) ? doc.getString("usuario") : null;
    }

    public void actualizarContrasena(String usuario, String nuevaContrasena) {
        usuarioCollection.updateOne(
            Filters.eq("usuario", usuario),
            Updates.set("contrasena", nuevaContrasena)
        );
        cargarUsuariosEnCache(); // Actualizar cache
    }

    public boolean esContrasenaTemporal(String contrasena) {
        // Contraseñas temporales tienen exactamente 8 caracteres alfanuméricos
        return contrasena != null && contrasena.length() == 8 && 
               contrasena.matches("^[A-Za-z0-9]{8}$");
    }

    public String obtenerCorreoAdministradora() {
        Document doc = usuarioCollection.find(Filters.eq("rol", "Administradora")).first();
        return (doc != null) ? doc.getString("correo") : null;
    }

    public Document obtenerDatosAdministradora() {
        return usuarioCollection.find(Filters.eq("rol", "Administradora")).first();
    }

    public void crearUsuario(String usuario, String contrasena, String rol, String correo) {
        Document newUser = new Document()
            .append("usuario", usuario)
            .append("contrasena", contrasena)
            .append("rol", rol)
            .append("correo", correo);
        usuarioCollection.insertOne(newUser);
        cargarUsuariosEnCache(); // Actualizar cache
    }

    public Map<String, String[]> getUsuarios() {
        return usuariosCache;
    }

    public void cambiarCredenciales(String usuarioActual, String nuevoUsuario, String nuevaContrasena) {
        Document userDoc = usuarioCollection.find(Filters.eq("usuario", usuarioActual)).first();
        if (userDoc != null) {
            String usuarioFinal = (nuevoUsuario == null || nuevoUsuario.isEmpty()) ? 
                usuarioActual : nuevoUsuario;
            String contrasenaFinal = (nuevaContrasena == null || nuevaContrasena.isEmpty()) ? 
                userDoc.getString("contrasena") : nuevaContrasena;
            
            // Actualizar en MongoDB
            usuarioCollection.updateOne(
                Filters.eq("usuario", usuarioActual),
                Updates.combine(
                    Updates.set("usuario", usuarioFinal),
                    Updates.set("contrasena", contrasenaFinal)
                )
            );
            
            // Actualizar cache
            cargarUsuariosEnCache();
        }
    }
}