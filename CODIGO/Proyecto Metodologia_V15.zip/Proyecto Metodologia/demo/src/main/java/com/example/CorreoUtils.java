package com.example;

import jakarta.mail.AuthenticationFailedException;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.time.LocalDate;
import java.util.Properties;

public class CorreoUtils {
    public static boolean enviarRecordatorio(String remitente, String password, String destinatario, String asunto, String cuerpo) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, password);
            }
        });
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);
            message.setText(cuerpo);
            Transport.send(message);
            System.out.println("Correo enviado correctamente a " + destinatario);
            return true;
        } catch (AuthenticationFailedException e) {
            String msg = "Error de autenticación al enviar el correo. Verifica la contraseña de aplicación y que el acceso SMTP esté habilitado en tu cuenta de Gmail.";
            System.out.println(msg);
            e.printStackTrace();
            return false;
        } catch (MessagingException e) {
            String msg = "Error de mensajería: " + e.getMessage();
            System.out.println(msg);
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            String msg = "Error inesperado al enviar el correo: " + e.getMessage();
            System.out.println(msg);
            e.printStackTrace();
            return false;
        }
    }
}
