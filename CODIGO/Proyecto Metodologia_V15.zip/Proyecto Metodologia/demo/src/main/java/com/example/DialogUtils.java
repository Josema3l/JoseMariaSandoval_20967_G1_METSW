package com.example;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;

public class DialogUtils {
    /**
     * Muestra un aviso moderno con mensaje y botón de cerrar. Ejecuta onSuccess.run() si es éxito.
     * @param owner Nodo padre para centrar el diálogo
     * @param mensaje Mensaje a mostrar
     * @param esExito Si es true, cierra el formulario al cerrar el aviso
     * @param onSuccess Acción a ejecutar si es éxito (puede ser null)
     */
    public static void mostrarAviso(Node owner, String mensaje, boolean esExito, Runnable onSuccess) {
        javafx.stage.Stage avisoStage = new javafx.stage.Stage();
        avisoStage.setTitle(esExito ? "✅ Operación Exitosa" : "ℹ️ Información");
        
        // Icono moderno
        Label iconoLabel = new Label(esExito ? "✅" : "ℹ️");
        iconoLabel.setStyle(
            "-fx-font-size: 48px; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 8, 0, 0, 2);"
        );
        
        // Título del mensaje
        Label tituloLabel = new Label(esExito ? "¡Éxito!" : "Información");
        tituloLabel.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 20px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: " + (esExito ? "#27ae60" : "#3498db") + "; " +
            "-fx-padding: 0 0 10 0;"
        );
        
        // Mensaje principal con soporte para texto largo
        Label mensajeLabel = new Label(mensaje);
        mensajeLabel.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-line-spacing: 2px; " +
            "-fx-padding: 0; " +
            "-fx-background-color: transparent;"
        );
        mensajeLabel.setWrapText(true);
        mensajeLabel.setTextAlignment(TextAlignment.CENTER);
        mensajeLabel.setAlignment(Pos.CENTER);
        mensajeLabel.setMaxWidth(380);
        mensajeLabel.setPrefWidth(380);
        mensajeLabel.setMinHeight(50);
        
        // VBox para el mensaje con padding adecuado y centrado perfecto
        VBox mensajeContainer = new VBox(mensajeLabel);
        mensajeContainer.setAlignment(Pos.CENTER);
        mensajeContainer.setPadding(new Insets(15, 25, 15, 25));
        mensajeContainer.setMaxWidth(430);
        mensajeContainer.setMinHeight(70);
        mensajeContainer.setStyle("-fx-background-color: transparent;");
        
        // Botón moderno con gradiente
        Button btnCerrar = new Button("Entendido");
        btnCerrar.setPrefWidth(120);
        btnCerrar.setPrefHeight(40);
        btnCerrar.setStyle(
            "-fx-background-color: linear-gradient(to bottom, " + 
            (esExito ? "#27ae60, #2ecc71" : "#3498db, #2980b9") + "); " +
            "-fx-text-fill: white; " +
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8px; " +
            "-fx-border-radius: 8px; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2);"
        );
        btnCerrar.setDefaultButton(true);
        
        // Efecto hover para el botón
        btnCerrar.setOnMouseEntered(e -> btnCerrar.setStyle(
            "-fx-background-color: linear-gradient(to bottom, " + 
            (esExito ? "#2ecc71, #27ae60" : "#5dade2, #3498db") + "); " +
            "-fx-text-fill: white; " +
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8px; " +
            "-fx-border-radius: 8px; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        ));
        
        btnCerrar.setOnMouseExited(e -> btnCerrar.setStyle(
            "-fx-background-color: linear-gradient(to bottom, " + 
            (esExito ? "#27ae60, #2ecc71" : "#3498db, #2980b9") + "); " +
            "-fx-text-fill: white; " +
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8px; " +
            "-fx-border-radius: 8px; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2);"
        ));
        
        // Header con icono y título
        VBox headerBox = new VBox(8);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.getChildren().addAll(iconoLabel, tituloLabel);
        
        // Contenedor principal del contenido
        VBox contentBox = new VBox(20);
        contentBox.setAlignment(Pos.CENTER);
        contentBox.setPadding(new Insets(25, 30, 25, 30));
        contentBox.getChildren().addAll(headerBox, mensajeContainer, btnCerrar);
        
        // Contenedor con fondo y sombras modernas
        StackPane container = new StackPane(contentBox);
        container.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-background-radius: 15px; " +
            "-fx-border-radius: 15px; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 20, 0, 0, 8);"
        );
        container.setMaxWidth(500);
        container.setMinWidth(350);
        
        // Fondo general completamente transparente con mayor padding
        StackPane root = new StackPane(container);
        root.setStyle("-fx-background-color: transparent;");
        root.setPadding(new Insets(20, 20, 20, 20)); // Padding uniforme más grande para eliminar bordes
        
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        scene.setFill(javafx.scene.paint.Color.TRANSPARENT); // Fondo completamente transparente
        avisoStage.setScene(scene);
        avisoStage.setResizable(false);
        avisoStage.initStyle(javafx.stage.StageStyle.TRANSPARENT);
        avisoStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
        
        // Forzar transparencia total del stage
        avisoStage.setOpacity(1.0);
        
        if (owner != null && owner.getScene() != null && owner.getScene().getWindow() != null) {
            avisoStage.initOwner(owner.getScene().getWindow());
        }
        
        // Permitir cerrar con ESC
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                avisoStage.close();
            }
        });
        
        btnCerrar.setOnAction(e -> {
            avisoStage.close();
            if (onSuccess != null) {
                javafx.application.Platform.runLater(onSuccess);
            }
        });
        
        avisoStage.showAndWait();
    }
    
    /**
     * Muestra un mensaje de éxito
     */
    public static void showSuccess(String mensaje) {
        mostrarAviso(null, mensaje, true, null);
    }
    
    /**
     * Muestra un mensaje de error
     */
    public static void showError(String mensaje) {
        mostrarAviso(null, mensaje, false, null);
    }
    
    /**
     * Muestra un diálogo de confirmación
     */
    public static java.util.Optional<javafx.scene.control.ButtonType> showConfirmation(String titulo, String mensaje) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        
        // Aplicar estilo moderno
        alert.getDialogPane().setStyle("""
            -fx-background-color: white;
            -fx-font-family: 'Segoe UI';
            """);
        
        return alert.showAndWait();
    }
}
