package com.example;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.bson.Document;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

public class ArchivoManagerDialogRequisito {
    private final Stage stage;
    private final RequisitoLegalService requisitoService;
    private final ListView<String> archivosListView;
    private final ObservableList<String> archivosObservableList;
    private final String nombreRequisitoLegal;
    private Label infoLabel;
    private Button eliminarBtn;
    private Button descargarBtn;
    private Button verificarBtn;

    public ArchivoManagerDialogRequisito(String nombreRequisitoLegal, RequisitoLegalService requisitoService) {
        this.nombreRequisitoLegal = nombreRequisitoLegal;
        this.requisitoService = requisitoService;
        this.archivosObservableList = FXCollections.observableArrayList();
        this.archivosListView = new ListView<>(archivosObservableList);
        
        // Configurar stage
        this.stage = new Stage();
        this.stage.initModality(Modality.APPLICATION_MODAL);
        this.stage.setTitle("📁 Gestión de Archivos - Requisito Legal");
        this.stage.setWidth(800);
        this.stage.setHeight(650);
        this.stage.setResizable(true);

        setupInterface();
        cargarArchivos();
    }

    private void setupInterface() {
        // Container principal con gradiente moderno
        VBox mainContainer = new VBox();
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #f8f9fa, #e9ecef);
            """);

        // Header con título
        VBox headerBox = new VBox(10);
        headerBox.setPadding(new Insets(30, 30, 20, 30));
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2);");

        Label titulo = new Label("📁 Gestión de Archivos");
        titulo.setStyle("""
            -fx-font-size: 28px;
            -fx-font-weight: bold;
            -fx-text-fill: white;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.3), 2, 0, 1, 1);
            """);

        Label subtitulo = new Label("Requisito Legal: " + nombreRequisitoLegal);
        subtitulo.setStyle("""
            -fx-font-size: 16px;
            -fx-text-fill: rgba(255,255,255,0.9);
            """);

        infoLabel = new Label();
        infoLabel.setStyle("""
            -fx-font-size: 12px;
            -fx-text-fill: rgba(255,255,255,0.8);
            """);

        headerBox.getChildren().addAll(titulo, subtitulo, infoLabel);

        // Área de contenido principal
        VBox contentBox = new VBox(20);
        contentBox.setPadding(new Insets(30, 40, 30, 40));

        // Lista de archivos moderna
        Label lblArchivos = new Label("📋 Archivos del Requisito Legal");
        lblArchivos.setStyle("""
            -fx-font-size: 18px;
            -fx-font-weight: bold;
            -fx-text-fill: #2c3e50;
            """);

        // Configurar ListView
        archivosListView.setPrefHeight(250);
        archivosListView.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 3, 0, 0, 1);
            -fx-font-size: 14px;
            """);

        // Listener para selección
        archivosListView.getSelectionModel().selectedItemProperty().addListener(
            (@SuppressWarnings("unused") var obs, @SuppressWarnings("unused") var oldSelection, @SuppressWarnings("unused") var newSelection) -> updateButtonStates()
        );

        // Grid de botones modernos
        GridPane buttonGrid = new GridPane();
        buttonGrid.setHgap(15);
        buttonGrid.setVgap(15);
        buttonGrid.setAlignment(Pos.CENTER);

        // Configurar columnas
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHalignment(HPos.CENTER);
        col1.setPrefWidth(180);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setHalignment(HPos.CENTER);
        col2.setPrefWidth(180);
        ColumnConstraints col3 = new ColumnConstraints();
        col3.setHalignment(HPos.CENTER);
        col3.setPrefWidth(180);
        buttonGrid.getColumnConstraints().addAll(col1, col2, col3);

        // Estilo común para botones
        String buttonStyle = """
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 20;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            -fx-pref-width: 160;
            -fx-pref-height: 40;
            """;

        // Botón Agregar
        Button agregarBtn = new Button("📎 Agregar Archivo");
        agregarBtn.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #28a745, #20a144);");
        agregarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> agregarBtn.setStyle(agregarBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        agregarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> agregarBtn.setStyle(agregarBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        agregarBtn.setOnAction((@SuppressWarnings("unused") var e) -> agregarArchivo());

        // Botón Descargar
        descargarBtn = new Button("💾 Descargar");
        descargarBtn.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #007bff, #0056b3);");
        descargarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> descargarBtn.setStyle(descargarBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        descargarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> descargarBtn.setStyle(descargarBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        descargarBtn.setOnAction((@SuppressWarnings("unused") var e) -> descargarArchivo());

        // Botón Verificar
        verificarBtn = new Button("🔍 Verificar");
        verificarBtn.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #17a2b8, #138496);");
        verificarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> verificarBtn.setStyle(verificarBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        verificarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> verificarBtn.setStyle(verificarBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        verificarBtn.setOnAction((@SuppressWarnings("unused") var e) -> verificarArchivo());

        // Botón Eliminar
        eliminarBtn = new Button("🗑️ Eliminar");
        eliminarBtn.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #dc3545, #c82333);");
        eliminarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> eliminarBtn.setStyle(eliminarBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        eliminarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> eliminarBtn.setStyle(eliminarBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        eliminarBtn.setOnAction((@SuppressWarnings("unused") var e) -> eliminarArchivo());

        // Botón Actualizar
        Button actualizarBtn = new Button("🔄 Actualizar");
        actualizarBtn.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #6f42c1, #5a32a3);");
        actualizarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> actualizarBtn.setStyle(actualizarBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        actualizarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> actualizarBtn.setStyle(actualizarBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        actualizarBtn.setOnAction((@SuppressWarnings("unused") var e) -> cargarArchivos());

        // Botón Abrir Carpeta
        Button abrirCarpetaBtn = new Button("📂 Abrir Carpeta");
        abrirCarpetaBtn.setStyle(buttonStyle + "-fx-background-color: linear-gradient(to bottom, #fd7e14, #e8590c);");
        abrirCarpetaBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> abrirCarpetaBtn.setStyle(abrirCarpetaBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        abrirCarpetaBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> abrirCarpetaBtn.setStyle(abrirCarpetaBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        abrirCarpetaBtn.setOnAction((@SuppressWarnings("unused") var e) -> abrirCarpetaArchivos());

        // Agregar botones al grid
        buttonGrid.add(agregarBtn, 0, 0);
        buttonGrid.add(descargarBtn, 1, 0);
        buttonGrid.add(verificarBtn, 2, 0);
        buttonGrid.add(eliminarBtn, 0, 1);
        buttonGrid.add(actualizarBtn, 1, 1);
        buttonGrid.add(abrirCarpetaBtn, 2, 1);

        // Botón Cerrar centrado
        Button cerrarBtn = new Button("❌ Cerrar");
        cerrarBtn.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #6c757d, #5a6268);
            -fx-text-fill: white;
            -fx-font-size: 16px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 30;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        cerrarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> cerrarBtn.setStyle(cerrarBtn.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        cerrarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> cerrarBtn.setStyle(cerrarBtn.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        cerrarBtn.setOnAction((@SuppressWarnings("unused") var e) -> stage.close());

        HBox closeBox = new HBox();
        closeBox.setAlignment(Pos.CENTER);
        closeBox.setPadding(new Insets(20, 0, 0, 0));
        closeBox.getChildren().add(cerrarBtn);

        contentBox.getChildren().addAll(lblArchivos, archivosListView, buttonGrid, closeBox);

        // Ensamblar la interfaz
        mainContainer.getChildren().addAll(headerBox, contentBox);

        Scene scene = new Scene(mainContainer, 800, 650);
        stage.setScene(scene);
        
        updateButtonStates();
    }
    private void cargarArchivos() {
        // Mostrar indicador de progreso
        ProgressIndicator progressIndicator = new ProgressIndicator();
        progressIndicator.setPrefSize(20, 20);
        Label lblCargando = new Label("📂 Cargando archivos...");
        lblCargando.setStyle("-fx-font-size: 12px; -fx-text-fill: #3498db; -fx-font-weight: bold;");
        
        HBox progressBox = new HBox(10, progressIndicator, lblCargando);
        progressBox.setAlignment(Pos.CENTER);
        
        VBox parent = (VBox) archivosListView.getParent();
        if (parent != null) {
            parent.getChildren().add(parent.getChildren().indexOf(archivosListView) + 1, progressBox);
        }

        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                Document requisito = requisitoService.obtenerRequisitoPorNombre(nombreRequisitoLegal);
                if (requisito != null) {
                    @SuppressWarnings("unchecked")
                    List<String> nombresArchivos = (List<String>) requisito.get("nombresArchivos");
                    if (nombresArchivos != null) {
                        Platform.runLater(() -> {
                            archivosObservableList.clear();
                            for (String archivo : nombresArchivos) {
                                archivosObservableList.add("📄 " + archivo);
                            }
                            updateInfoLabel();
                        });
                    } else {
                        Platform.runLater(() -> {
                            archivosObservableList.clear();
                            updateInfoLabel();
                        });
                    }
                } else {
                    Platform.runLater(() -> {
                        archivosObservableList.clear();
                        updateInfoLabel();
                    });
                }
                return null;
            }
            
            @Override
            protected void succeeded() {
                Platform.runLater(() -> {
                    if (parent != null) {
                        parent.getChildren().remove(progressBox);
                    }
                });
            }
            
            @Override
            protected void failed() {
                Platform.runLater(() -> {
                    if (parent != null) {
                        parent.getChildren().remove(progressBox);
                    }
                    DialogUtils.showError("Error al cargar archivos: " + getException().getMessage());
                });
            }
        };

        Thread thread = new Thread(task);
        thread.setDaemon(true);
        thread.start();
    }

    private void updateInfoLabel() {
        int totalArchivos = archivosObservableList.size();
        if (totalArchivos > 0) {
            infoLabel.setText("📊 Total de archivos: " + totalArchivos);
        } else {
            infoLabel.setText("📊 No hay archivos adjuntos");
        }
    }

    private void updateButtonStates() {
        boolean haySeleccion = archivosListView.getSelectionModel().getSelectedItem() != null;
        eliminarBtn.setDisable(!haySeleccion);
        descargarBtn.setDisable(!haySeleccion);
        if (verificarBtn != null) {
            verificarBtn.setDisable(!haySeleccion);
        }
    }

    private void agregarArchivo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("📎 Seleccionar archivo para requisito legal");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Hojas de cálculo", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif"),
            new FileChooser.ExtensionFilter("Archivos de texto", "*.txt", "*.rtf")
        );

        File archivoSeleccionado = fileChooser.showOpenDialog(stage);
        if (archivoSeleccionado != null) {
            // Verificar tamaño del archivo (límite de 50MB)
            if (archivoSeleccionado.length() > 50 * 1024 * 1024) {
                DialogUtils.showError("El archivo es demasiado grande. El tamaño máximo permitido es 50MB.");
                return;
            }

            // Mostrar indicador de progreso
            ProgressIndicator progressIndicator = new ProgressIndicator();
            progressIndicator.setPrefSize(25, 25);
            Label lblSubiendo = new Label("📤 Subiendo archivo...");
            lblSubiendo.setStyle("-fx-font-size: 12px; -fx-text-fill: #28a745; -fx-font-weight: bold;");
            
            HBox progressBox = new HBox(10, progressIndicator, lblSubiendo);
            progressBox.setAlignment(Pos.CENTER);
            
            VBox parent = (VBox) archivosListView.getParent();
            parent.getChildren().add(parent.getChildren().indexOf(archivosListView) + 1, progressBox);

            Task<Boolean> task = new Task<Boolean>() {
                @Override
                protected Boolean call() throws Exception {
                    return requisitoService.agregarArchivo(nombreRequisitoLegal, archivoSeleccionado);
                }

                @Override
                protected void succeeded() {
                    Platform.runLater(() -> {
                        parent.getChildren().remove(progressBox);
                        if (getValue()) {
                            DialogUtils.showSuccess("✅ Archivo agregado exitosamente: " + archivoSeleccionado.getName());
                            cargarArchivos();
                        } else {
                            DialogUtils.showError("❌ Error al agregar el archivo");
                        }
                    });
                }

                @Override
                protected void failed() {
                    Platform.runLater(() -> {
                        parent.getChildren().remove(progressBox);
                        DialogUtils.showError("❌ Error al agregar el archivo: " + getException().getMessage());
                    });
                }
            };

            Thread thread = new Thread(task);
            thread.setDaemon(true);
            thread.start();
        }
    }

    private void eliminarArchivo() {
        int indiceSeleccionado = archivosListView.getSelectionModel().getSelectedIndex();
        String archivoSeleccionado = archivosListView.getSelectionModel().getSelectedItem();
        
        if (indiceSeleccionado >= 0 && archivoSeleccionado != null) {
            String nombreArchivo = archivoSeleccionado.replace("📄 ", "");
            
            Optional<ButtonType> resultado = DialogUtils.showConfirmation(
                "🗑️ Confirmar eliminación",
                "¿Está seguro de que desea eliminar el archivo:\n\n📄 " + nombreArchivo + "\n\nEsta acción no se puede deshacer."
            );

            if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
                // Mostrar indicador de progreso
                ProgressIndicator progressIndicator = new ProgressIndicator();
                progressIndicator.setPrefSize(25, 25);
                Label lblEliminando = new Label("🗑️ Eliminando archivo...");
                lblEliminando.setStyle("-fx-font-size: 12px; -fx-text-fill: #dc3545; -fx-font-weight: bold;");
                
                HBox progressBox = new HBox(10, progressIndicator, lblEliminando);
                progressBox.setAlignment(Pos.CENTER);
                
                VBox parent = (VBox) archivosListView.getParent();
                parent.getChildren().add(parent.getChildren().indexOf(archivosListView) + 1, progressBox);

                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return requisitoService.eliminarArchivo(nombreRequisitoLegal, indiceSeleccionado);
                    }

                    @Override
                    protected void succeeded() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            if (getValue()) {
                                DialogUtils.showSuccess("✅ Archivo eliminado exitosamente");
                                cargarArchivos();
                                updateButtonStates();
                            } else {
                                DialogUtils.showError("❌ Error al eliminar el archivo");
                            }
                        });
                    }

                    @Override
                    protected void failed() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            DialogUtils.showError("❌ Error al eliminar el archivo: " + getException().getMessage());
                        });
                    }
                };

                Thread thread = new Thread(task);
                thread.setDaemon(true);
                thread.start();
            }
        }
    }

    private void descargarArchivo() {
        int indiceSeleccionado = archivosListView.getSelectionModel().getSelectedIndex();
        String archivoSeleccionado = archivosListView.getSelectionModel().getSelectedItem();
        
        if (indiceSeleccionado >= 0 && archivoSeleccionado != null) {
            String nombreArchivo = archivoSeleccionado.replace("📄 ", "");
            
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("📂 Seleccionar carpeta de destino");
            
            // Establecer directorio inicial
            try {
                String userHome = System.getProperty("user.home");
                Path downloadsPath = Paths.get(userHome, "Downloads");
                if (Files.exists(downloadsPath)) {
                    directoryChooser.setInitialDirectory(downloadsPath.toFile());
                } else {
                    directoryChooser.setInitialDirectory(new File(userHome));
                }
            } catch (Exception e) {
                // Si hay error, usar directorio actual
                directoryChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
            }

            File directorioDestino = directoryChooser.showDialog(stage);
            if (directorioDestino != null) {
                // Mostrar indicador de progreso
                ProgressIndicator progressIndicator = new ProgressIndicator();
                progressIndicator.setPrefSize(25, 25);
                Label lblDescargando = new Label("💾 Descargando archivo...");
                lblDescargando.setStyle("-fx-font-size: 12px; -fx-text-fill: #007bff; -fx-font-weight: bold;");
                
                HBox progressBox = new HBox(10, progressIndicator, lblDescargando);
                progressBox.setAlignment(Pos.CENTER);
                
                VBox parent = (VBox) archivosListView.getParent();
                parent.getChildren().add(parent.getChildren().indexOf(archivosListView) + 1, progressBox);

                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return requisitoService.descargarArchivoDeRequisito(
                            nombreRequisitoLegal, 
                            indiceSeleccionado, 
                            directorioDestino.getAbsolutePath()
                        );
                    }

                    @Override
                    protected void succeeded() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            if (getValue()) {
                                DialogUtils.showSuccess(
                                    "✅ Archivo descargado exitosamente:\n\n📂 " + directorioDestino.getAbsolutePath() + 
                                    File.separator + nombreArchivo
                                );
                            } else {
                                DialogUtils.showError("❌ Error al descargar el archivo");
                            }
                        });
                    }

                    @Override
                    protected void failed() {
                        Platform.runLater(() -> {
                            parent.getChildren().remove(progressBox);
                            DialogUtils.showError("❌ Error al descargar el archivo: " + getException().getMessage());
                        });
                    }
                };

                Thread thread = new Thread(task);
                thread.setDaemon(true);
                thread.start();
            }
        }
    }

    private void verificarArchivo() {
        int indiceSeleccionado = archivosListView.getSelectionModel().getSelectedIndex();
        String archivoSeleccionado = archivosListView.getSelectionModel().getSelectedItem();
        
        if (indiceSeleccionado >= 0 && archivoSeleccionado != null) {
            String nombreArchivo = archivoSeleccionado.replace("📄 ", "");
            
            // Mostrar información del archivo
            String info = String.format(
                "📄 Información del Archivo\n\n" +
                "📋 Nombre: %s\n" +
                "📂 Requisito Legal: %s\n" +
                "📍 Índice: %d\n" +
                "🔗 Ubicación: Almacenado en el sistema"
                ,
                nombreArchivo,
                nombreRequisitoLegal,
                indiceSeleccionado + 1
            );

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("🔍 Información del archivo");
            alert.setHeaderText("Detalles del archivo seleccionado");
            alert.setContentText(info);
            
            // Aplicar estilo moderno al diálogo
            alert.getDialogPane().setStyle("""
                -fx-background-color: #f8f9fa;
                -fx-font-family: 'Segoe UI';
                """);
            
            alert.showAndWait();
        }
    }

    private void abrirCarpetaArchivos() {
        try {
            String carpetaArchivos = "documentos_partes_interesadas" + File.separator + nombreRequisitoLegal;
            File carpeta = new File(carpetaArchivos);
            
            if (!carpeta.exists()) {
                DialogUtils.showError("📂 La carpeta de archivos no existe aún.\n\nSe creará automáticamente cuando agregue el primer archivo.");
                return;
            }
            
            // Intentar abrir la carpeta con el explorador del sistema
            if (java.awt.Desktop.isDesktopSupported()) {
                java.awt.Desktop.getDesktop().open(carpeta);
                DialogUtils.showSuccess("✅ Carpeta abierta en el explorador de archivos");
            } else {
                DialogUtils.showError("❌ No se puede abrir la carpeta automáticamente.\n\nUbicación: " + carpeta.getAbsolutePath());
            }
        } catch (Exception e) {
            DialogUtils.showError("❌ Error al abrir la carpeta: " + e.getMessage());
        }
    }

    public void show() {
        stage.show();
    }

    public void showAndWait() {
        stage.showAndWait();
    }
}
