package com.example;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.security.SecureRandom;

public class RecuperarContrasenaDialog {
    private final UsuarioService usuarioService;
    private final Stage parentStage;

    public RecuperarContrasenaDialog(UsuarioService usuarioService, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stage = new Stage();
        stage.setTitle("Recuperar Contraseña");
        stage.initModality(Modality.WINDOW_MODAL);
        stage.initOwner(parentStage);
        stage.setResizable(false);

        // Container principal con gradiente moderno
        VBox mainContainer = new VBox();
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #f8f9fa, #e9ecef);
            -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 0);
            """);

        // Header con título
        VBox headerBox = new VBox(10);
        headerBox.setPadding(new Insets(30, 30, 20, 30));
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2);");

        Label titulo = new Label("Recuperar Contraseña");
        titulo.setStyle("""
            -fx-font-size: 24px;
            -fx-font-weight: bold;
            -fx-text-fill: white;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.3), 2, 0, 1, 1);
            """);

        Label subtitulo = new Label("Obtenga una nueva contraseña temporal");
        subtitulo.setStyle("""
            -fx-font-size: 14px;
            -fx-text-fill: rgba(255,255,255,0.9);
            """);

        headerBox.getChildren().addAll(titulo, subtitulo);

        // Formulario con VBox centrado
        VBox formBox = new VBox(25);
        formBox.setPadding(new Insets(40, 50, 40, 50));
        formBox.setAlignment(Pos.CENTER);

        // Instrucciones
        Label instruccion = new Label("Ingrese su nombre de usuario o correo electrónico:");
        instruccion.setStyle("""
            -fx-font-size: 16px;
            -fx-font-weight: 600;
            -fx-text-fill: #2c3e50;
            -fx-text-alignment: center;
            """);
        instruccion.setWrapText(true);
        instruccion.setMaxWidth(400);

        // Campo de texto con estilo moderno
        TextField txtIdentificador = new TextField();
        txtIdentificador.setPromptText("Usuario o correo electrónico");
        txtIdentificador.setPrefWidth(350);
        txtIdentificador.setPrefHeight(50);
        txtIdentificador.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-padding: 15;
            -fx-font-size: 16px;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);
            """);

        String fieldFocusStyle = """
            -fx-background-color: white;
            -fx-border-color: #667eea;
            -fx-border-width: 2;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-padding: 15;
            -fx-font-size: 16px;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);
            """;

        txtIdentificador.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtIdentificador.setStyle(newVal ? fieldFocusStyle : txtIdentificador.getStyle());
        });

        // Información adicional
        Label infoLabel = new Label("Se enviará una contraseña temporal a su correo electrónico registrado");
        infoLabel.setStyle("""
            -fx-font-size: 13px;
            -fx-text-fill: #6c757d;
            -fx-text-alignment: center;
            """);
        infoLabel.setWrapText(true);
        infoLabel.setMaxWidth(400);

        formBox.getChildren().addAll(instruccion, txtIdentificador, infoLabel);

        // Botones con estilo moderno
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20, 30, 30, 30));

        Button btnEnviar = new Button("Enviar Nueva Contraseña");
        btnEnviar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #007bff, #0056b3);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnEnviar.setOnMouseEntered(e -> btnEnviar.setStyle(btnEnviar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnEnviar.setOnMouseExited(e -> btnEnviar.setStyle(btnEnviar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #6c757d, #5a6268);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCancelar.setOnMouseEntered(e -> btnCancelar.setStyle(btnCancelar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCancelar.setOnMouseExited(e -> btnCancelar.setStyle(btnCancelar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnCancelar.setOnAction(e -> stage.close());

        buttonBox.getChildren().addAll(btnEnviar, btnCancelar);

        // Ensamblar la interfaz
        mainContainer.getChildren().addAll(headerBox, formBox, buttonBox);

        // Configurar escena
        Scene scene = new Scene(mainContainer, 550, 500);
        stage.setScene(scene);

        // Manejar tecla ESC
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stage.close();
            }
        });

        btnEnviar.setOnAction(e -> {
            String identificador = txtIdentificador.getText();
            if (identificador == null || identificador.trim().isEmpty()) {
                DialogUtils.showError("Debe ingresar un usuario o correo electrónico");
                return;
            }

            procesarRecuperacion(identificador.trim(), stage);
        });

        stage.showAndWait();
    }

    private void procesarRecuperacion(String identificador, Stage stage) {
        try {
            // Buscar usuario por nombre o correo
            String usuario = null;
            String correo = null;

            // Verificar si es un correo electrónico
            if (UsuarioService.esCorreoValido(identificador)) {
                usuario = usuarioService.obtenerUsuarioPorCorreo(identificador);
                correo = identificador;
            } else {
                // Es un nombre de usuario
                if (usuarioService.existeUsuario(identificador)) {
                    usuario = identificador;
                    correo = usuarioService.getCorreo(identificador);
                }
            }

            if (usuario == null) {
                DialogUtils.showError("Usuario o correo electrónico no encontrado");
                return;
            }

            if (correo == null || correo.trim().isEmpty()) {
                DialogUtils.showError("El usuario no tiene un correo electrónico registrado");
                return;
            }

            // Generar nueva contraseña temporal
            String nuevaContrasena = generarContrasenaTemporal();

            // Actualizar contraseña en la base de datos
            usuarioService.actualizarContrasena(usuario, nuevaContrasena);

            // Usar credenciales del administrador (ya configuradas en el sistema)
            String remitenteAdmin = usuarioService.obtenerCorreoAdministradora();
            String passwordAdmin = "mtxxorlkbnpwjdkt"; // Contraseña de aplicación ya configurada

            if (remitenteAdmin == null) {
                DialogUtils.showError("Error: No se encontró el correo del administrador");
                return;
            }

            String asunto = "Recuperación de contraseña - Sistema";
            String cuerpo = String.format(
                "Hola %s,\n\n" +
                "Su nueva contraseña temporal es: %s\n\n" +
                "Por favor, cambie esta contraseña después de iniciar sesión.\n\n" +
                "Saludos,\n" +
                "Equipo del Sistema",
                usuario, nuevaContrasena
            );

            // Enviar correo automáticamente
            boolean enviado = CorreoUtils.enviarRecordatorio(remitenteAdmin, passwordAdmin, correo, asunto, cuerpo);

            if (enviado) {
                DialogUtils.showSuccess(
                    "Nueva contraseña enviada exitosamente a " + correo + 
                    "\n\nRevise su correo electrónico para obtener la contraseña temporal.");
                stage.close();
            } else {
                DialogUtils.showError(
                    "Error al enviar el correo.\n\n" +
                    "Por favor, contacte al administrador para obtener una nueva contraseña.");
            }

        } catch (Exception ex) {
            DialogUtils.showError("Error al procesar la recuperación: " + ex.getMessage());
        }
    }

    private String generarContrasenaTemporal() {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        SecureRandom random = new SecureRandom();
        StringBuilder contrasena = new StringBuilder(8);

        for (int i = 0; i < 8; i++) {
            contrasena.append(caracteres.charAt(random.nextInt(caracteres.length())));
        }

        return contrasena.toString();
    }
}
