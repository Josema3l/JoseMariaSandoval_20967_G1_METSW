package com.example;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CambioContrasenaDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioContrasenaDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar Contraseña");
        stageCambio.initModality(Modality.WINDOW_MODAL);
        stageCambio.initOwner(parentStage);
        stageCambio.setResizable(false);

        // Container principal con gradiente moderno
        VBox mainContainer = new VBox();
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #f8f9fa, #e9ecef);
            -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 0);
            """);

        // Header con título
        VBox headerBox = new VBox(10);
        headerBox.setPadding(new Insets(30, 30, 20, 30));
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2);");

        Label titulo = new Label("Cambiar Contraseña");
        titulo.setStyle("""
            -fx-font-size: 24px;
            -fx-font-weight: bold;
            -fx-text-fill: white;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.3), 2, 0, 1, 1);
            """);

        Label subtitulo = new Label("Actualice la contraseña del usuario");
        subtitulo.setStyle("""
            -fx-font-size: 14px;
            -fx-text-fill: rgba(255,255,255,0.9);
            """);

        headerBox.getChildren().addAll(titulo, subtitulo);

        // Formulario con GridPane
        GridPane formGrid = new GridPane();
        formGrid.setHgap(15);
        formGrid.setVgap(20);
        formGrid.setPadding(new Insets(30, 40, 30, 40));
        formGrid.setAlignment(Pos.CENTER);

        // Configurar columnas
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHalignment(HPos.RIGHT);
        col1.setPrefWidth(150);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPrefWidth(280);
        formGrid.getColumnConstraints().addAll(col1, col2);

        // Estilo común para labels
        String labelStyle = """
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-text-fill: #2c3e50;
            """;

        // Estilo común para campos
        String fieldStyle = """
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-padding: 12;
            -fx-font-size: 14px;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);
            """;

        String fieldFocusStyle = fieldStyle + """
            -fx-border-color: #667eea;
            -fx-border-width: 2;
            """;

        int rowIndex = 0;

        // Configuración según el rol
        boolean esPrivilegiado = rol.equalsIgnoreCase("Tester") || rol.equalsIgnoreCase("Administradora");

        // Campo Usuario
        Label lblUsuario = new Label("Usuario:");
        lblUsuario.setStyle(labelStyle);
        ComboBox<String> comboUsuario = new ComboBox<>();
        comboUsuario.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-font-size: 14px;
            """);

        if (esPrivilegiado) {
            for (String u : usuarioService.getTodosLosUsuarios()) {
                comboUsuario.getItems().add(u);
            }
            comboUsuario.setEditable(false);
            comboUsuario.setPromptText("Seleccione usuario");
        } else {
            comboUsuario.getItems().add(usuario);
            comboUsuario.setValue(usuario);
            comboUsuario.setDisable(true);
        }

        formGrid.add(lblUsuario, 0, rowIndex);
        formGrid.add(comboUsuario, 1, rowIndex++);

        // CheckBox para cambio administrativo (solo para usuarios privilegiados)
        CheckBox chkCambioAdministrativo = null;
        if (esPrivilegiado) {
            chkCambioAdministrativo = new CheckBox("Cambio administrativo (sin verificar contraseña actual)");
            chkCambioAdministrativo.setStyle("""
                -fx-text-fill: #2c3e50;
                -fx-font-size: 12px;
                -fx-font-weight: 600;
                """);
            
            GridPane.setColumnSpan(chkCambioAdministrativo, 2);
            GridPane.setHalignment(chkCambioAdministrativo, HPos.CENTER);
            formGrid.add(chkCambioAdministrativo, 0, rowIndex++);
        }

        // Campo Contraseña Actual
        Label lblContrasenaActual = new Label("Contraseña actual:");
        lblContrasenaActual.setStyle(labelStyle);
        PasswordField txtContrasenaActual = new PasswordField();
        txtContrasenaActual.setStyle(fieldStyle);
        txtContrasenaActual.setPromptText("Ingrese contraseña actual");
        txtContrasenaActual.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtContrasenaActual.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        formGrid.add(lblContrasenaActual, 0, rowIndex);
        formGrid.add(txtContrasenaActual, 1, rowIndex++);

        // Campo Nueva Contraseña
        Label lblNuevaContrasena = new Label("Nueva contraseña:");
        lblNuevaContrasena.setStyle(labelStyle);
        PasswordField txtNuevaContrasena = new PasswordField();
        txtNuevaContrasena.setStyle(fieldStyle);
        txtNuevaContrasena.setPromptText("Ingrese nueva contraseña");
        txtNuevaContrasena.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtNuevaContrasena.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        formGrid.add(lblNuevaContrasena, 0, rowIndex);
        formGrid.add(txtNuevaContrasena, 1, rowIndex++);

        // Campo Repetir Contraseña
        Label lblRepetirContrasena = new Label("Repetir contraseña:");
        lblRepetirContrasena.setStyle(labelStyle);
        PasswordField txtRepetirContrasena = new PasswordField();
        txtRepetirContrasena.setStyle(fieldStyle);
        txtRepetirContrasena.setPromptText("Repita la nueva contraseña");
        txtRepetirContrasena.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtRepetirContrasena.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        formGrid.add(lblRepetirContrasena, 0, rowIndex);
        formGrid.add(txtRepetirContrasena, 1, rowIndex++);

        // Listener para cambio administrativo
        final CheckBox finalChk = chkCambioAdministrativo;
        if (chkCambioAdministrativo != null) {
            chkCambioAdministrativo.setOnAction(e -> {
                boolean isSelected = finalChk.isSelected();
                txtContrasenaActual.setDisable(isSelected);
                lblContrasenaActual.setDisable(isSelected);
                if (isSelected) {
                    txtContrasenaActual.clear();
                }
            });
        }

        // Botones con estilo moderno
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20, 30, 30, 30));

        Button btnCambiar = new Button("Cambiar Contraseña");
        btnCambiar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #28a745, #20a144);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCambiar.setOnMouseEntered(e -> btnCambiar.setStyle(btnCambiar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCambiar.setOnMouseExited(e -> btnCambiar.setStyle(btnCambiar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #6c757d, #5a6268);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCancelar.setOnMouseEntered(e -> btnCancelar.setStyle(btnCancelar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCancelar.setOnMouseExited(e -> btnCancelar.setStyle(btnCancelar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnCancelar.setOnAction(e -> stageCambio.close());

        buttonBox.getChildren().addAll(btnCambiar, btnCancelar);

        // Ensamblar la interfaz
        mainContainer.getChildren().addAll(headerBox, formGrid, buttonBox);

        // Configurar escena
        Scene scene = new Scene(mainContainer, 600, 650);
        stageCambio.setScene(scene);

        // Manejar tecla ESC
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        final CheckBox finalChkCambioAdministrativo = chkCambioAdministrativo;
        
        btnCambiar.setOnAction(e -> {
            String usuarioObjetivo = comboUsuario.getValue();
            String contrasenaActual = txtContrasenaActual.getText();
            String nuevaContrasena = txtNuevaContrasena.getText();
            String repetirContrasena = txtRepetirContrasena.getText();
            
            // Validaciones básicas
            if (usuarioObjetivo == null || usuarioObjetivo.isEmpty()) {
                DialogUtils.showError("Debe seleccionar un usuario.");
                return;
            }
            
            if (nuevaContrasena == null || nuevaContrasena.isEmpty()) {
                DialogUtils.showError("Debe ingresar la nueva contraseña.");
                return;
            }
            
            if (repetirContrasena == null || repetirContrasena.isEmpty()) {
                DialogUtils.showError("Debe repetir la nueva contraseña.");
                return;
            }

            // Verificar que las nuevas contraseñas coincidan
            if (!nuevaContrasena.equals(repetirContrasena)) {
                DialogUtils.showError("Las nuevas contraseñas no coinciden.");
                return;
            }

            // Verificación de contraseña actual según el tipo de cambio
            boolean esCambioAdministrativo = esPrivilegiado && finalChkCambioAdministrativo != null && finalChkCambioAdministrativo.isSelected();
            
            if (!esCambioAdministrativo) {
                // Verificación normal de contraseña
                if (contrasenaActual == null || contrasenaActual.isEmpty()) {
                    DialogUtils.showError("Debe ingresar la contraseña actual.");
                    return;
                }
                
                // Para usuarios privilegiados cambiando otros usuarios, verificar la contraseña del usuario objetivo
                String usuarioParaVerificar = esPrivilegiado ? usuarioObjetivo : usuario;
                if (!usuarioService.verificarCredenciales(usuarioParaVerificar, contrasenaActual)) {
                    DialogUtils.showError("Contraseña actual incorrecta.");
                    return;
                }
                
                // Verificar que la nueva contraseña sea diferente
                if (nuevaContrasena.equals(contrasenaActual)) {
                    DialogUtils.showError("La nueva contraseña no puede ser igual a la actual.");
                    return;
                }
            }

            try {
                usuarioService.cambiarCredenciales(usuarioObjetivo, null, nuevaContrasena);
                String mensaje = esCambioAdministrativo ? 
                    "Contraseña cambiada exitosamente (cambio administrativo)." : 
                    "Contraseña cambiada exitosamente.";
                DialogUtils.showSuccess(mensaje);
                stageCambio.close();
            } catch (Exception ex) {
                DialogUtils.showError("Error al cambiar la contraseña: " + ex.getMessage());
            }
        });

        stageCambio.showAndWait();
    }
}