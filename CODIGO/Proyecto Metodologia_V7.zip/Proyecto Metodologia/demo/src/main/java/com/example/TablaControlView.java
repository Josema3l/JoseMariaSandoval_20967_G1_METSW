package com.example;

import java.util.List;

import org.bson.Document;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TablaControlView {
    private final PanelController panelController;
    private final DocumentoService documentoService;

    public TablaControlView(PanelController panelController) {
        this.panelController = panelController;
        this.documentoService = new DocumentoService();
    }

    public void mostrar() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("Tabla de control de documentos legales");
        
        Button btnRegistrar = new Button("Registrar documento");
        btnRegistrar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20 10 20;");
        
        Button btnVer = new Button("Ver documentos registrados");
        btnVer.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20 10 20;");
        
        VBox vbox = new VBox(20, btnRegistrar, btnVer);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPrefSize(400, 200);
        
        Scene scene = new Scene(vbox);
        tablaStage.setScene(scene);
        tablaStage.show();

        btnRegistrar.setOnAction(_ -> {
            tablaStage.close();
            panelController.mostrarFormularioRegistro();
        });
        
        btnVer.setOnAction(_ -> {
            tablaStage.close();
            mostrarDocumentosRegistrados();
        });
        
        // Cerrar conexión cuando se cierre la ventana
        tablaStage.setOnCloseRequest(e -> cerrarConexion());
    }

    public void mostrarDocumentosRegistrados() {
        Stage docsStage = new Stage();
        docsStage.setTitle("Documentos registrados");
        
        // Crear la tabla
        TableView<DocumentoTableRow> table = new TableView<>();
        table.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // Configurar columnas
        TableColumn<DocumentoTableRow, String> colCodigo = new TableColumn<>("Código nro");
        colCodigo.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCodigo()));
        colCodigo.setPrefWidth(120);
        
        TableColumn<DocumentoTableRow, String> colRequisito = new TableColumn<>("Requisito Legal");
        colRequisito.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getRequisitoLegal()));
        colRequisito.setPrefWidth(200);
        
        TableColumn<DocumentoTableRow, String> colComoAplica = new TableColumn<>("Cómo se aplica");
        colComoAplica.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getComoSeAplica()));
        colComoAplica.setPrefWidth(180);
        
        TableColumn<DocumentoTableRow, String> colPorQueAplica = new TableColumn<>("Por qué lo aplica");
        colPorQueAplica.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPorQueLoAplica()));
        colPorQueAplica.setPrefWidth(180);
        
        TableColumn<DocumentoTableRow, String> colFechaEmision = new TableColumn<>("Fecha de emisión");
        colFechaEmision.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaEmision()));
        colFechaEmision.setPrefWidth(130);
        
        TableColumn<DocumentoTableRow, String> colFechaVencimiento = new TableColumn<>("Fecha de vencimiento");
        colFechaVencimiento.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaVencimiento()));
        colFechaVencimiento.setPrefWidth(140);
        
        TableColumn<DocumentoTableRow, String> colFechaRenovacion = new TableColumn<>("Fecha próxima renovación");
        colFechaRenovacion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaProximaRenovacion()));
        colFechaRenovacion.setPrefWidth(160);
        
        TableColumn<DocumentoTableRow, String> colArchivos = new TableColumn<>("Archivos");
        colArchivos.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCantidadArchivos()));
        colArchivos.setPrefWidth(80);
        
        table.getColumns().addAll(colCodigo, colRequisito, colComoAplica, colPorQueAplica, 
                                 colFechaEmision, colFechaVencimiento, colFechaRenovacion, colArchivos);
        
        // Crear menú contextual
        ContextMenu contextMenu = new ContextMenu();
        MenuItem menuGestionarArchivos = new MenuItem("Gestionar archivos");
        MenuItem menuEliminarDocumento = new MenuItem("Eliminar documento");
        
        menuGestionarArchivos.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                ArchivoManagerDialog archivoManager = new ArchivoManagerDialog(docsStage, selected.getCodigo());
                archivoManager.mostrar();
            }
        });
        
        menuEliminarDocumento.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarDocumento(selected.getCodigo(), table);
            }
        });
        
        contextMenu.getItems().addAll(menuGestionarArchivos, menuEliminarDocumento);
        table.setContextMenu(contextMenu);
        
        // Cargar datos
        cargarDocumentos(table);
        
        // Botones
        Button btnGestionarArchivos = new Button("Gestionar archivos");
        btnGestionarArchivos.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white;");
        btnGestionarArchivos.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                ArchivoManagerDialog archivoManager = new ArchivoManagerDialog(docsStage, selected.getCodigo());
                archivoManager.mostrar();
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un documento para gestionar sus archivos.", false, null);
            }
        });
        
        Button btnActualizar = new Button("Actualizar");
        btnActualizar.setOnAction(e -> cargarDocumentos(table));
        
        Button btnEliminar = new Button("Eliminar documento");
        btnEliminar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        btnEliminar.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarDocumento(selected.getCodigo(), table);
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un documento para eliminar.", false, null);
            }
        });
        
        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setOnAction(e -> docsStage.close());
        
        HBox hboxBotones = new HBox(10, btnGestionarArchivos, btnActualizar, btnEliminar, btnCerrar);
        hboxBotones.setAlignment(Pos.CENTER);
        
        VBox vbox = new VBox(10, table, hboxBotones);
        vbox.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(vbox, 1200, 600);
        docsStage.setScene(scene);
        docsStage.show();
        
        // Cerrar conexión cuando se cierre la ventana
        docsStage.setOnCloseRequest(e -> cerrarConexion());
    }
    
    private void cargarDocumentos(TableView<DocumentoTableRow> table) {
        try {
            List<Document> documentos = documentoService.obtenerTodosLosDocumentos();
            ObservableList<DocumentoTableRow> rows = FXCollections.observableArrayList();
            
            for (Document doc : documentos) {
                DocumentoTableRow row = new DocumentoTableRow(
                    obtenerStringSeguro(doc, "codigo"),
                    obtenerStringSeguro(doc, "requisitoLegal"),
                    obtenerStringSeguro(doc, "comoSeAplica"),
                    obtenerStringSeguro(doc, "porQueLoAplica"),
                    obtenerFechaComoString(doc, "fechaEmision"),
                    obtenerFechaComoString(doc, "fechaVencimiento"),
                    obtenerFechaComoString(doc, "fechaProximaRenovacion"),
                    obtenerCantidadArchivos(doc)
                );
                rows.add(row);
            }
            
            table.setItems(rows);
        } catch (Exception e) {
            DialogUtils.mostrarAviso(null, "Error al cargar los documentos: " + e.getMessage(), false, null);
            e.printStackTrace();
        }
    }
    
    private String obtenerStringSeguro(Document doc, String campo) {
        Object valor = doc.get(campo);
        return valor != null ? valor.toString() : "";
    }
    
    private String obtenerFechaComoString(Document doc, String campo) {
        Object fecha = doc.get(campo);
        if (fecha == null) {
            return "";
        }
        
        // Si es una fecha de Java (Date)
        if (fecha instanceof java.util.Date) {
            java.util.Date date = (java.util.Date) fecha;
            java.time.LocalDate localDate = date.toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();
            return localDate.toString();
        }
        
        // Si es un LocalDate
        if (fecha instanceof java.time.LocalDate) {
            return fecha.toString();
        }
        
        // Si es un string
        return fecha.toString();
    }
    
    private String obtenerCantidadArchivos(Document documento) {
        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        if (archivos != null) {
            return String.valueOf(archivos.size());
        }
        return "0";
    }
    
    private void eliminarDocumento(String codigo, TableView<DocumentoTableRow> table) {
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Confirmar eliminación");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText("¿Estás seguro de que deseas eliminar el documento '" + codigo + "'?\n" +
                                   "Esta acción también eliminará todos los archivos asociados.");
        
        if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            try {
                if (documentoService.eliminarDocumento(codigo)) {
                    cargarDocumentos(table); // Recargar la tabla
                    DialogUtils.mostrarAviso(null, "Documento eliminado exitosamente.", true, null);
                } else {
                    DialogUtils.mostrarAviso(null, "Error al eliminar el documento.", false, null);
                }
            } catch (Exception e) {
                DialogUtils.mostrarAviso(null, "Error al eliminar el documento: " + e.getMessage(), false, null);
                e.printStackTrace();
            }
        }
    }
    
    public void cerrarConexion() {
        if (documentoService != null) {
            documentoService.cerrarConexion();
        }
    }
    
    // Método estático para mantener compatibilidad con PanelController
    public static void mostrarDocumentosRegistradosEstatico() {
        TablaControlView tablaControlView = new TablaControlView(null);
        tablaControlView.mostrarDocumentosRegistrados();
    }
    
    // Clase interna para representar una fila de la tabla
    public static class DocumentoTableRow {
        private final String codigo;
        private final String requisitoLegal;
        private final String comoSeAplica;
        private final String porQueLoAplica;
        private final String fechaEmision;
        private final String fechaVencimiento;
        private final String fechaProximaRenovacion;
        private final String cantidadArchivos;
        
        public DocumentoTableRow(String codigo, String requisitoLegal, String comoSeAplica, 
                               String porQueLoAplica, String fechaEmision, String fechaVencimiento,
                               String fechaProximaRenovacion, String cantidadArchivos) {
            this.codigo = codigo;
            this.requisitoLegal = requisitoLegal;
            this.comoSeAplica = comoSeAplica;
            this.porQueLoAplica = porQueLoAplica;
            this.fechaEmision = fechaEmision;
            this.fechaVencimiento = fechaVencimiento;
            this.fechaProximaRenovacion = fechaProximaRenovacion;
            this.cantidadArchivos = cantidadArchivos;
        }
        
        // Getters
        public String getCodigo() { return codigo; }
        public String getRequisitoLegal() { return requisitoLegal; }
        public String getComoSeAplica() { return comoSeAplica; }
        public String getPorQueLoAplica() { return porQueLoAplica; }
        public String getFechaEmision() { return fechaEmision; }
        public String getFechaVencimiento() { return fechaVencimiento; }
        public String getFechaProximaRenovacion() { return fechaProximaRenovacion; }
        public String getCantidadArchivos() { return cantidadArchivos; }
    }
}