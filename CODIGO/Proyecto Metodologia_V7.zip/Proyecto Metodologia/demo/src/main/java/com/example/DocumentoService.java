package com.example;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;

public class DocumentoService {
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "sistema_documentos";
    private static final String COLLECTION_NAME = "documentos_legales";
    
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;
    private GridFSBucket gridFSBucket;

    public DocumentoService() {
        connect();
    }

    private void connect() {
        try {
            mongoClient = MongoClients.create(CONNECTION_STRING);
            database = mongoClient.getDatabase(DATABASE_NAME);
            collection = database.getCollection(COLLECTION_NAME);
            gridFSBucket = GridFSBuckets.create(database, "documentos_archivos");
        } catch (Exception e) {
            System.err.println("Error al conectar con MongoDB: " + e.getMessage());
            throw new RuntimeException("No se pudo conectar a la base de datos", e);
        }
    }

    public boolean guardarDocumento(String codigo, String requisitoLegal, String comoSeAplica, 
                                   String porQueLoAplica, LocalDate fechaEmision, 
                                   LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion,
                                   List<File> archivos) {
        try {
            // Verificar si el código ya existe
            if (existeDocumento(codigo)) {
                return false;
            }

            // Subir archivos a GridFS
            List<ObjectId> idsArchivos = new ArrayList<>();
            List<Document> infoArchivos = new ArrayList<>();
            
            if (archivos != null) {
                for (File archivo : archivos) {
                    ObjectId archivoId = subirArchivo(archivo);
                    if (archivoId != null) {
                        idsArchivos.add(archivoId);
                        Document infoArchivo = new Document()
                            .append("archivoId", archivoId)
                            .append("nombreOriginal", archivo.getName())
                            .append("tamaño", archivo.length())
                            .append("fechaSubida", new Date());
                        infoArchivos.add(infoArchivo);
                    }
                }
            }

            Document documento = new Document()
                .append("codigo", codigo)
                .append("requisitoLegal", requisitoLegal)
                .append("comoSeAplica", comoSeAplica)
                .append("porQueLoAplica", porQueLoAplica)
                .append("fechaEmision", java.sql.Date.valueOf(fechaEmision))
                .append("fechaVencimiento", java.sql.Date.valueOf(fechaVencimiento))
                .append("fechaProximaRenovacion", java.sql.Date.valueOf(fechaProximaRenovacion))
                .append("fechaCreacion", new Date())
                .append("fechaModificacion", new Date())
                .append("activo", true)
                .append("archivos", infoArchivos);

            collection.insertOne(documento);
            return true;
        } catch (Exception e) {
            System.err.println("Error al guardar documento: " + e.getMessage());
            return false;
        }
    }

    // Sobrecarga del método original para mantener compatibilidad
    public boolean guardarDocumento(String codigo, String requisitoLegal, String comoSeAplica, 
                                   String porQueLoAplica, LocalDate fechaEmision, 
                                   LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion) {
        return guardarDocumento(codigo, requisitoLegal, comoSeAplica, porQueLoAplica, 
                               fechaEmision, fechaVencimiento, fechaProximaRenovacion, null);
    }

    private ObjectId subirArchivo(File archivo) {
        try (FileInputStream streamArchivo = new FileInputStream(archivo)) {
            GridFSUploadOptions options = new GridFSUploadOptions()
                .metadata(new Document("originalName", archivo.getName())
                         .append("contentType", determinarTipoContenido(archivo.getName())));
            
            return gridFSBucket.uploadFromStream(archivo.getName(), streamArchivo, options);
        } catch (IOException e) {
            System.err.println("Error al subir archivo " + archivo.getName() + ": " + e.getMessage());
            return null;
        }
    }

    private String determinarTipoContenido(String nombreArchivo) {
        String extension = nombreArchivo.substring(nombreArchivo.lastIndexOf('.') + 1).toLowerCase();
        switch (extension) {
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "txt": return "text/plain";
            default: return "application/octet-stream";
        }
    }

    public boolean descargarArchivo(ObjectId archivoId, String rutaDestino) {
        try (FileOutputStream streamDestino = new FileOutputStream(rutaDestino)) {
            gridFSBucket.downloadToStream(archivoId, streamDestino);
            return true;
        } catch (IOException e) {
            System.err.println("Error al descargar archivo: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarArchivo(ObjectId archivoId) {
        try {
            gridFSBucket.delete(archivoId);
            return true;
        } catch (Exception e) {
            System.err.println("Error al eliminar archivo: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarDocumento(String codigo, String requisitoLegal, String comoSeAplica, 
                                      String porQueLoAplica, LocalDate fechaEmision, 
                                      LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion) {
        try {
            Document filtro = new Document("codigo", codigo);
            Document actualizacion = new Document("$set", new Document()
                .append("requisitoLegal", requisitoLegal)
                .append("comoSeAplica", comoSeAplica)
                .append("porQueLoAplica", porQueLoAplica)
                .append("fechaEmision", java.sql.Date.valueOf(fechaEmision))
                .append("fechaVencimiento", java.sql.Date.valueOf(fechaVencimiento))
                .append("fechaProximaRenovacion", java.sql.Date.valueOf(fechaProximaRenovacion))
                .append("fechaModificacion", new Date()));

            return collection.updateOne(filtro, actualizacion).getMatchedCount() > 0;
        } catch (Exception e) {
            System.err.println("Error al actualizar documento: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarDocumento(String codigo) {
        try {
            Document filtro = new Document("codigo", codigo);
            Document actualizacion = new Document("$set", new Document()
                .append("activo", false)
                .append("fechaEliminacion", new Date()));

            return collection.updateOne(filtro, actualizacion).getMatchedCount() > 0;
        } catch (Exception e) {
            System.err.println("Error al eliminar documento: " + e.getMessage());
            return false;
        }
    }

    public Document buscarDocumento(String codigo) {
        try {
            Document filtro = new Document("codigo", codigo).append("activo", true);
            return collection.find(filtro).first();
        } catch (Exception e) {
            System.err.println("Error al buscar documento: " + e.getMessage());
            return null;
        }
    }

    public List<Document> obtenerTodosLosDocumentos() {
        List<Document> documentos = new ArrayList<>();
        try {
            Document filtro = new Document("activo", true);
            try (MongoCursor<Document> cursor = collection.find(filtro).iterator()) {
                while (cursor.hasNext()) {
                    documentos.add(cursor.next());
                }
            }
        } catch (Exception e) {
            System.err.println("Error al obtener documentos: " + e.getMessage());
        }
        return documentos;
    }

    public List<Document> obtenerDocumentosProximosAVencer(int diasAnticipacion) {
        List<Document> documentos = new ArrayList<>();
        try {
            Date fechaLimite = java.sql.Date.valueOf(LocalDate.now().plusDays(diasAnticipacion));
            Document filtro = new Document("activo", true)
                .append("fechaVencimiento", new Document("$lte", fechaLimite))
                .append("fechaVencimiento", new Document("$gte", new Date()));
            
            try (MongoCursor<Document> cursor = collection.find(filtro).iterator()) {
                while (cursor.hasNext()) {
                    documentos.add(cursor.next());
                }
            }
        } catch (Exception e) {
            System.err.println("Error al obtener documentos próximos a vencer: " + e.getMessage());
        }
        return documentos;
    }

    public boolean existeDocumento(String codigo) {
        try {
            Document filtro = new Document("codigo", codigo).append("activo", true);
            return collection.find(filtro).first() != null;
        } catch (Exception e) {
            System.err.println("Error al verificar existencia de documento: " + e.getMessage());
            return false;
        }
    }

    public long contarDocumentos() {
        try {
            return collection.countDocuments(new Document("activo", true));
        } catch (Exception e) {
            System.err.println("Error al contar documentos: " + e.getMessage());
            return 0;
        }
    }

    public void cerrarConexion() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
public boolean actualizarArchivosDocumento(String codigo, List<Document> archivos) {
    try {
        Document filtro = new Document("codigo", codigo);
        Document actualizacion = new Document("$set", new Document()
            .append("archivos", archivos)
            .append("fechaModificacion", new Date()));

        return collection.updateOne(filtro, actualizacion).getMatchedCount() > 0;
    } catch (Exception e) {
        System.err.println("Error al actualizar archivos del documento: " + e.getMessage());
        return false;
    }
}

// Método adicional para agregar un nuevo archivo a un documento existente
public boolean agregarArchivoADocumento(String codigo, File archivo) {
    try {
        // Subir el archivo a GridFS
        ObjectId archivoId = subirArchivo(archivo);
        if (archivoId == null) {
            return false;
        }

        // Crear la información del archivo
        Document infoArchivo = new Document()
            .append("archivoId", archivoId)
            .append("nombreOriginal", archivo.getName())
            .append("tamaño", archivo.length())
            .append("fechaSubida", new Date());

        // Agregar el archivo a la lista existente
        Document filtro = new Document("codigo", codigo);
        Document actualizacion = new Document("$push", new Document("archivos", infoArchivo))
            .append("$set", new Document("fechaModificacion", new Date()));

        return collection.updateOne(filtro, actualizacion).getMatchedCount() > 0;
    } catch (Exception e) {
        System.err.println("Error al agregar archivo al documento: " + e.getMessage());
        return false;
    }
}

    // Método alternativo para obtener información de un archivo específico
    public boolean existeArchivo(ObjectId archivoId) {
        try {
            return gridFSBucket.find(new Document("_id", archivoId)).first() != null;
        } catch (Exception e) {
            System.err.println("Error al verificar existencia del archivo: " + e.getMessage());
            return false;
        }
    }

    // Método para obtener el nombre de un archivo por su ID
    public String obtenerNombreArchivo(ObjectId archivoId) {
        try {
            com.mongodb.client.gridfs.model.GridFSFile archivo = gridFSBucket.find(new Document("_id", archivoId)).first();
            return archivo != null ? archivo.getFilename() : null;
        } catch (Exception e) {
            System.err.println("Error al obtener nombre del archivo: " + e.getMessage());
            return null;
        }
    }
}