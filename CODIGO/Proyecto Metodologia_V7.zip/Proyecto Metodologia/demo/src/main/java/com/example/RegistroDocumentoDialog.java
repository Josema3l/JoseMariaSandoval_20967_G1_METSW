package com.example;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class RegistroDocumentoDialog {
    private final Stage parentStage;
    private final DocumentoService documentoService;
    private List<File> archivosSeleccionados;

    public RegistroDocumentoDialog(Stage parentStage) {
        this.parentStage = parentStage;
        this.documentoService = new DocumentoService();
        this.archivosSeleccionados = new ArrayList<>();
    }

    public void mostrar() {
        Stage registroStage = new Stage();
        registroStage.setTitle("Registrar documento legal");
        Label lblMensaje = new Label();
        TextField txtCodigo = new TextField();
        TextField txtRequisitoLegal = new TextField();
        TextField txtComoSeAplica = new TextField();
        TextField txtPorQueLoAplica = new TextField();
        DatePicker dtpFechaEmision = new DatePicker();
        DatePicker dtpFechaVencimiento = new DatePicker();
        DatePicker dtpFechaProximaRenovacion = new DatePicker();
        
        // Sección para archivos
        Label lblArchivos = new Label("Archivos adjuntos:");
        ListView<String> listViewArchivos = new ListView<>();
        listViewArchivos.setPrefHeight(100);
        
        Button btnSeleccionarArchivos = new Button("Seleccionar archivos");
        btnSeleccionarArchivos.setOnAction(e -> seleccionarArchivos(listViewArchivos));
        
        Button btnEliminarArchivo = new Button("Eliminar seleccionado");
        btnEliminarArchivo.setOnAction(e -> eliminarArchivoSeleccionado(listViewArchivos));
        
        HBox hboxArchivos = new HBox(10, btnSeleccionarArchivos, btnEliminarArchivo);
        hboxArchivos.setAlignment(Pos.CENTER_LEFT);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Código nro:"), 0, 0);
        grid.add(txtCodigo, 1, 0);
        grid.add(new Label("Requisito Legal:"), 0, 1);
        grid.add(txtRequisitoLegal, 1, 1);
        grid.add(new Label("Cómo se aplica:"), 0, 2);
        grid.add(txtComoSeAplica, 1, 2);
        grid.add(new Label("Por qué lo aplica:"), 0, 3);
        grid.add(txtPorQueLoAplica, 1, 3);
        grid.add(new Label("Fecha de emisión:"), 0, 4);
        grid.add(dtpFechaEmision, 1, 4);
        grid.add(new Label("Fecha de vencimiento:"), 0, 5);
        grid.add(dtpFechaVencimiento, 1, 5);
        grid.add(new Label("Fecha próxima de renovación:"), 0, 6);
        grid.add(dtpFechaProximaRenovacion, 1, 6);
        grid.add(lblArchivos, 0, 7);
        grid.add(listViewArchivos, 1, 7);
        grid.add(hboxArchivos, 1, 8);
        grid.add(lblMensaje, 0, 9, 2, 1);

        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(_ -> {
            String codigo = txtCodigo.getText();
            String requisitoLegal = txtRequisitoLegal.getText();
            String comoSeAplica = txtComoSeAplica.getText();
            String porQueLoAplica = txtPorQueLoAplica.getText();
            LocalDate fechaEmision = dtpFechaEmision.getValue();
            LocalDate fechaVencimiento = dtpFechaVencimiento.getValue();
            LocalDate fechaProximaRenovacion = dtpFechaProximaRenovacion.getValue();
            
            if (codigo.isEmpty() || requisitoLegal.isEmpty() || comoSeAplica.isEmpty() || 
                porQueLoAplica.isEmpty() || fechaEmision == null || fechaVencimiento == null || 
                fechaProximaRenovacion == null) {
                DialogUtils.mostrarAviso(grid, "Por favor, complete todos los campos.", false, null);
                return;
            }
            
            if (fechaVencimiento.isBefore(fechaEmision) || fechaProximaRenovacion.isBefore(fechaEmision)) {
                DialogUtils.mostrarAviso(grid, "La fecha de vencimiento y la fecha próxima de renovación no pueden ser anteriores a la fecha de emisión.", false, null);
                return;
            }
            
            try {
                // Verificar si el código ya existe
                if (documentoService.existeDocumento(codigo)) {
                    DialogUtils.mostrarAviso(grid, "Ya existe un documento con este código.", false, null);
                    return;
                }
                
                // Guardar documento usando el servicio
                boolean guardado = documentoService.guardarDocumento(
                    codigo, requisitoLegal, comoSeAplica, porQueLoAplica,
                    fechaEmision, fechaVencimiento, fechaProximaRenovacion,
                    archivosSeleccionados
                );
                
                if (guardado) {
                    DialogUtils.mostrarAviso(grid, "Documento registrado exitosamente.", true, () -> {
                        txtCodigo.clear();
                        txtRequisitoLegal.clear();
                        txtComoSeAplica.clear();
                        txtPorQueLoAplica.clear();
                        dtpFechaEmision.setValue(null);
                        dtpFechaVencimiento.setValue(null);
                        dtpFechaProximaRenovacion.setValue(null);
                        archivosSeleccionados.clear();
                        listViewArchivos.getItems().clear();
                    });
                } else {
                    DialogUtils.mostrarAviso(grid, "Error al guardar el documento.", false, null);
                }
                
            } catch (Exception ex) {
                DialogUtils.mostrarAviso(grid, "Error al guardar el documento: " + ex.getMessage(), false, null);
                ex.printStackTrace();
            }
        });

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(e -> registroStage.close());
        
        HBox hboxBotones = new HBox(10, btnGuardar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        grid.add(hboxBotones, 0, 10, 2, 1);

        Scene scene = new Scene(grid, 650, 500);
        registroStage.setScene(scene);
        registroStage.initOwner(parentStage);
        registroStage.show();
        
        // Cerrar conexión cuando se cierre la ventana
        registroStage.setOnCloseRequest(e -> cerrarConexion());
    }
    
    private void seleccionarArchivos(ListView<String> listViewArchivos) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivos");
        
        // Configurar filtros de archivo
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Documentos Excel", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp"),
            new FileChooser.ExtensionFilter("Archivos de texto", "*.txt", "*.rtf")
        );
        
        List<File> archivos = fileChooser.showOpenMultipleDialog(parentStage);
        if (archivos != null) {
            for (File archivo : archivos) {
                if (!archivosSeleccionados.contains(archivo)) {
                    archivosSeleccionados.add(archivo);
                    listViewArchivos.getItems().add(archivo.getName() + " (" + formatFileSize(archivo.length()) + ")");
                }
            }
        }
    }
    
    private void eliminarArchivoSeleccionado(ListView<String> listViewArchivos) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            archivosSeleccionados.remove(selectedIndex);
            listViewArchivos.getItems().remove(selectedIndex);
        }
    }
    
    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024.0));
        return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
    }
    
    public void cerrarConexion() {
        if (documentoService != null) {
            documentoService.cerrarConexion();
        }
    }
}