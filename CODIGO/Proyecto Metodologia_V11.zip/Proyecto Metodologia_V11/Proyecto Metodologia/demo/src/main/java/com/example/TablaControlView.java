package com.example;

import java.util.List;

import org.bson.Document;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TablaControlView {
    private final PanelController panelController;
    private final DocumentoService documentoService;

    public TablaControlView(PanelController panelController) {
        this.panelController = panelController;
        this.documentoService = new DocumentoService();
    }

    public void mostrar() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("Control de documentos y registro");
        
        Button btnRegistrar = new Button("Registrar documento");
        btnRegistrar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20 10 20;");
        
        Button btnVer = new Button("Ver documentos registrados");
        btnVer.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20 10 20;");
        
        VBox vbox = new VBox(20, btnRegistrar, btnVer);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPrefSize(400, 200);
        
        Scene scene = new Scene(vbox);
        tablaStage.setScene(scene);
        tablaStage.show();

        btnRegistrar.setOnAction(_ -> {
            tablaStage.close();
            panelController.mostrarFormularioRegistro();
        });
        
        btnVer.setOnAction(_ -> {
            tablaStage.close();
            mostrarDocumentosRegistrados();
        });
        
        // Cerrar conexión cuando se cierre la ventana
        tablaStage.setOnCloseRequest(e -> cerrarConexion());
    }

    public void mostrarDocumentosRegistrados() {
        Stage docsStage = new Stage();
        docsStage.setTitle("Documentos registrados");
        
        // Crear la tabla
        TableView<DocumentoTableRow> table = new TableView<>();
        table.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        TableColumn<DocumentoTableRow, String> colVersion = new TableColumn<>("Versión");
        colVersion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getVersion()));
        colVersion.setPrefWidth(100);

        TableColumn<DocumentoTableRow, String> colCodigo = new TableColumn<>("Código");
        colCodigo.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCodigoDoc()));
        colCodigo.setPrefWidth(100);
        
        TableColumn<DocumentoTableRow, String> colUsuario = new TableColumn<>("Usuario");
        colUsuario.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getUsuario()));
        colUsuario.setPrefWidth(150);
        
        // Configurar columnas
        TableColumn<DocumentoTableRow, String> colnombreDoc = new TableColumn<>("Nombre del documento");
        colnombreDoc.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNombreDoc()));
        colnombreDoc.setPrefWidth(120);
        
        TableColumn<DocumentoTableRow, String> colFechaEmision = new TableColumn<>("Fecha de emisión");
        colFechaEmision.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaEmision()));
        colFechaEmision.setPrefWidth(130);
        
        TableColumn<DocumentoTableRow, String> colFechaVencimiento = new TableColumn<>("Fecha de vencimiento");
        colFechaVencimiento.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaVencimiento()));
        colFechaVencimiento.setPrefWidth(140);
        
        TableColumn<DocumentoTableRow, String> colFechaRenovacion = new TableColumn<>("Fecha próxima renovación");
        colFechaRenovacion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaProximaRenovacion()));
        colFechaRenovacion.setPrefWidth(160);

        TableColumn<DocumentoTableRow, String> colMotivodeModificacion = new TableColumn<>("Motivo de modificación");
        colMotivodeModificacion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMotivodeModificacion()));
        colMotivodeModificacion.setPrefWidth(200);
        
        TableColumn<DocumentoTableRow, String> colArchivos = new TableColumn<>("Archivos");
        colArchivos.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCantidadArchivos()));
        colArchivos.setPrefWidth(80);

        table.getColumns().addAll(colVersion,colCodigo, colUsuario, colnombreDoc, colFechaEmision, colFechaVencimiento, colFechaRenovacion, colMotivodeModificacion, colArchivos);

        // Crear menú contextual
        ContextMenu contextMenu = new ContextMenu();
        MenuItem menuGestionarArchivos = new MenuItem("Gestionar archivos");
        MenuItem menuEliminarDocumento = new MenuItem("Eliminar documento");
        
        menuGestionarArchivos.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                ArchivoManagerDialog archivoManager = new ArchivoManagerDialog(docsStage, selected.getCodigoDoc());
                archivoManager.mostrar();
            }
        });
        
        menuEliminarDocumento.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarDocumento(selected.getCodigoDoc(), table);
            }
        });
        
        contextMenu.getItems().addAll(menuGestionarArchivos, menuEliminarDocumento);
        table.setContextMenu(contextMenu);
        
        // Cargar datos
        cargarDocumentos(table);
        
        // Botones
        Button btnGestionarArchivos = new Button("Gestionar archivos");
        btnGestionarArchivos.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white;");
        btnGestionarArchivos.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                ArchivoManagerDialog archivoManager = new ArchivoManagerDialog(docsStage, selected.getCodigoDoc());
                archivoManager.mostrar();
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un documento para gestionar sus archivos.", false, null);
            }
        });
        
        Button btnActualizar = new Button("Actualizar");
        btnActualizar.setOnAction(e -> cargarDocumentos(table));
        
        Button btnEliminar = new Button("Eliminar documento");
        btnEliminar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        btnEliminar.setOnAction(e -> {
            DocumentoTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarDocumento(selected.getCodigoDoc(), table);
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un documento para eliminar.", false, null);
            }
        });
        
        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setOnAction(e -> docsStage.close());
        
        HBox hboxBotones = new HBox(10, btnGestionarArchivos, btnActualizar, btnEliminar, btnCerrar);
        hboxBotones.setAlignment(Pos.CENTER);
        
        VBox vbox = new VBox(10, table, hboxBotones);
        vbox.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(vbox, 1200, 600);
        docsStage.setScene(scene);
        docsStage.show();
        
        // Cerrar conexión cuando se cierre la ventana
        docsStage.setOnCloseRequest(e -> cerrarConexion());
    }
    
    private void cargarDocumentos(TableView<DocumentoTableRow> table) {
        try {
            List<Document> documentos = documentoService.obtenerTodosLosDocumentos();
            ObservableList<DocumentoTableRow> rows = FXCollections.observableArrayList();
            
            for (Document doc : documentos) {
                DocumentoTableRow row = new DocumentoTableRow(
                    obtenerStringSeguro(doc, "version"),
                    obtenerStringSeguro(doc, "codigo"),
                    obtenerStringSeguro(doc, "usuario"),
                    obtenerStringSeguro(doc, "nombreDocumento"),
                    obtenerFechaComoString(doc, "fechaEmision"),
                    obtenerFechaComoString(doc, "fechaVencimiento"),
                    obtenerFechaComoString(doc, "fechaProximaRenovacion"),
                    obtenerStringSeguro(doc, "motivodeModificacion"),
                    obtenerCantidadArchivos(doc)
                );
                rows.add(row);
            }
            
            table.setItems(rows);
        } catch (Exception e) {
            DialogUtils.mostrarAviso(null, "Error al cargar los documentos: " + e.getMessage(), false, null);
            e.printStackTrace();
        }
    }
    
    private String obtenerStringSeguro(Document doc, String campo) {
        Object valor = doc.get(campo);
        return valor != null ? valor.toString() : "";
    }
    
    private String obtenerFechaComoString(Document doc, String campo) {
        Object fecha = doc.get(campo);
        if (fecha == null) {
            return "";
        }
        // Permitir 'nv' o 'NV' como 'No vence' solo para vencimiento y próxima renovación
        if (fecha instanceof String) {
            String fechaStr = ((String) fecha).trim();
            if (fechaStr.equalsIgnoreCase("nv")) {
                return "No Vence";
            }
        }
        // Si es una fecha de Java (Date)
        if (fecha instanceof java.util.Date) {
            java.util.Date date = (java.util.Date) fecha;
            java.time.LocalDate localDate = date.toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();
            return localDate.toString();
        }
        // Si es un LocalDate
        if (fecha instanceof java.time.LocalDate) {
            return fecha.toString();
        }
        // Si es un string
        return fecha.toString();
    }
    
    private String obtenerCantidadArchivos(Document documento) {
        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        if (archivos != null) {
            return String.valueOf(archivos.size());
        }
        return "0";
    }
    
    private void eliminarDocumento(String codigoDoc, TableView<DocumentoTableRow> table) {
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Confirmar eliminación");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText("¿Estás seguro de que deseas eliminar el documento con código '" + codigoDoc + "'?\n" +
                                   "Esta acción también eliminará todos los archivos asociados.");
        
        if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            try {
                if (documentoService.eliminarDocumento(codigoDoc)) {
                    cargarDocumentos(table); // Recargar la tabla
                    DialogUtils.mostrarAviso(null, "Documento eliminado exitosamente.", true, null);
                } else {
                    DialogUtils.mostrarAviso(null, "Error al eliminar el documento.", false, null);
                }
            } catch (Exception e) {
                DialogUtils.mostrarAviso(null, "Error al eliminar el documento: " + e.getMessage(), false, null);
                e.printStackTrace();
            }
        }
    }
    
    public void cerrarConexion() {
        if (documentoService != null) {
            documentoService.cerrarConexion();
        }
    }
    
    // Método estático para mantener compatibilidad con PanelController
    public static void mostrarDocumentosRegistradosEstatico() {
        TablaControlView tablaControlView = new TablaControlView(null);
        tablaControlView.mostrarDocumentosRegistrados();
    }

        // Clase interna para representar una fila de la tabla
    public static class DocumentoTableRow {
        
        private final String version;
        private final String codigoDoc;
        private final String usuario;
        private final String nombreDoc;
        private final String fechaEmision;
        private final String fechaVencimiento;
        private final String fechaProximaRenovacion;
        private final String motivodeModificacion;
        private final String cantidadArchivos;

        public DocumentoTableRow(String version, String codigoDoc, String usuario, String nombreDoc, String fechaEmision, 
                               String fechaVencimiento, String fechaProximaRenovacion, String cantidadArchivos, String motivodeModificacion) {
            this.version = version;
            this.codigoDoc = codigoDoc;
            this.usuario = usuario;
            this.nombreDoc = nombreDoc;
            this.fechaEmision = fechaEmision;
            this.fechaVencimiento = fechaVencimiento;
            this.fechaProximaRenovacion = fechaProximaRenovacion;
            this.motivodeModificacion = motivodeModificacion;
            this.cantidadArchivos = cantidadArchivos;
        }

        public String getVersion() {
            return version;
        }

        public String getUsuario() {
            return usuario;
        }
        
        public String getNombreDoc() { 
            return nombreDoc; 
        }
        
        public String getFechaEmision() { 
            return fechaEmision; 
        }
        
        public String getFechaVencimiento() { 
            return fechaVencimiento; 
        }
        
        public String getFechaProximaRenovacion() { 
            return fechaProximaRenovacion; 
        }
        
        public String getCantidadArchivos() { 
            return cantidadArchivos; 
        }

        public String getCodigoDoc() { 
            return codigoDoc;
        }

        public String getMotivodeModificacion() {
            return motivodeModificacion;
        }
    }
}