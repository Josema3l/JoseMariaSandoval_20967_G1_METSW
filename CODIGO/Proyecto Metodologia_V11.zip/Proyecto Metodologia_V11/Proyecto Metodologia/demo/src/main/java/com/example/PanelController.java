package com.example;

import java.time.LocalDate;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PanelController {
    private final UsuarioService usuarioService;
    private final DocumentoService documentoService = new DocumentoService();
    // private Stage mainStage; // removed duplicate

    public PanelController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // setMainStage is defined only once at the top of the class

    public void mostrarPantallaPanel(Stage stage, String usuario, String rol) {
        Button btnMapa = new Button("Mapa de Procesos");
        btnMapa.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        Button btnTabla = new Button("Control de documentos y \n\t      registro");
        btnTabla.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        Button btnCerrar = new Button("Cerrar sesión");
        btnCerrar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");

        // Botón para correo personalizado
        Button btnCorreoPersonalizado = new Button("Correo personalizado");
        btnCorreoPersonalizado.setStyle("-fx-background-color: #8e44ad; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        btnCorreoPersonalizado.setOnAction(_ -> {
            new CorreoPersonalizadoDialog().mostrar(stage);
        });
        // Botones de cambio de usuario y contraseña eliminados (ahora solo en menú hamburguesa)
        Button btnEnviarRecordatorios = new Button("Enviar recordatorios");
        btnEnviarRecordatorios.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        Label lblMensaje = new Label();
        lblMensaje.setStyle("-fx-font-size: 15px; -fx-text-fill: #8e44ad; -fx-font-weight: bold;");

        // Solo el menú hamburguesa, sin topBar visible
        MenuButton menuHamburguesa = new MenuButton();
        menuHamburguesa.setText("");
        menuHamburguesa.setStyle("-fx-background-color: transparent; -fx-padding: 0; -fx-border-width: 0;");
        javafx.scene.shape.SVGPath iconoHamburguesa = new javafx.scene.shape.SVGPath();
        iconoHamburguesa.setContent("M3 7h18M3 12h18M3 17h18");
        iconoHamburguesa.setStroke(javafx.scene.paint.Color.web("#2c3e50"));
        iconoHamburguesa.setStrokeWidth(3);
        iconoHamburguesa.setFill(javafx.scene.paint.Color.TRANSPARENT);
        iconoHamburguesa.setScaleX(1.5);
        iconoHamburguesa.setScaleY(1.5);
        menuHamburguesa.setGraphic(iconoHamburguesa);
        menuHamburguesa.setPrefSize(48, 48);
        menuHamburguesa.setPopupSide(javafx.geometry.Side.BOTTOM);
        MenuItem cambiarUsuario = new MenuItem("Cambiar usuario");
        cambiarUsuario.setOnAction(_ -> {
            new CambioUsuarioDialog(usuarioService, usuario, rol, stage).mostrar();
        });
        MenuItem cambiarContrasena = new MenuItem("Cambiar contraseña");
        cambiarContrasena.setOnAction(_ -> {
            new CambioContrasenaDialog(usuarioService, usuario, rol, stage).mostrar();
        });
        if (rol.equalsIgnoreCase("Administradora") || rol.equalsIgnoreCase("Tester")) {
            MenuItem crearUsuario = new MenuItem("Crear nuevo usuario");
            crearUsuario.setOnAction(_ -> mostrarDialogoCrearUsuario(lblMensaje));
            menuHamburguesa.getItems().addAll(crearUsuario, cambiarUsuario, cambiarContrasena);
        } else if (rol.equalsIgnoreCase("Cliente")) {
            menuHamburguesa.getItems().addAll(cambiarUsuario, cambiarContrasena);
        }

        StackPane panelCentral = new StackPane();
        // Fondo degradado para el panel central
        String gradient = rol.equals("Administradora")
            ? "-fx-background-color: linear-gradient(to bottom right, #e0eafc, #cfdef3, #f9f9f9);"
            : "-fx-background-color: linear-gradient(to bottom right, #b2fefa, #e0c3fc);";
        panelCentral.setStyle(gradient);

        Label lblBienvenidaCentral = new Label("Bienvenido " + usuario);
        lblBienvenidaCentral.setStyle(
        "-fx-font-family: 'Lucida Handwriting', 'Bradley Hand ITC', cursive; " +
        "-fx-font-size: 100px; " +
        "-fx-text-fill: #2c3e50;"
        );

        panelCentral.getChildren().add(lblBienvenidaCentral);
        StackPane.setAlignment(lblBienvenidaCentral, Pos.CENTER);
        
        VBox vboxMenu = new VBox();
        vboxMenu.setSpacing(30);
        // Solo Administradora ve el botón de recordatorios
        if (rol.equals("Administradora")) {
            vboxMenu.getChildren().add(btnEnviarRecordatorios);
            btnEnviarRecordatorios.setOnAction(_ -> revisarYEnviarRecordatorios(lblMensaje));
        }
        vboxMenu.getChildren().addAll(btnMapa, btnTabla, btnCorreoPersonalizado, btnCerrar, lblMensaje);
        vboxMenu.setAlignment(Pos.TOP_CENTER);
        vboxMenu.setPrefWidth(270);
        vboxMenu.setStyle("-fx-background-color: linear-gradient(to bottom, #f8ffae, #43c6ac); -fx-border-color: #2980b9; -fx-border-width: 0 2px 0 0;");

        // --- Botón Cerrar Mapa (siempre presente pero oculto, se muestra solo con el mapa) ---
        Button btnCerrarMapaLateral = new Button("Cerrar mapa");
        btnCerrarMapaLateral.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8; -fx-padding: 8 18 8 18;");
        btnCerrarMapaLateral.setVisible(false);
        btnCerrarMapaLateral.setManaged(false);
        // Espaciador para empujar el botón hacia abajo
        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        VBox.setVgrow(spacer, javafx.scene.layout.Priority.ALWAYS);
        vboxMenu.getChildren().addAll(spacer, btnCerrarMapaLateral);

        btnCerrar.setOnAction(_ -> new LoginController().mostrarPantallaLogin(stage));
        // Acciones de cambio de usuario y contraseña eliminadas del menú lateral (ahora solo en menú hamburguesa)
        btnMapa.setOnAction(_ -> {
            if (rol.equals("Administradora")) {
                // Quitar mensaje antiguo y usar aviso moderno
                panelCentral.getChildren().clear();
                try {
                    Image mapaImg = new Image(getClass().getResourceAsStream("/mapa_procesos.png"));
                    ImageView mapaView = new ImageView(mapaImg);
                    mapaView.setPreserveRatio(true);
                    mapaView.setFitWidth(1250);
                    mapaView.setStyle("-fx-effect: dropshadow(gaussian, #34495e, 30, 0.3, 0, 0);");

                    // --- Botones sobre el mapa (no tocar) ---
                    String botonMapaBase = "-fx-background-radius: 15; -fx-font-weight: bold; -fx-font-size: 13px; -fx-border-width: 2; -fx-border-radius: 15;";
                    Button btnSistemasGestion = new Button("");
                    btnSistemasGestion.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;" + botonMapaBase);
                    btnSistemasGestion.setPrefSize(85, 75);
                    btnSistemasGestion.setLayoutX(805);
                    btnSistemasGestion.setLayoutY(190);
                    btnSistemasGestion.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/MEJORA CONTINUA", lblMensaje));
                    Button btnGestionComercial = new Button("Gestión de Comercialización");
                    btnGestionComercial.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnGestionComercial.setPrefSize(80, 90);
                    btnGestionComercial.setLayoutX(310);
                    btnGestionComercial.setLayoutY(455);
                    btnGestionComercial.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/GESTION DE COMERCIALIZACION", lblMensaje));
                    Button btnAnalisis = new Button("Análisis Vulnerabilidad");
                    btnAnalisis.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnAnalisis.setPrefSize(150, 120);
                    btnAnalisis.setLayoutX(440);
                    btnAnalisis.setLayoutY(425);
                    btnAnalisis.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/ANALISIS VULNERABILIDAD", lblMensaje));
                    Button btnInduccion = new Button("Inducción Vigilante");
                    btnInduccion.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnInduccion.setPrefSize(105, 120);
                    btnInduccion.setLayoutX(605);
                    btnInduccion.setLayoutY(425);
                    btnInduccion.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/INDUCCION VIGILANTE", lblMensaje));
                    Button btnOperaciones = new Button("Operaciones Fija - Móvil");
                    btnOperaciones.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnOperaciones.setPrefSize(125, 120);
                    btnOperaciones.setLayoutX(725);
                    btnOperaciones.setLayoutY(425);
                    btnOperaciones.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/OPERACIONES FIJA-MOVIL", lblMensaje));
                    Button btnSupervision = new Button("Supervisión Control");
                    btnSupervision.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnSupervision.setPrefSize(118, 120);
                    btnSupervision.setLayoutX(860);
                    btnSupervision.setLayoutY(425);
                    btnSupervision.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SUPERVISION CONTROL", lblMensaje));
                    Button btnSatisfaccion = new Button("Satisfacción al Cliente");
                    btnSatisfaccion.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnSatisfaccion.setPrefSize(45, 65);
                    btnSatisfaccion.setLayoutX(1060);
                    btnSatisfaccion.setLayoutY(450);
                    btnSatisfaccion.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SATISFACCION AL CLIENTE", lblMensaje));
                    Button btnAdmin1 = new Button("A1");
                    btnAdmin1.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnAdmin1.setPrefSize(65, 70);
                    btnAdmin1.setLayoutX(145);
                    btnAdmin1.setLayoutY(685);
                    btnAdmin1.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/CONTABLE", lblMensaje));
                    Button btnAdmin2 = new Button("A2");
                    btnAdmin2.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnAdmin2.setPrefSize(85, 70);
                    btnAdmin2.setLayoutX(225);
                    btnAdmin2.setLayoutY(685);
                    btnAdmin2.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/ADQUISICIONES", lblMensaje));
                    Button btnAdmin3 = new Button("A3");
                    btnAdmin3.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnAdmin3.setPrefSize(63, 85);
                    btnAdmin3.setLayoutX(320);
                    btnAdmin3.setLayoutY(685);
                    btnAdmin3.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SEGURIDAD FISICA", lblMensaje));
                    Button btnAdmin4 = new Button("A4");
                    btnAdmin4.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnAdmin4.setPrefSize(60, 70);
                    btnAdmin4.setLayoutX(400);
                    btnAdmin4.setLayoutY(685);
                    btnAdmin4.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/LOGISTICA", lblMensaje));
                    Button btnTalento1 = new Button("T1");
                    btnTalento1.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnTalento1.setPrefSize(115, 70);
                    btnTalento1.setLayoutX(585);
                    btnTalento1.setLayoutY(700);
                    btnTalento1.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/CONTRATACION", lblMensaje));
                    Button btnTalento2 = new Button("T2");
                    btnTalento2.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnTalento2.setPrefSize(130, 70);
                    btnTalento2.setLayoutX(715);
                    btnTalento2.setLayoutY(700);
                    btnTalento2.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/ADMINISTRACION", lblMensaje));
                    Button btnTalento3 = new Button("T3");
                    btnTalento3.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnTalento3.setPrefSize(135, 70);
                    btnTalento3.setLayoutX(850);
                    btnTalento3.setLayoutY(700);
                    btnTalento3.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/DESVINCULACION", lblMensaje));
                    Button btnTalento4 = new Button("T4");
                    btnTalento4.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnTalento4.setPrefSize(110, 70);
                    btnTalento4.setLayoutX(990);
                    btnTalento4.setLayoutY(700);
                    btnTalento4.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/CAPACITACION", lblMensaje));
                    Button btnTalento5 = new Button("T5");
                    btnTalento5.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnTalento5.setPrefSize(90, 70);
                    btnTalento5.setLayoutX(480);
                    btnTalento5.setLayoutY(700);
                    btnTalento5.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SELECCION", lblMensaje));
                    Button btnGestionIT = new Button("Gestión de IT");
                    btnGestionIT.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnGestionIT.setPrefSize(60, 70);
                    btnGestionIT.setLayoutX(1140);
                    btnGestionIT.setLayoutY(700);
                    btnGestionIT.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/GESTION IT", lblMensaje));
                    Button btnDireccionEstrategica = new Button("DIRECCION ESTRATEGICA");
                    btnDireccionEstrategica.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnDireccionEstrategica.setPrefSize(100, 75);
                    btnDireccionEstrategica.setLayoutX(300);
                    btnDireccionEstrategica.setLayoutY(190);
                    btnDireccionEstrategica.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/DIRECCION ESTRATEGICA", lblMensaje));
                    Button btnRequisitosLegales = new Button("REQUISITOS LEGALES");
                    btnRequisitosLegales.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnRequisitosLegales.setPrefSize(90, 75);
                    btnRequisitosLegales.setLayoutX(425);
                    btnRequisitosLegales.setLayoutY(190);
                    btnRequisitosLegales.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/REQUISITOS LEGALES", lblMensaje));
                    Button btnFirmaContrato = new Button("FIRMA CONTRATO");
                    btnFirmaContrato.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnFirmaContrato.setPrefSize(82, 75);
                    btnFirmaContrato.setLayoutX(558);
                    btnFirmaContrato.setLayoutY(190);
                    btnFirmaContrato.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/FIRMA CONTRATO", lblMensaje));
                    Button btnNecesidadesPartes = new Button("NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS");
                    btnNecesidadesPartes.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnNecesidadesPartes.setPrefSize(100, 140);
                    btnNecesidadesPartes.setLayoutX(17);
                    btnNecesidadesPartes.setLayoutY(400);
                    btnNecesidadesPartes.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS", lblMensaje));

                    Pane overlay = new Pane();
                    overlay.setPickOnBounds(false);
                    overlay.getChildren().addAll(
                        mapaView,
                        btnDireccionEstrategica, btnRequisitosLegales, btnFirmaContrato, btnNecesidadesPartes,
                        btnSistemasGestion,
                        btnGestionComercial, btnAnalisis, btnInduccion, btnOperaciones, btnSupervision, btnSatisfaccion,
                        btnAdmin1, btnAdmin2, btnAdmin3, btnAdmin4,
                        btnTalento1, btnTalento2, btnTalento3, btnTalento4, btnTalento5,
                        btnGestionIT
                    );
                    panelCentral.getChildren().add(overlay);
                    // Mostrar botón lateral para cerrar mapa
                    btnCerrarMapaLateral.setVisible(true);
                    btnCerrarMapaLateral.setManaged(true);
                    btnCerrarMapaLateral.setOnAction(_ -> {
                        panelCentral.getChildren().clear();
                        btnCerrarMapaLateral.setVisible(false);
                        btnCerrarMapaLateral.setManaged(false);

                        panelCentral.getChildren().add(lblBienvenidaCentral); // Volver al mensaje de bienvenida
                        StackPane.setAlignment(lblBienvenidaCentral, Pos.CENTER);
                    });
                } catch (Exception ex) {
                    DialogUtils.mostrarAviso(panelCentral, "No se pudo cargar el mapa de procesos.", false, null);
                }
            } else {
                DialogUtils.mostrarAviso(panelCentral, "Acceso al mapa de procesos restringido.", false, null);
                panelCentral.getChildren().clear();
                btnCerrarMapaLateral.setVisible(false);
                btnCerrarMapaLateral.setManaged(false);
                panelCentral.getChildren().add(lblBienvenidaCentral); // Volver al mensaje de bienvenida
                StackPane.setAlignment(lblBienvenidaCentral, Pos.CENTER);
            }
        });
        btnTabla.setOnAction(_ -> {
            mostrarVentanaTablaControl();

            panelCentral.getChildren().add(lblBienvenidaCentral); // Volver al mensaje de bienvenida
            StackPane.setAlignment(lblBienvenidaCentral, Pos.CENTER);
        });

        BorderPane root = new BorderPane();
        root.setLeft(vboxMenu);
        root.setCenter(panelCentral);
        // Coloca el menú hamburguesa en la esquina superior izquierda, sin barra blanca ni padding
        StackPane topStack = new StackPane(menuHamburguesa);
        topStack.setStyle("-fx-background-color: transparent; -fx-padding: 0; -fx-border-width: 0;");
        topStack.setAlignment(Pos.TOP_LEFT);
        // Elimina cualquier padding/margin del BorderPane
        BorderPane.setMargin(topStack, javafx.geometry.Insets.EMPTY);
        root.setTop(topStack);

        Scene scene = new Scene(root);
        stage.setTitle("Panel Principal");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();

        // Los recordatorios solo se envían cuando se presiona el botón, no al iniciar la app
    }

    private Stage mainStage;

    private void mostrarDialogoCrearUsuario(Label lblMensaje) {
        new CrearUsuarioDialog(usuarioService, (Stage) lblMensaje.getScene().getWindow()).mostrar(lblMensaje);
    }

    
private void abrirCarpeta(String folderPath, Label lblMensaje) {
    try {
        java.io.File carpeta = new java.io.File(folderPath);
        
        // Verificar si la carpeta existe
        if (!carpeta.exists()) {
            // Crear la carpeta y todas las carpetas padre necesarias
            boolean creada = carpeta.mkdirs();
            if (creada) {
                lblMensaje.setText("Carpeta creada exitosamente: " + folderPath);
                lblMensaje.setStyle("-fx-font-size: 15px; -fx-text-fill: #27ae60; -fx-font-weight: bold;");
            } else {
                lblMensaje.setText("No se pudo crear la carpeta: " + folderPath);
                lblMensaje.setStyle("-fx-font-size: 15px; -fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                return; // Salir si no se pudo crear
            }
        }
        
        // Intentar abrir la carpeta
        java.awt.Desktop.getDesktop().open(carpeta);
        
        // Si llegamos aquí, la carpeta se abrió exitosamente
        if (carpeta.exists()) {
            lblMensaje.setText("Carpeta abierta: " + carpeta.getName());
            lblMensaje.setStyle("-fx-font-size: 15px; -fx-text-fill: #2980b9; -fx-font-weight: bold;");
        }
        
    } catch (Exception ex) {
        lblMensaje.setText("Error al abrir/crear la carpeta: " + ex.getMessage());
        lblMensaje.setStyle("-fx-font-size: 15px; -fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        ex.printStackTrace();
    }
}

    // Nueva ventana para Tabla de control
    private void mostrarVentanaTablaControl() {
        new TablaControlView(this).mostrar();
    }

    // Mostrar documentos registrados en una tabla
    public void mostrarDocumentosRegistrados() {
        // Modularizado: ahora en TablaControlView
        TablaControlView.mostrarDocumentosRegistradosEstatico();
    }

    // Mostrar formulario de registro de documento
    public void mostrarFormularioRegistro() {
        new RegistroDocumentoDialog(mainStage).mostrar();
    }

    // Set the main stage for dialog ownership
    public void setMainStage(Stage stage) {
        this.mainStage = stage;
    }

    private void revisarYEnviarRecordatorios(Label lblMensaje) {
        // Leer documentos desde MongoDB y enviar recordatorios en un hilo en segundo plano
        new Thread(() -> {
            boolean huboError = false;
            StringBuilder resultado = new StringBuilder();
            try {
                java.util.List<org.bson.Document> documentos = documentoService.obtenerTodosLosDocumentos();
                int enviados = 0;
                for (org.bson.Document doc : documentos) {
                    String usuario = doc.getString("usuario");
                    String nombreDocumento = doc.getString("nombreDocumento");
                    Object fechaEmisionObj = doc.get("fechaEmision");
                    Object fechaVencimientoObj = doc.get("fechaVencimiento");
                    Object fechaProximaRenovacionObj = doc.get("fechaProximaRenovacion");

                    LocalDate fechaEmision = null;
                    LocalDate fechaVencimiento = null;
                    LocalDate fechaProximaRenovacion = null;
                    try {
                        if (fechaEmisionObj instanceof java.util.Date) {
                            fechaEmision = ((java.util.Date) fechaEmisionObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaEmisionObj instanceof String && !"NV".equals(fechaEmisionObj)) {
                            fechaEmision = LocalDate.parse((String) fechaEmisionObj);
                        }
                        if (fechaVencimientoObj instanceof java.util.Date) {
                            fechaVencimiento = ((java.util.Date) fechaVencimientoObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaVencimientoObj instanceof String && !"NV".equals(fechaVencimientoObj)) {
                            fechaVencimiento = LocalDate.parse((String) fechaVencimientoObj);
                        }
                        if (fechaProximaRenovacionObj instanceof java.util.Date) {
                            fechaProximaRenovacion = ((java.util.Date) fechaProximaRenovacionObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaProximaRenovacionObj instanceof String && !"NV".equals(fechaProximaRenovacionObj)) {
                            fechaProximaRenovacion = LocalDate.parse((String) fechaProximaRenovacionObj);
                        }
                    } catch (Exception ex) {
                        System.err.println("Documento ignorado por fecha inválida: " + nombreDocumento);
                        huboError = true;
                        continue;
                    }
                    
                    if ("NV".equals(fechaVencimientoObj) || "NV".equals(fechaProximaRenovacionObj)) {
                        continue;
                    }
                    
                    if (fechaProximaRenovacion != null && fechaVencimiento != null &&
                        !fechaProximaRenovacion.isAfter(LocalDate.now()) &&
                        !fechaVencimiento.isBefore(LocalDate.now())) {
                        boolean exito = enviarRecordatorio(usuario, nombreDocumento, fechaEmision, fechaVencimiento, fechaProximaRenovacion, lblMensaje);
                        if (!exito) huboError = true;
                        enviados++;
                    }
                }
                if (!huboError) {
                    resultado.append("Recordatorios enviados correctamente (" + enviados + " documentos para renovar).");
                } else {
                    resultado.append("Algunos documentos fueron ignorados por formato de fecha inválido.");
                }
            } catch (Exception e) {
                resultado.append("Error al revisar documentos: " + e.getMessage());
                e.printStackTrace();
            }
            // Mostrar aviso emergente en vez de solo debajo de los botones
            javafx.application.Platform.runLater(() -> {
                DialogUtils.mostrarAviso(null, resultado.toString(), true, null);
            });
        }).start();
    }

    private boolean enviarRecordatorio(String Usuario,String nombreDocumento, LocalDate fechaEmision, LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, Label lblMensaje) {
        // Configuración del correo
        String remitente = "santy.rojas.2005.santylol@gmail.com"; // Cambia por tu correo
        String password = "mtxxorlkbnpwjdkt"; // Cambia por tu contraseña de aplicación
        String destinatario = "josema19082005@gmail.com"; // Cambia por el destinatario
        String asunto = "Recordatorio de renovación de documento";
        String cuerpo = "Recordatorio: El documento de nombre " + nombreDocumento + " compartido por el usuario '" + Usuario + "' tiene fecha de renovación próxima o vencida."
                + "\nFecha de emisión: " + fechaEmision
                + "\nFecha de vencimiento: " + fechaVencimiento
                + "\nFecha próxima de renovación: " + fechaProximaRenovacion;

        boolean exito = CorreoUtils.enviarRecordatorio(remitente, password, destinatario, asunto, cuerpo);
        if (exito) {
            lblMensaje.setText("Correo enviado correctamente a " + destinatario);
        } else {
            lblMensaje.setText("No se pudo enviar el correo a " + destinatario);
        }
        return exito;
    }
}
