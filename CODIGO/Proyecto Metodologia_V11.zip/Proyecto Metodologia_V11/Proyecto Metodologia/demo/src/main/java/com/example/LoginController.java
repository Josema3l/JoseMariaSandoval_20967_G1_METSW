package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController {
    private UsuarioService usuarioService = new UsuarioService();
    private int intentos = 0;
    private long tiempoBloqueo = 0; // tiempo en milisegundos

    public void mostrarPantallaLogin(Stage stage) {
        Image logoImg = new Image(getClass().getResourceAsStream("/logo.png"));
        ImageView logoView = new ImageView(logoImg);
        logoView.setFitWidth(120);
        logoView.setPreserveRatio(true);

        Label lblUsuario = new Label("Usuario:");
        TextField txtUsuario = new TextField();
        txtUsuario.setMaxWidth(160);
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setMaxWidth(160);
        Button btnLogin = new Button("Iniciar sesión");
        Label lblMensaje = new Label();
        btnLogin.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage, btnLogin));
        txtContrasena.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage, btnLogin));
        VBox vbox = new VBox(12, logoView, lblUsuario, txtUsuario, lblContrasena, txtContrasena, btnLogin, lblMensaje);
        vbox.setAlignment(Pos.CENTER);
        StackPane root = new StackPane(vbox);
        root.setStyle("-fx-background-color: #f0f0f0;");
        Scene scene = new Scene(root, 400, 340);
        stage.setTitle("Login JavaFX");
        stage.setScene(scene);
        stage.setMaximized(false);
        stage.setWidth(400);
        stage.setHeight(500);
        stage.centerOnScreen();
        stage.show();
    }

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error de inicio de sesión");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void verificarLogin(TextField txtUsuario, PasswordField txtContrasena, Label lblMensaje, Stage stage, Button btnLogin) {
        long ahora = System.currentTimeMillis();
        if (ahora < tiempoBloqueo) {
            mostrarError("Demasiados intentos. Intenta de nuevo en 5 minutos.");
            btnLogin.setDisable(true);
            return;
        } else {
            btnLogin.setDisable(false);
        }

        String usuario = txtUsuario.getText();
        String contrasena = txtContrasena.getText();
        if (usuarioService.verificarUsuario(usuario, contrasena)) {
            intentos = 0;
            String rol = usuarioService.getRol(usuario);
            if (rol == null || rol.isEmpty()) {
                mostrarError("El usuario no tiene un rol asignado o no es válido.");
                return;
            }
            new PanelController(usuarioService).mostrarPantallaPanel(stage, usuario, rol);
        } else {
            intentos++;
            if (intentos >= 3) {
                mostrarError("Demasiados intentos. Intenta de nuevo en 5 minutos.");
                tiempoBloqueo = System.currentTimeMillis() + 5 * 60 * 1000; // 5 minutos
                btnLogin.setDisable(true);
                new Thread(() -> {
                    try {
                        Thread.sleep(5 * 60 * 1000);
                    } catch (InterruptedException e) {
                        // Ignorar
                    }
                    javafx.application.Platform.runLater(() -> {
                        intentos = 0;
                        btnLogin.setDisable(false);
                        lblMensaje.setText("");
                    });
                }).start();
            } else {
                mostrarError("Usuario o contraseña incorrectos. Intento " + intentos + " de 3.");
            }
        }
    }

    public java.util.Map<String, String[]> getUsuarios() {
        return usuarioService.getUsuarios();
    }
}
