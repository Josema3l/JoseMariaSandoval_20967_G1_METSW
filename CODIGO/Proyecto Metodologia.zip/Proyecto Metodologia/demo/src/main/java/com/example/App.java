package com.example; // Asegúrate de que este paquete coincida con tu groupId

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Clase principal de tu aplicación JavaFX.
 * Extiende javafx.application.Application para definir el ciclo de vida de la aplicación.
 */
public class App extends Application {
    private Map<String, String[]> usuarios = new HashMap<>(); // usuario -> [contraseña, rol]

    /**
     * El método 'start' es el punto de entrada principal para todas las aplicaciones JavaFX.
     * Se llama después de que el sistema JavaFX ha sido inicializado.
     *
     * @param stage El objeto Stage (ventana principal) proporcionado por el sistema JavaFX.
     */
    @Override
    public void start(Stage stage) {
        cargarUsuarios();
        mostrarPantallaLogin(stage);
    }

    private void mostrarPantallaPanel(Stage stage, String usuario, String rol) {
        Label lbl = new Label("Bienvenido/a: " + usuario);
        Button btnMapa = new Button("Mapa de Procesos");
        Button btnTabla = new Button("Tabla");
        Button btnCerrar = new Button("Cerrar sesión");
        Label lblMensaje = new Label();

        // Menú tipo hamburguesa solo para administradora
        HBox topBar = new HBox();
        topBar.setAlignment(Pos.TOP_LEFT);
        MenuButton menuHamburguesa = null;
        if (rol.equals("administradora")) {
            menuHamburguesa = new MenuButton("≡");
            MenuItem crearUsuario = new MenuItem("Crear nuevo usuario");
            crearUsuario.setOnAction(_ -> mostrarDialogoCrearUsuario(lblMensaje));
            menuHamburguesa.getItems().add(crearUsuario);
            topBar.getChildren().add(menuHamburguesa);
        }

        // Panel principal vacío (puedes agregar contenido aquí si lo deseas)
        StackPane panelCentral = new StackPane();
        panelCentral.setStyle(rol.equals("administradora") ? "-fx-background-color: #d1f2eb;" : "-fx-background-color:rgb(182, 200, 255);");

        // Panel lateral izquierdo (menú y botones)
        VBox vboxMenu = new VBox(30);
        if (rol.equals("administradora")) {
            vboxMenu.getChildren().add(topBar);
        }
        vboxMenu.getChildren().addAll(lbl, btnMapa, btnTabla, btnCerrar, lblMensaje);
        vboxMenu.setAlignment(Pos.TOP_CENTER);
        vboxMenu.setPrefWidth(250);
        vboxMenu.setStyle("-fx-background-color:rgb(178, 226, 89);");

        btnCerrar.setOnAction(_ -> mostrarPantallaLogin(stage));
        btnMapa.setOnAction(_ -> {
            if (rol.equals("administradora")) {
                lblMensaje.setText("Abriendo mapa de procesos...");
                panelCentral.getChildren().clear();
                try {
                    Image mapaImg = new Image(getClass().getResourceAsStream("/mapa_procesos.png"));
                    ImageView mapaView = new ImageView(mapaImg);
                    mapaView.setPreserveRatio(true);
                    mapaView.setFitWidth(1250);

                    // Botones visibles y funcionales para cada apartado del mapa (ajustados a la imagen)
                    Button btnSistemasGestion = new Button("Sistemas de Gestión");
                    btnSistemasGestion.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnSistemasGestion.setPrefSize(85, 75);
                    btnSistemasGestion.setLayoutX(805);
                    btnSistemasGestion.setLayoutY(190);
                    btnSistemasGestion.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\MEJORA CONTINUA";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnGestionComercial = new Button("Gestión de Comercialización");
                    btnGestionComercial.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnGestionComercial.setPrefSize(80, 90);
                    btnGestionComercial.setLayoutX(310);
                    btnGestionComercial.setLayoutY(455);
                    btnGestionComercial.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\GESTION DE COMERCIALIZACION";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnAnalisis = new Button("Análisis Vulnerabilidad");
                    btnAnalisis.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnAnalisis.setPrefSize(150, 120);
                    btnAnalisis.setLayoutX(440);
                    btnAnalisis.setLayoutY(425);
                    btnAnalisis.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\ANALISIS VULNERABILIDAD";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnInduccion = new Button("Inducción Vigilante");
                    btnInduccion.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnInduccion.setPrefSize(105, 120);
                    btnInduccion.setLayoutX(605);
                    btnInduccion.setLayoutY(425);
                    btnInduccion.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\INDUCCION VIGILANTE";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnOperaciones = new Button("Operaciones Fija - Móvil");
                    btnOperaciones.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnOperaciones.setPrefSize(125, 120);
                    btnOperaciones.setLayoutX(725);
                    btnOperaciones.setLayoutY(425);
                    btnOperaciones.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\OPERACIONES FIJA-MOVIL";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnSupervision = new Button("Supervisión Control");
                    btnSupervision.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnSupervision.setPrefSize(118, 120);
                    btnSupervision.setLayoutX(860);
                    btnSupervision.setLayoutY(425);
                    btnSupervision.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\SUPERVISION CONTROL";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnSatisfaccion = new Button("Satisfacción al Cliente");
                    btnSatisfaccion.setStyle("-fx-background-color: rgba(0,255,100,0.4); -fx-border-color: #000;");
                    btnSatisfaccion.setPrefSize(45, 65);
                    btnSatisfaccion.setLayoutX(1060);
                    btnSatisfaccion.setLayoutY(450);
                    btnSatisfaccion.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\SATISFACCION AL CLIENTE";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    // 4 botones para GESTIÓN ADMINISTRATIVA-FINANCIERA
                    Button btnAdmin1 = new Button("A1");
                    btnAdmin1.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin1.setPrefSize(65, 70);
                    btnAdmin1.setLayoutX(145);
                    btnAdmin1.setLayoutY(685);
                    btnAdmin1.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\CONTABLE";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnAdmin2 = new Button("A2");
                    btnAdmin2.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin2.setPrefSize(85, 70);
                    btnAdmin2.setLayoutX(225);
                    btnAdmin2.setLayoutY(685);
                    btnAdmin2.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\ADQUISICIONES";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnAdmin3 = new Button("A3");
                    btnAdmin3.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin3.setPrefSize(63, 85);
                    btnAdmin3.setLayoutX(320);
                    btnAdmin3.setLayoutY(685);
                    btnAdmin3.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\SEGURIDAD FISICA";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnAdmin4 = new Button("A4");
                    btnAdmin4.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin4.setPrefSize(60, 70);
                    btnAdmin4.setLayoutX(400);
                    btnAdmin4.setLayoutY(685);
                    btnAdmin4.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\LOGISTICA";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    // 4 botones para GESTIÓN DE TALENTO HUMANO
                    Button btnTalento1 = new Button("T1");
                    btnTalento1.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento1.setPrefSize(115, 70);
                    btnTalento1.setLayoutX(585);
                    btnTalento1.setLayoutY(700);
                    btnTalento1.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\CONTRATACION";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnTalento2 = new Button("T2");
                    btnTalento2.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento2.setPrefSize(130, 70);
                    btnTalento2.setLayoutX(715);
                    btnTalento2.setLayoutY(700);
                    btnTalento2.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\ADMINISTRACION";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnTalento3 = new Button("T3");
                    btnTalento3.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento3.setPrefSize(135, 70);
                    btnTalento3.setLayoutX(850);
                    btnTalento3.setLayoutY(700);
                    btnTalento3.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\DESVINCULACION";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnTalento4 = new Button("T4");
                    btnTalento4.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento4.setPrefSize(110, 70);
                    btnTalento4.setLayoutX(990);
                    btnTalento4.setLayoutY(700);
                    btnTalento4.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\CAPACITACION";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnTalento5 = new Button("T5");
                    btnTalento5.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento5.setPrefSize(90, 70);
                    btnTalento5.setLayoutX(480);
                    btnTalento5.setLayoutY(700);
                    btnTalento5.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\SELECCION";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnGestionIT = new Button("Gestión de IT");
                    btnGestionIT.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnGestionIT.setPrefSize(60, 70);
                    btnGestionIT.setLayoutX(1140);
                    btnGestionIT.setLayoutY(700);
                    btnGestionIT.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\GESTION IT";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    // Eliminar btnPlanificacion y crear 4 nuevos botones para la sección superior izquierda
                    Button btnDireccionEstrategica = new Button("DIRECCION ESTRATEGICA");
                    btnDireccionEstrategica.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnDireccionEstrategica.setPrefSize(100, 75);
                    btnDireccionEstrategica.setLayoutX(300);
                    btnDireccionEstrategica.setLayoutY(190);
                    btnDireccionEstrategica.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\DIRECCION ESTRATEGICA";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnRequisitosLegales = new Button("REQUISITOS LEGALES");
                    btnRequisitosLegales.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnRequisitosLegales.setPrefSize(90, 75);
                    btnRequisitosLegales.setLayoutX(425);
                    btnRequisitosLegales.setLayoutY(190);
                    btnRequisitosLegales.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\REQUISITOS LEGALES";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnFirmaContrato = new Button("FIRMA CONTRATO");
                    btnFirmaContrato.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnFirmaContrato.setPrefSize(82, 75);
                    btnFirmaContrato.setLayoutX(558);
                    btnFirmaContrato.setLayoutY(190);
                    btnFirmaContrato.setOnAction(_ -> {
                        try {
                            String folderPath = "C:\\Users\\santy\\OneDrive\\Documentos\\Carpetas documentos\\FIRMA CONTRATO";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    Button btnNecesidadesPartes = new Button("NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS");
                    btnNecesidadesPartes.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnNecesidadesPartes.setPrefSize(100, 140);
                    btnNecesidadesPartes.setLayoutX(17);
                    btnNecesidadesPartes.setLayoutY(400);
                    btnNecesidadesPartes.setOnAction(_ -> {
                        try {
                            String folderPath = "C:/Users/santy/OneDrive/Documentos/Carpetas documentos/NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS";
                            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
                        } catch (Exception ex) {
                            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
                        }
                    });

                    javafx.scene.layout.Pane overlay = new javafx.scene.layout.Pane();
                    overlay.setPickOnBounds(false);
                    overlay.getChildren().addAll(
                        mapaView,
                        btnDireccionEstrategica, btnRequisitosLegales, btnFirmaContrato, btnNecesidadesPartes,
                        btnSistemasGestion,
                        btnGestionComercial, btnAnalisis, btnInduccion, btnOperaciones, btnSupervision, btnSatisfaccion,
                        btnAdmin1, btnAdmin2, btnAdmin3, btnAdmin4,
                        btnTalento1, btnTalento2, btnTalento3, btnTalento4, btnTalento5,
                        btnGestionIT
                    );
                    panelCentral.getChildren().add(overlay);
                } catch (Exception ex) {
                    lblMensaje.setText("No se pudo cargar el mapa de procesos.");
                }
            } else if (rol.equals("cliente")) {
                lblMensaje.setText("Acceso al mapa de procesos restringido.");
                panelCentral.getChildren().clear();
            }
        });
        btnTabla.setOnAction(_ -> {
            if (rol.equals("administradora")) {
                lblMensaje.setText("Abriendo tabla...");
            } else if (rol.equals("cliente")) {
                lblMensaje.setText("Acceso a la tabla restringido.");
            }
        });

        BorderPane root = new BorderPane();
        root.setLeft(vboxMenu);
        root.setCenter(panelCentral);

        Scene scene = new Scene(root);
        stage.setTitle("Panel Principal");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();
    }

    private void mostrarDialogoCrearUsuario(Label lblMensaje) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Crear nuevo usuario");
        dialog.setHeaderText("Ingrese el nuevo usuario y contraseña separados por coma (usuario,contraseña,rol):");
        dialog.setContentText("Datos:");
        dialog.showAndWait().ifPresent(input -> {
            String[] partes = input.split(",");
            if (partes.length == 3) {
                usuarios.put(partes[0], new String[]{partes[1], partes[2]});
                lblMensaje.setText("Usuario creado: " + partes[0] + " (rol: " + partes[2] + ")");
            } else {
                lblMensaje.setText("Formato incorrecto. Use: usuario,contraseña,rol");
            }
        });
    }

    private void mostrarPantallaLogin(Stage stage) {
        // Logo
        Image logoImg = new Image(getClass().getResourceAsStream("/logo.png"));
        ImageView logoView = new ImageView(logoImg);
        logoView.setFitWidth(120);
        logoView.setPreserveRatio(true);
        // Campos de usuario y contraseña
        Label lblUsuario = new Label("Usuario:");
        TextField txtUsuario = new TextField();
        txtUsuario.setMaxWidth(160);
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setMaxWidth(160);
        Button btnLogin = new Button("Iniciar sesión");
        Label lblMensaje = new Label();
        btnLogin.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage));
        // Permitir login con Enter en el campo contraseña
        txtContrasena.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage));
        javafx.scene.layout.VBox vbox = new javafx.scene.layout.VBox(12, logoView, lblUsuario, txtUsuario, lblContrasena, txtContrasena, btnLogin, lblMensaje);
        vbox.setAlignment(Pos.CENTER);
        StackPane root = new StackPane(vbox);
        root.setStyle("-fx-background-color: #f0f0f0;"); // Gris claro para login
        Scene scene = new Scene(root, 400, 340);
        stage.setTitle("Login JavaFX");
        stage.setScene(scene);
        stage.setMaximized(false);
        stage.setWidth(400);
        stage.setHeight(340);
        stage.centerOnScreen();
        stage.show();
    }

    // Nuevo método para verificar login
    private void verificarLogin(TextField txtUsuario, PasswordField txtContrasena, Label lblMensaje, Stage stage) {
        String usuario = txtUsuario.getText();
        String contrasena = txtContrasena.getText();
        if (usuarios.containsKey(usuario) && usuarios.get(usuario)[0].equals(contrasena)) {
            String rol = usuarios.get(usuario)[1];
            mostrarPantallaPanel(stage, usuario, rol);
        } else {
            lblMensaje.setText("Usuario o contraseña incorrectos");
        }
    }

    private void cargarUsuarios() {
        try {
            InputStream is = getClass().getResourceAsStream("/usuarios.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String linea;
            boolean primera = true;
            while ((linea = reader.readLine()) != null) {
                if (primera) { primera = false; continue; }
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    usuarios.put(partes[0], new String[]{partes[1], partes[2]});
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * El método 'main' es el punto de entrada estándar para cualquier aplicación Java.
     * Para una aplicación JavaFX, este método simplemente llama a 'launch()'.
     * El método 'launch()' se encarga de inicializar el sistema JavaFX y, eventualmente,
     * llamar al método 'start()' de tu clase Application.
     *
     * @param args Argumentos de línea de comandos pasados a la aplicación.
     */
    public static void main(String[] args) {
        launch(); // Inicia el ciclo de vida de la aplicación JavaFX
    }
}
