package com.example;

import java.util.HashMap;
import java.util.Map;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileWriter;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedWriter;

public class UsuarioService {
    private Map<String, String[]> usuarios = new HashMap<>();
    private static final String USUARIOS_FILE = "usuarios.txt";

    public UsuarioService() {
        cargarUsuarios();
    }

    private void cargarUsuarios() {
        try {
            File file = new File(USUARIOS_FILE);
            if (!file.exists()) {
                // Si no existe, crear archivo con cabecera y un usuario admin por defecto
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                writer.write("usuario,contraseña,rol\nadmin,admin123,administradora\ncliente,cliente123,cliente");
                writer.close();
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String linea;
            boolean primera = true;
            while ((linea = reader.readLine()) != null) {
                if (primera) { primera = false; continue; }
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    usuarios.put(partes[0], new String[]{partes[1], partes[2]});
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean verificarUsuario(String usuario, String contrasena) {
        return usuarios.containsKey(usuario) && usuarios.get(usuario)[0].equals(contrasena);
    }

    public String getRol(String usuario) {
        return usuarios.get(usuario)[1];
    }

    public void crearUsuario(String usuario, String contrasena, String rol) {
        usuarios.put(usuario, new String[]{contrasena, rol});
        guardarUsuarioEnCSV(usuario, contrasena, rol);
    }

    private void guardarUsuarioEnCSV(String usuario, String contrasena, String rol) {
        try {
            BufferedWriter fw = new BufferedWriter(new FileWriter(USUARIOS_FILE, true));
            fw.write("\n" + usuario + "," + contrasena + "," + rol);
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Permitir acceso a los usuarios para poblar el ComboBox desde LoginController
    public Map<String, String[]> getUsuarios() {
        return usuarios;
    }
}
