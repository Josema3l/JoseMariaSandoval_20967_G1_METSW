package com.example;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

public class PanelController {
    private final UsuarioService usuarioService;

    public PanelController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    public void mostrarPantallaPanel(Stage stage, String usuario, String rol) {
        Label lbl = new Label("Bienvenido/a: " + usuario);
        Button btnMapa = new Button("Mapa de Procesos");
        Button btnTabla = new Button("Tabla de control");
        Button btnCerrar = new Button("Cerrar sesión");
        Button btnEnviarRecordatorios = new Button("Enviar recordatorios");
        Label lblMensaje = new Label();

        HBox topBar = new HBox();
        topBar.setAlignment(Pos.TOP_LEFT);
        MenuButton menuHamburguesa = null;
        if (rol.equals("administradora")) {
            menuHamburguesa = new MenuButton("≡");
            MenuItem crearUsuario = new MenuItem("Crear nuevo usuario");
            crearUsuario.setOnAction(_ -> mostrarDialogoCrearUsuario(lblMensaje));
            menuHamburguesa.getItems().add(crearUsuario);
            topBar.getChildren().add(menuHamburguesa);
        }

        StackPane panelCentral = new StackPane();
        panelCentral.setStyle(rol.equals("administradora") ? "-fx-background-color: #d1f2eb;" : "-fx-background-color:rgb(182, 200, 255);");

        VBox vboxMenu = new VBox(30);
        if (rol.equals("administradora")) {
            vboxMenu.getChildren().add(topBar);
            vboxMenu.getChildren().add(btnEnviarRecordatorios);
        }
        vboxMenu.getChildren().addAll(lbl, btnMapa, btnTabla, btnCerrar, lblMensaje);
        vboxMenu.setAlignment(Pos.TOP_CENTER);
        vboxMenu.setPrefWidth(250);
        vboxMenu.setStyle("-fx-background-color:rgb(178, 226, 89);");

        btnCerrar.setOnAction(_ -> new LoginController().mostrarPantallaLogin(stage));
        btnEnviarRecordatorios.setOnAction(_ -> revisarYEnviarRecordatorios(lblMensaje));
        btnMapa.setOnAction(_ -> {
            if (rol.equals("administradora")) {
                lblMensaje.setText("Abriendo mapa de procesos...");
                panelCentral.getChildren().clear();
                try {
                    Image mapaImg = new Image(getClass().getResourceAsStream("/mapa_procesos.png"));
                    ImageView mapaView = new ImageView(mapaImg);
                    mapaView.setPreserveRatio(true);
                    mapaView.setFitWidth(1250);

                    // Botones sobre el mapa
                    Button btnSistemasGestion = new Button("");
                    btnSistemasGestion.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
                    btnSistemasGestion.setPrefSize(85, 75);
                    btnSistemasGestion.setLayoutX(805);
                    btnSistemasGestion.setLayoutY(190);
                    btnSistemasGestion.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/MEJORA CONTINUA", lblMensaje));

                    Button btnGestionComercial = new Button("Gestión de Comercialización");
                    btnGestionComercial.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnGestionComercial.setPrefSize(80, 90);
                    btnGestionComercial.setLayoutX(310);
                    btnGestionComercial.setLayoutY(455);
                    btnGestionComercial.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/GESTION DE COMERCIALIZACION", lblMensaje));

                    Button btnAnalisis = new Button("Análisis Vulnerabilidad");
                    btnAnalisis.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnAnalisis.setPrefSize(150, 120);
                    btnAnalisis.setLayoutX(440);
                    btnAnalisis.setLayoutY(425);
                    btnAnalisis.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ANALISIS VULNERABILIDAD", lblMensaje));

                    Button btnInduccion = new Button("Inducción Vigilante");
                    btnInduccion.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnInduccion.setPrefSize(105, 120);
                    btnInduccion.setLayoutX(605);
                    btnInduccion.setLayoutY(425);
                    btnInduccion.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/INDUCCION VIGILANTE", lblMensaje));

                    Button btnOperaciones = new Button("Operaciones Fija - Móvil");
                    btnOperaciones.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnOperaciones.setPrefSize(125, 120);
                    btnOperaciones.setLayoutX(725);
                    btnOperaciones.setLayoutY(425);
                    btnOperaciones.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/OPERACIONES FIJA-MOVIL", lblMensaje));

                    Button btnSupervision = new Button("Supervisión Control");
                    btnSupervision.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnSupervision.setPrefSize(118, 120);
                    btnSupervision.setLayoutX(860);
                    btnSupervision.setLayoutY(425);
                    btnSupervision.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SUPERVISION CONTROL", lblMensaje));

                    Button btnSatisfaccion = new Button("Satisfacción al Cliente");
                    btnSatisfaccion.setStyle("-fx-background-color: rgba(0,255,100,0.4); -fx-border-color: #000;");
                    btnSatisfaccion.setPrefSize(45, 65);
                    btnSatisfaccion.setLayoutX(1060);
                    btnSatisfaccion.setLayoutY(450);
                    btnSatisfaccion.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SATISFACCION AL CLIENTE", lblMensaje));

                    Button btnAdmin1 = new Button("A1");
                    btnAdmin1.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin1.setPrefSize(65, 70);
                    btnAdmin1.setLayoutX(145);
                    btnAdmin1.setLayoutY(685);
                    btnAdmin1.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CONTABLE", lblMensaje));

                    Button btnAdmin2 = new Button("A2");
                    btnAdmin2.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin2.setPrefSize(85, 70);
                    btnAdmin2.setLayoutX(225);
                    btnAdmin2.setLayoutY(685);
                    btnAdmin2.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ADQUISICIONES", lblMensaje));

                    Button btnAdmin3 = new Button("A3");
                    btnAdmin3.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin3.setPrefSize(63, 85);
                    btnAdmin3.setLayoutX(320);
                    btnAdmin3.setLayoutY(685);
                    btnAdmin3.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SEGURIDAD FISICA", lblMensaje));

                    Button btnAdmin4 = new Button("A4");
                    btnAdmin4.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin4.setPrefSize(60, 70);
                    btnAdmin4.setLayoutX(400);
                    btnAdmin4.setLayoutY(685);
                    btnAdmin4.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/LOGISTICA", lblMensaje));

                    Button btnTalento1 = new Button("T1");
                    btnTalento1.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento1.setPrefSize(115, 70);
                    btnTalento1.setLayoutX(585);
                    btnTalento1.setLayoutY(700);
                    btnTalento1.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CONTRATACION", lblMensaje));

                    Button btnTalento2 = new Button("T2");
                    btnTalento2.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento2.setPrefSize(130, 70);
                    btnTalento2.setLayoutX(715);
                    btnTalento2.setLayoutY(700);
                    btnTalento2.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ADMINISTRACION", lblMensaje));

                    Button btnTalento3 = new Button("T3");
                    btnTalento3.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento3.setPrefSize(135, 70);
                    btnTalento3.setLayoutX(850);
                    btnTalento3.setLayoutY(700);
                    btnTalento3.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/DESVINCULACION", lblMensaje));

                    Button btnTalento4 = new Button("T4");
                    btnTalento4.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento4.setPrefSize(110, 70);
                    btnTalento4.setLayoutX(990);
                    btnTalento4.setLayoutY(700);
                    btnTalento4.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CAPACITACION", lblMensaje));

                    Button btnTalento5 = new Button("T5");
                    btnTalento5.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento5.setPrefSize(90, 70);
                    btnTalento5.setLayoutX(480);
                    btnTalento5.setLayoutY(700);
                    btnTalento5.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SELECCION", lblMensaje));

                    Button btnGestionIT = new Button("Gestión de IT");
                    btnGestionIT.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnGestionIT.setPrefSize(60, 70);
                    btnGestionIT.setLayoutX(1140);
                    btnGestionIT.setLayoutY(700);
                    btnGestionIT.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/GESTION IT", lblMensaje));

                    Button btnDireccionEstrategica = new Button("DIRECCION ESTRATEGICA");
                    btnDireccionEstrategica.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnDireccionEstrategica.setPrefSize(100, 75);
                    btnDireccionEstrategica.setLayoutX(300);
                    btnDireccionEstrategica.setLayoutY(190);
                    btnDireccionEstrategica.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/DIRECCION ESTRATEGICA", lblMensaje));

                    Button btnRequisitosLegales = new Button("REQUISITOS LEGALES");
                    btnRequisitosLegales.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnRequisitosLegales.setPrefSize(90, 75);
                    btnRequisitosLegales.setLayoutX(425);
                    btnRequisitosLegales.setLayoutY(190);
                    btnRequisitosLegales.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/REQUISITOS LEGALES", lblMensaje));

                    Button btnFirmaContrato = new Button("FIRMA CONTRATO");
                    btnFirmaContrato.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnFirmaContrato.setPrefSize(82, 75);
                    btnFirmaContrato.setLayoutX(558);
                    btnFirmaContrato.setLayoutY(190);
                    btnFirmaContrato.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/FIRMA CONTRATO", lblMensaje));

                    Button btnNecesidadesPartes = new Button("NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS");
                    btnNecesidadesPartes.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnNecesidadesPartes.setPrefSize(100, 140);
                    btnNecesidadesPartes.setLayoutX(17);
                    btnNecesidadesPartes.setLayoutY(400);
                    btnNecesidadesPartes.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS", lblMensaje));

                    Pane overlay = new Pane();
                    overlay.setPickOnBounds(false);
                    overlay.getChildren().addAll(
                        mapaView,
                        btnDireccionEstrategica, btnRequisitosLegales, btnFirmaContrato, btnNecesidadesPartes,
                        btnSistemasGestion,
                        btnGestionComercial, btnAnalisis, btnInduccion, btnOperaciones, btnSupervision, btnSatisfaccion,
                        btnAdmin1, btnAdmin2, btnAdmin3, btnAdmin4,
                        btnTalento1, btnTalento2, btnTalento3, btnTalento4, btnTalento5,
                        btnGestionIT
                    );
                    panelCentral.getChildren().add(overlay);
                } catch (Exception ex) {
                    lblMensaje.setText("No se pudo cargar el mapa de procesos.");
                }
            } else {
                lblMensaje.setText("Acceso al mapa de procesos restringido.");
                panelCentral.getChildren().clear();
            }
        });
        btnTabla.setOnAction(_ -> {
            if (rol.equals("administradora")) {
                mostrarVentanaTablaControl();
            } else {
                lblMensaje.setText("Acceso a la tabla restringido.");
            }
        });

        BorderPane root = new BorderPane();
        root.setLeft(vboxMenu);
        root.setCenter(panelCentral);

        Scene scene = new Scene(root);
        stage.setTitle("Panel Principal");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();

        // Al abrir la app, revisar documentos y enviar recordatorio si corresponde
        revisarYEnviarRecordatorios(lblMensaje);
    }

    private void mostrarDialogoCrearUsuario(Label lblMensaje) {
        Dialog<String[]> dialog = new Dialog<>();
        dialog.setTitle("Crear nuevo usuario");
        dialog.setHeaderText("Ingrese los datos del nuevo usuario:");

        Label lblUsuario = new Label("Usuario:");
        TextField txtUsuario = new TextField();
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        Label lblRol = new Label("Rol:");
        ComboBox<String> comboRol = new ComboBox<>();
        comboRol.getItems().addAll("Administradora", "Cliente", "Tester"); // Puedes agregar más roles si lo deseas
        comboRol.setPromptText("Seleccione rol");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(lblUsuario, 0, 0);
        grid.add(txtUsuario, 1, 0);
        grid.add(lblContrasena, 0, 1);
        grid.add(txtContrasena, 1, 1);
        grid.add(lblRol, 0, 2);
        grid.add(comboRol, 1, 2);

        dialog.getDialogPane().setContent(grid);
        ButtonType btnCrear = new ButtonType("Crear", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(btnCrear, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == btnCrear) {
                return new String[]{txtUsuario.getText(), txtContrasena.getText(), comboRol.getValue()};
            }
            return null;
        });

        dialog.showAndWait().ifPresent(partes -> {
            if (partes != null && partes.length == 3 && partes[0] != null && partes[1] != null && partes[2] != null) {
                usuarioService.crearUsuario(partes[0], partes[1], partes[2]);
                lblMensaje.setText("Usuario creado: " + partes[0] + " (rol: " + partes[2] + ")");
            } else {
                lblMensaje.setText("Debe completar todos los campos y seleccionar un rol");
            }
        });
    }

    
    private void abrirCarpeta(String folderPath, Label lblMensaje) {
        try {
            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
        } catch (Exception ex) {
            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
        }
    }

    // Nueva ventana para Tabla de control
    private void mostrarVentanaTablaControl() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("Tabla de control de documentos legales");
        Button btnRegistrar = new Button("Registrar documento");
        Button btnVer = new Button("Ver documentos registrados");
        VBox vbox = new VBox(20, btnRegistrar, btnVer);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPrefSize(400, 200);
        Scene scene = new Scene(vbox);
        tablaStage.setScene(scene);
        tablaStage.show();

        btnRegistrar.setOnAction(_ -> {
            tablaStage.close();
            mostrarFormularioRegistro();
        });
        btnVer.setOnAction(_ -> {
            tablaStage.close();
            mostrarDocumentosRegistrados();
        });
    }

    // Mostrar documentos registrados en una tabla
    private void mostrarDocumentosRegistrados() {
        Stage docsStage = new Stage();
        docsStage.setTitle("Documentos registrados");
        TableView<String[]> table = new TableView<>();
        String[] headers = {"Código nro", "Requisito Legal", "Cómo se aplica", "Por qué lo aplica", "Fecha de emisión", "Fecha de vencimiento", "Fecha próxima de renovación"};
        for (int i = 0; i < headers.length; i++) {
            final int colIdx = i;
            TableColumn<String[], String> col = new TableColumn<>(headers[i]);
            col.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue()[colIdx]));
            col.setPrefWidth(150);
            table.getColumns().add(col);
        }
        // Leer documentos.txt
        java.util.List<String[]> rows = new java.util.ArrayList<>();
        try {
            java.nio.file.Path path = java.nio.file.Paths.get("documentos.txt");
            if (java.nio.file.Files.exists(path)) {
                java.util.List<String> lines = java.nio.file.Files.readAllLines(path);
                for (String line : lines) {
                    String[] parts = line.split(";");
                    if (parts.length == headers.length) {
                        rows.add(parts);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        table.setItems(javafx.collections.FXCollections.observableArrayList(rows));

        VBox vbox = new VBox(table);
        Scene scene = new Scene(vbox);
        docsStage.setScene(scene);
        docsStage.show();
    }

    // Mostrar formulario de registro de documento
    private void mostrarFormularioRegistro() {
        Stage registroStage = new Stage();
        registroStage.setTitle("Registrar documento legal");
        Label lblMensaje = new Label();
        TextField txtCodigo = new TextField();
        TextField txtRequisitoLegal = new TextField();
        TextField txtComoSeAplica = new TextField();
        TextField txtPorQueLoAplica = new TextField();
        DatePicker dtpFechaEmision = new DatePicker();
        DatePicker dtpFechaVencimiento = new DatePicker();
        DatePicker dtpFechaProximaRenovacion = new DatePicker();

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Código nro:"), 0, 0);
        grid.add(txtCodigo, 1, 0);
        grid.add(new Label("Requisito Legal:"), 0, 1);
        grid.add(txtRequisitoLegal, 1, 1);
        grid.add(new Label("Cómo se aplica:"), 0, 2);
        grid.add(txtComoSeAplica, 1, 2);
        grid.add(new Label("Por qué lo aplica:"), 0, 3);
        grid.add(txtPorQueLoAplica, 1, 3);
        grid.add(new Label("Fecha de emisión:"), 0, 4);
        grid.add(dtpFechaEmision, 1, 4);
        grid.add(new Label("Fecha de vencimiento:"), 0, 5);
        grid.add(dtpFechaVencimiento, 1, 5);
        grid.add(new Label("Fecha próxima de renovación:"), 0, 6);
        grid.add(dtpFechaProximaRenovacion, 1, 6);
        grid.add(lblMensaje, 0, 7, 2, 1);

        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(e -> {
            String codigo = txtCodigo.getText();
            String requisitoLegal = txtRequisitoLegal.getText();
            String comoSeAplica = txtComoSeAplica.getText();
            String porQueLoAplica = txtPorQueLoAplica.getText();
            LocalDate fechaEmision = dtpFechaEmision.getValue();
            LocalDate fechaVencimiento = dtpFechaVencimiento.getValue();
            LocalDate fechaProximaRenovacion = dtpFechaProximaRenovacion.getValue();

            if (codigo.isEmpty() || requisitoLegal.isEmpty() || comoSeAplica.isEmpty() || porQueLoAplica.isEmpty() || fechaEmision == null || fechaVencimiento == null || fechaProximaRenovacion == null) {
                lblMensaje.setText("Por favor, complete todos los campos.");
                return;
            }

            // Guardar en documentos.txt
            try {
                java.nio.file.Path path = java.nio.file.Paths.get("documentos.txt");
                String linea = String.join(";", codigo, requisitoLegal, comoSeAplica, porQueLoAplica, fechaEmision.toString(), fechaVencimiento.toString(), fechaProximaRenovacion.toString());
                java.nio.file.Files.write(path, java.util.Collections.singleton(linea), java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
                lblMensaje.setText("Documento registrado exitosamente.");
                // Limpiar campos
                txtCodigo.clear();
                txtRequisitoLegal.clear();
                txtComoSeAplica.clear();
                txtPorQueLoAplica.clear();
                dtpFechaEmision.setValue(null);
                dtpFechaVencimiento.setValue(null);
                dtpFechaProximaRenovacion.setValue(null);
            } catch (Exception ex) {
                lblMensaje.setText("Error al guardar el documento.");
                ex.printStackTrace();
            }
        });

        HBox hboxBotones = new HBox(10, btnGuardar, new Button("Cancelar"));
        hboxBotones.setAlignment(Pos.CENTER);
        grid.add(hboxBotones, 0, 8, 2, 1);

        Scene scene = new Scene(grid, 600, 400);
        registroStage.setScene(scene);
        registroStage.show();
    }

    private void revisarYEnviarRecordatorios(Label lblMensaje) {
        // Leer documentos.txt y enviar recordatorios si corresponde
        boolean huboError = false;
        try {
            java.nio.file.Path path = java.nio.file.Paths.get("documentos.txt");
            if (java.nio.file.Files.exists(path)) {
                java.util.List<String> lines = java.nio.file.Files.readAllLines(path);
                for (String line : lines) {
                    String[] partes = line.split(";");
                    if (partes.length >= 7) {
                        String codigo = partes[0];
                        String requisitoLegal = partes[1];
                        String comoSeAplica = partes[2];
                        String porQueLoAplica = partes[3];
                        LocalDate fechaEmision = LocalDate.parse(partes[4]);
                        LocalDate fechaVencimiento = LocalDate.parse(partes[5]);
                        LocalDate fechaProximaRenovacion = LocalDate.parse(partes[6]);

                        // Si la fecha próxima de renovación es hoy o ya pasó, enviar recordatorio
                        if (!fechaProximaRenovacion.isAfter(LocalDate.now())) {
                            boolean exito = enviarRecordatorio(codigo, requisitoLegal, comoSeAplica, porQueLoAplica, fechaEmision, fechaVencimiento, fechaProximaRenovacion, lblMensaje);
                            if (!exito) huboError = true;
                        }
                    }
                }
                if (!huboError) {
                    lblMensaje.setText("Recordatorios enviados correctamente (si había documentos para renovar).");
                }
            } else {
                lblMensaje.setText("No hay documentos registrados.");
            }
        } catch (Exception e) {
            lblMensaje.setText("Error al revisar documentos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean enviarRecordatorio(String codigo, String requisitoLegal, String comoSeAplica, String porQueLoAplica, LocalDate fechaEmision, LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, Label lblMensaje) {
        // Configuración del correo
        String remitente = "santy.rojas.2005.santylol@gmail.com"; // Cambia por tu correo
        String password = "chru xxhs tbjc udwn"; // Cambia por tu contraseña de aplicación
        String destinatario = "diegopintosegovia@gmail.com"; // Cambia por el destinatario
        String asunto = "Recordatorio de renovación de documento legal";
        String cuerpo = "Recordatorio: El documento con código " + codigo + " y requisito legal '" + requisitoLegal + "' tiene fecha de renovación próxima o vencida."
                + "\nFecha de emisión: " + fechaEmision
                + "\nFecha de vencimiento: " + fechaVencimiento
                + "\nFecha próxima de renovación: " + fechaProximaRenovacion;

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, password);
            }
        });
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);
            message.setText(cuerpo);
            Transport.send(message);
            System.out.println("Correo enviado correctamente a " + destinatario);
            lblMensaje.setText("Correo enviado correctamente a " + destinatario);
            return true;
        } catch (AuthenticationFailedException e) {
            String msg = "Error de autenticación al enviar el correo. Verifica la contraseña de aplicación y que el acceso SMTP esté habilitado en tu cuenta de Gmail.";
            System.out.println(msg);
            lblMensaje.setText(msg);
            e.printStackTrace();
            return false;
        } catch (MessagingException e) {
            String msg = "Error de mensajería: " + e.getMessage();
            System.out.println(msg);
            lblMensaje.setText(msg);
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            String msg = "Error inesperado al enviar el correo: " + e.getMessage();
            System.out.println(msg);
            lblMensaje.setText(msg);
            e.printStackTrace();
            return false;
        }
    }
}
