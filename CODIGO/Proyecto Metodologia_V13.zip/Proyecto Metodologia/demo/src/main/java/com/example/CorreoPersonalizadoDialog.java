package com.example;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CorreoPersonalizadoDialog {
    public void mostrar(Stage parentStage) {
        Stage correoStage = new Stage();
        correoStage.setTitle("📧 Envío de Correo Personalizado - Sistema Moderno");
        correoStage.initModality(Modality.APPLICATION_MODAL);
        correoStage.setWidth(900);
        correoStage.setHeight(600);
        correoStage.setResizable(true);
        
        // Header moderno
        Label lblTitulo = new Label("📧 Envío de Correo Personalizado");
        lblTitulo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 28px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 0 0 5 0; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 2, 0, 0, 1);"
        );
        
        Label lblSubtitulo = new Label("Complete los campos para enviar un correo electrónico personalizado");
        lblSubtitulo.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-text-fill: #7f8c8d; " +
            "-fx-padding: 0 0 20 0;"
        );
        
        // Campos modernos
        TextField txtPara = new TextField();
        txtPara.setPromptText("correo@ejemplo.com");
        txtPara.setPrefHeight(40);
        txtPara.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 8; " +
            "-fx-background-radius: 8; " +
            "-fx-padding: 12; " +
            "-fx-font-size: 14px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);"
        );
        
        TextField txtAsunto = new TextField();
        txtAsunto.setPromptText("Asunto del correo electrónico");
        txtAsunto.setPrefHeight(40);
        txtAsunto.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 8; " +
            "-fx-background-radius: 8; " +
            "-fx-padding: 12; " +
            "-fx-font-size: 14px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);"
        );
        
        TextArea txtMensaje = new TextArea();
        txtMensaje.setPromptText("Escriba aquí su mensaje...");
        txtMensaje.setPrefHeight(180);
        txtMensaje.setWrapText(true);
        txtMensaje.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 8; " +
            "-fx-background-radius: 8; " +
            "-fx-padding: 12; " +
            "-fx-font-size: 14px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);"
        );

        // Labels modernos
        String labelStyle = 
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #34495e; " +
            "-fx-padding: 5 0;";
            
        Label lblPara = new Label("📮 Destinatario:");
        lblPara.setStyle(labelStyle);
        
        Label lblAsunto = new Label("📋 Asunto:");
        lblAsunto.setStyle(labelStyle);
        
        Label lblMensaje = new Label("✉️ Mensaje:");
        lblMensaje.setStyle(labelStyle);

        // Layout con GridPane moderno
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setStyle("-fx-padding: 30;");
        
        // Agregar campos al grid
        grid.add(lblPara, 0, 0);
        grid.add(txtPara, 1, 0);
        grid.add(lblAsunto, 0, 1);
        grid.add(txtAsunto, 1, 1);
        grid.add(lblMensaje, 0, 2);
        grid.add(txtMensaje, 1, 2);

        // Botones modernos
        Button btnEnviar = new Button("📤 Enviar Correo");
        btnEnviar.setPrefWidth(180);
        btnEnviar.setPrefHeight(45);
        btnEnviar.setStyle(
            "-fx-background-color: linear-gradient(to right, #27ae60, #2ecc71); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        Button btnCancelar = new Button("❌ Cancelar");
        btnCancelar.setPrefWidth(140);
        btnCancelar.setPrefHeight(45);
        btnCancelar.setStyle(
            "-fx-background-color: linear-gradient(to right, #e74c3c, #ec7063); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );

        // Efectos hover para los botones
        addButtonHoverEffect(btnEnviar, 
            "linear-gradient(to right, #27ae60, #2ecc71)", 
            "linear-gradient(to right, #2ecc71, #58d68d)");
        addButtonHoverEffect(btnCancelar, 
            "linear-gradient(to right, #e74c3c, #ec7063)", 
            "linear-gradient(to right, #ec7063, #f1948a)");

        // Acción del botón enviar con validación y operación asíncrona
        btnEnviar.setOnAction(_ -> {
            String para = txtPara.getText().trim();
            String asunto = txtAsunto.getText().trim();
            String mensaje = txtMensaje.getText().trim();
            
            // Validación de campos
            if (para.isEmpty()) {
                DialogUtils.showError("Por favor, ingrese el correo electrónico del destinatario.");
                txtPara.requestFocus();
                return;
            }
            
            if (!isValidEmail(para)) {
                DialogUtils.showError("Por favor, ingrese un correo electrónico válido.");
                txtPara.requestFocus();
                return;
            }
            
            if (asunto.isEmpty()) {
                DialogUtils.showError("Por favor, ingrese el asunto del correo.");
                txtAsunto.requestFocus();
                return;
            }
            
            if (mensaje.isEmpty()) {
                DialogUtils.showError("Por favor, escriba el mensaje del correo.");
                txtMensaje.requestFocus();
                return;
            }
            
            // Deshabilitar botones durante el envío
            btnEnviar.setDisable(true);
            btnCancelar.setDisable(true);
            
            // Crear indicador de progreso
            ProgressIndicator progressIndicator = new ProgressIndicator();
            progressIndicator.setPrefSize(30, 30);
            Label lblEnviando = new Label("📤 Enviando correo...");
            lblEnviando.setStyle(
                "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
                "-fx-font-size: 14px; " +
                "-fx-text-fill: #3498db; " +
                "-fx-font-weight: bold;"
            );
            
            HBox progressBox = new HBox(10, progressIndicator, lblEnviando);
            progressBox.setAlignment(Pos.CENTER);
            grid.add(progressBox, 0, 4, 2, 1);
            
            // Envío asíncrono del correo
            Task<Boolean> emailTask = new Task<Boolean>() {
                @Override
                protected Boolean call() throws Exception {
                    // Configuración del correo (deberías mover esto a un archivo de configuración)
                    String username = "santy.rojas.2005.santylol@gmail.com";
                    String password = "mtxxorlkbnpwjdkt";
                    String host = "smtp.gmail.com";
                    String port = "587";
                    
                    CorreoPersonalizado correo = new CorreoPersonalizado(username, password, host, port);
                    return correo.enviarCorreo(para, asunto, mensaje);
                }
                
                @Override
                protected void succeeded() {
                    Platform.runLater(() -> {
                        grid.getChildren().remove(progressBox);
                        btnEnviar.setDisable(false);
                        btnCancelar.setDisable(false);
                        
                        boolean enviado = getValue();
                        if (enviado) {
                            DialogUtils.showSuccess("✅ Correo enviado exitosamente a: " + para);
                            // Limpiar campos después del envío exitoso
                            txtPara.clear();
                            txtAsunto.clear();
                            txtMensaje.clear();
                        } else {
                            DialogUtils.showError("❌ Error al enviar el correo. Verifique la configuración SMTP y la conexión a internet.");
                        }
                    });
                }
                
                @Override
                protected void failed() {
                    Platform.runLater(() -> {
                        grid.getChildren().remove(progressBox);
                        btnEnviar.setDisable(false);
                        btnCancelar.setDisable(false);
                        
                        Throwable exception = getException();
                        String errorMsg = "Error desconocido";
                        if (exception != null) {
                            errorMsg = exception.getMessage();
                        }
                        DialogUtils.showError("❌ Error al enviar el correo: " + errorMsg);
                    });
                }
            };
            
            Thread emailThread = new Thread(emailTask);
            emailThread.setDaemon(true);
            emailThread.start();
        });

        btnCancelar.setOnAction((@SuppressWarnings("unused") var e) -> correoStage.close());

        HBox hboxBotones = new HBox(20, btnEnviar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        hboxBotones.setStyle("-fx-padding: 20 0;");
        grid.add(hboxBotones, 0, 3, 2, 1);

        // Header container
        VBox headerContainer = new VBox(5);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.getChildren().addAll(lblTitulo, lblSubtitulo);
        
        // Main container
        VBox mainContainer = new VBox(20);
        mainContainer.setAlignment(Pos.TOP_CENTER);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-padding: 30; " +
            "-fx-background-radius: 15; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 12, 0, 0, 4);"
        );
        mainContainer.getChildren().addAll(headerContainer, grid);
        
        // ScrollPane para manejar contenido
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(mainContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setStyle("-fx-background-color: transparent;");
        
        // Contenedor de fondo
        StackPane backgroundPane = new StackPane();
        backgroundPane.setStyle("-fx-background-color: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -fx-padding: 20;");
        backgroundPane.getChildren().add(scrollPane);

        Scene scene = new Scene(backgroundPane, 900, 600);
        correoStage.setScene(scene);
        correoStage.initOwner(parentStage);
        correoStage.show();
    }
    
    // Método auxiliar para validar email
    private boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }
    
    // Método auxiliar para efectos hover
    private void addButtonHoverEffect(Button button, String normalStyle, String hoverStyle) {
        String baseStyle = 
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; ";

        button.setOnMouseEntered((@SuppressWarnings("unused") var e) -> button.setStyle(
            "-fx-background-color: " + hoverStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 10, 0, 0, 4); " +
            "-fx-scale-x: 1.02; -fx-scale-y: 1.02;"
        ));

        button.setOnMouseExited((@SuppressWarnings("unused") var e) -> button.setStyle(
            "-fx-background-color: " + normalStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        ));
    }
}
