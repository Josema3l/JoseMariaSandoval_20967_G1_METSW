package com.example;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CrearUsuarioDialog {
    private final UsuarioService usuarioService;
    private final Stage parentStage;

    public CrearUsuarioDialog(UsuarioService usuarioService, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.parentStage = parentStage;
    }

    public void mostrar(Label lblMensaje) {
        Stage stage = new Stage();
        stage.setTitle("Crear Nuevo Usuario");
        stage.initModality(Modality.WINDOW_MODAL);
        stage.initOwner(parentStage);
        stage.setResizable(false);

        // Container principal con gradiente moderno
        VBox mainContainer = new VBox();
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #f8f9fa, #e9ecef);
            -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 0);
            """);

        // Header con título
        VBox headerBox = new VBox(10);
        headerBox.setPadding(new Insets(30, 30, 20, 30));
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2);");

        Label titulo = new Label("Crear Nuevo Usuario");
        titulo.setStyle("""
            -fx-font-size: 24px;
            -fx-font-weight: bold;
            -fx-text-fill: white;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.3), 2, 0, 1, 1);
            """);

        Label subtitulo = new Label("Complete la información del nuevo usuario");
        subtitulo.setStyle("""
            -fx-font-size: 14px;
            -fx-text-fill: rgba(255,255,255,0.9);
            """);

        headerBox.getChildren().addAll(titulo, subtitulo);

        // Formulario con GridPane para mejor organización
        GridPane formGrid = new GridPane();
        formGrid.setHgap(15);
        formGrid.setVgap(20);
        formGrid.setPadding(new Insets(30, 40, 30, 40));
        formGrid.setAlignment(Pos.CENTER);

        // Configurar columnas
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHalignment(HPos.RIGHT);
        col1.setPrefWidth(120);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPrefWidth(280);
        formGrid.getColumnConstraints().addAll(col1, col2);

        // Estilo común para labels
        String labelStyle = """
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-text-fill: #2c3e50;
            """;

        // Estilo común para campos de texto
        String fieldStyle = """
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-padding: 12;
            -fx-font-size: 14px;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);
            """;

        String fieldFocusStyle = fieldStyle + """
            -fx-border-color: #667eea;
            -fx-border-width: 2;
            """;

        // Campo Usuario
        Label lblUsuario = new Label("Usuario:");
        lblUsuario.setStyle(labelStyle);
        TextField txtUsuario = new TextField();
        txtUsuario.setStyle(fieldStyle);
        txtUsuario.setPromptText("Ingrese nombre de usuario");
        txtUsuario.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtUsuario.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        // Campo Contraseña
        Label lblContrasena = new Label("Contraseña:");
        lblContrasena.setStyle(labelStyle);
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setStyle(fieldStyle);
        txtContrasena.setPromptText("Ingrese contraseña");
        txtContrasena.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtContrasena.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        // Campo Correo
        Label lblCorreo = new Label("Correo:");
        lblCorreo.setStyle(labelStyle);
        TextField txtCorreo = new TextField();
        txtCorreo.setStyle(fieldStyle);
        txtCorreo.setPromptText("usuario@ejemplo.com");
        txtCorreo.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtCorreo.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        // Campo Rol
        Label lblRol = new Label("Rol:");
        lblRol.setStyle(labelStyle);
        ComboBox<String> comboRol = new ComboBox<>();
        comboRol.getItems().addAll("Administradora", "Cliente", "Tester");
        comboRol.setPromptText("Seleccione un rol");
        comboRol.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-font-size: 14px;
            """);
        comboRol.focusedProperty().addListener((obs, oldVal, newVal) -> {
            comboRol.setStyle(newVal ? 
                "-fx-background-color: white; -fx-border-color: #667eea; -fx-border-width: 2; -fx-border-radius: 8; -fx-background-radius: 8; -fx-font-size: 14px;" :
                "-fx-background-color: white; -fx-border-color: #ddd; -fx-border-radius: 8; -fx-background-radius: 8; -fx-font-size: 14px;");
        });

        // Agregar campos al grid
        formGrid.add(lblUsuario, 0, 0);
        formGrid.add(txtUsuario, 1, 0);
        formGrid.add(lblContrasena, 0, 1);
        formGrid.add(txtContrasena, 1, 1);
        formGrid.add(lblCorreo, 0, 2);
        formGrid.add(txtCorreo, 1, 2);
        formGrid.add(lblRol, 0, 3);
        formGrid.add(comboRol, 1, 3);

        // Botones con estilo moderno
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20, 30, 30, 30));

        Button btnCrear = new Button("Crear Usuario");
        btnCrear.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #28a745, #20a144);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCrear.setOnMouseEntered(e -> btnCrear.setStyle(btnCrear.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCrear.setOnMouseExited(e -> btnCrear.setStyle(btnCrear.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #6c757d, #5a6268);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCancelar.setOnMouseEntered(e -> btnCancelar.setStyle(btnCancelar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCancelar.setOnMouseExited(e -> btnCancelar.setStyle(btnCancelar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnCancelar.setOnAction(e -> stage.close());

        buttonBox.getChildren().addAll(btnCrear, btnCancelar);

        // Ensamblar la interfaz
        mainContainer.getChildren().addAll(headerBox, formGrid, buttonBox);

        // Acción del botón crear
        btnCrear.setOnAction(e -> {
            String usuario = txtUsuario.getText();
            String contrasena = txtContrasena.getText();
            String correo = txtCorreo.getText();
            String rol = comboRol.getValue();
            
            // Validación de campos vacíos
            if (usuario == null || usuario.trim().isEmpty() || 
                contrasena == null || contrasena.trim().isEmpty() || 
                correo == null || correo.trim().isEmpty() ||
                rol == null || rol.isEmpty()) {
                DialogUtils.showError("Debe completar todos los campos y seleccionar un rol");
                return;
            }
            
            // Validación del formato del correo
            if (!UsuarioService.esCorreoValido(correo.trim())) {
                DialogUtils.showError("El formato del correo electrónico no es válido");
                return;
            }
            
            // Validación de usuario único
            if (usuarioService.existeUsuario(usuario.trim())) {
                DialogUtils.showError("Ya existe un usuario con ese nombre. Elija otro nombre de usuario.");
                return;
            }
            
            // Validación de correo único
            if (usuarioService.existeCorreo(correo.trim())) {
                DialogUtils.showError("Ya existe un usuario registrado con ese correo electrónico.");
                return;
            }
            
            try {
                usuarioService.crearUsuario(usuario.trim(), contrasena, rol, correo.trim());
                DialogUtils.showSuccess("Usuario creado exitosamente: " + usuario + " (rol: " + rol + ")");
                stage.close();
            } catch (Exception ex) {
                DialogUtils.showError("Error al crear usuario: " + ex.getMessage());
            }
        });

        // Configurar escena
        Scene scene = new Scene(mainContainer, 550, 600);
        stage.setScene(scene);

        // Manejar tecla ESC
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stage.close();
            }
        });

        stage.showAndWait();
    }
}
