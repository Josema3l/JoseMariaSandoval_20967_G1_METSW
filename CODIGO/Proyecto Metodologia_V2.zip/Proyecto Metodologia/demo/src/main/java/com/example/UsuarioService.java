package com.example;

import java.util.HashMap;
import java.util.Map;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class UsuarioService {
    private Map<String, String[]> usuarios = new HashMap<>();

    public UsuarioService() {
        cargarUsuarios();
    }

    private void cargarUsuarios() {
        try {
            InputStream is = getClass().getResourceAsStream("/usuarios.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String linea;
            boolean primera = true;
            while ((linea = reader.readLine()) != null) {
                if (primera) { primera = false; continue; }
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    usuarios.put(partes[0], new String[]{partes[1], partes[2]});
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean verificarUsuario(String usuario, String contrasena) {
        return usuarios.containsKey(usuario) && usuarios.get(usuario)[0].equals(contrasena);
    }

    public String getRol(String usuario) {
        return usuarios.get(usuario)[1];
    }

    public void crearUsuario(String usuario, String contrasena, String rol) {
        usuarios.put(usuario, new String[]{contrasena, rol});
    }
}
