package com.example;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.stage.Stage;

public class PanelController {
    private final UsuarioService usuarioService;

    public PanelController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    public void mostrarPantallaPanel(Stage stage, String usuario, String rol) {
        Label lbl = new Label("Bienvenido/a: " + usuario);
        Button btnMapa = new Button("Mapa de Procesos");
        Button btnTabla = new Button("Tabla");
        Button btnCerrar = new Button("Cerrar sesión");
        Label lblMensaje = new Label();

        HBox topBar = new HBox();
        topBar.setAlignment(Pos.TOP_LEFT);
        MenuButton menuHamburguesa = null;
        if (rol.equals("administradora")) {
            menuHamburguesa = new MenuButton("≡");
            MenuItem crearUsuario = new MenuItem("Crear nuevo usuario");
            crearUsuario.setOnAction(_ -> mostrarDialogoCrearUsuario(lblMensaje));
            menuHamburguesa.getItems().add(crearUsuario);
            topBar.getChildren().add(menuHamburguesa);
        }

        StackPane panelCentral = new StackPane();
        panelCentral.setStyle(rol.equals("administradora") ? "-fx-background-color: #d1f2eb;" : "-fx-background-color:rgb(182, 200, 255);");

        VBox vboxMenu = new VBox(30);
        if (rol.equals("administradora")) {
            vboxMenu.getChildren().add(topBar);
        }
        vboxMenu.getChildren().addAll(lbl, btnMapa, btnTabla, btnCerrar, lblMensaje);
        vboxMenu.setAlignment(Pos.TOP_CENTER);
        vboxMenu.setPrefWidth(250);
        vboxMenu.setStyle("-fx-background-color:rgb(178, 226, 89);");

        btnCerrar.setOnAction(_ -> new LoginController().mostrarPantallaLogin(stage));
        btnMapa.setOnAction(_ -> {
            if (rol.equals("administradora")) {
                lblMensaje.setText("Abriendo mapa de procesos...");
                panelCentral.getChildren().clear();
                try {
                    Image mapaImg = new Image(getClass().getResourceAsStream("/mapa_procesos.png"));
                    ImageView mapaView = new ImageView(mapaImg);
                    mapaView.setPreserveRatio(true);
                    mapaView.setFitWidth(1250);

                    // Botones sobre el mapa
                    Button btnSistemasGestion = new Button("Sistemas de Gestión");
                    btnSistemasGestion.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnSistemasGestion.setPrefSize(85, 75);
                    btnSistemasGestion.setLayoutX(805);
                    btnSistemasGestion.setLayoutY(190);
                    btnSistemasGestion.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/MEJORA CONTINUA", lblMensaje));

                    Button btnGestionComercial = new Button("Gestión de Comercialización");
                    btnGestionComercial.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnGestionComercial.setPrefSize(80, 90);
                    btnGestionComercial.setLayoutX(310);
                    btnGestionComercial.setLayoutY(455);
                    btnGestionComercial.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/GESTION DE COMERCIALIZACION", lblMensaje));

                    Button btnAnalisis = new Button("Análisis Vulnerabilidad");
                    btnAnalisis.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnAnalisis.setPrefSize(150, 120);
                    btnAnalisis.setLayoutX(440);
                    btnAnalisis.setLayoutY(425);
                    btnAnalisis.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ANALISIS VULNERABILIDAD", lblMensaje));

                    Button btnInduccion = new Button("Inducción Vigilante");
                    btnInduccion.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnInduccion.setPrefSize(105, 120);
                    btnInduccion.setLayoutX(605);
                    btnInduccion.setLayoutY(425);
                    btnInduccion.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/INDUCCION VIGILANTE", lblMensaje));

                    Button btnOperaciones = new Button("Operaciones Fija - Móvil");
                    btnOperaciones.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnOperaciones.setPrefSize(125, 120);
                    btnOperaciones.setLayoutX(725);
                    btnOperaciones.setLayoutY(425);
                    btnOperaciones.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/OPERACIONES FIJA-MOVIL", lblMensaje));

                    Button btnSupervision = new Button("Supervisión Control");
                    btnSupervision.setStyle("-fx-background-color: rgba(0,200,255,0.4); -fx-border-color: #000;");
                    btnSupervision.setPrefSize(118, 120);
                    btnSupervision.setLayoutX(860);
                    btnSupervision.setLayoutY(425);
                    btnSupervision.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SUPERVISION CONTROL", lblMensaje));

                    Button btnSatisfaccion = new Button("Satisfacción al Cliente");
                    btnSatisfaccion.setStyle("-fx-background-color: rgba(0,255,100,0.4); -fx-border-color: #000;");
                    btnSatisfaccion.setPrefSize(45, 65);
                    btnSatisfaccion.setLayoutX(1060);
                    btnSatisfaccion.setLayoutY(450);
                    btnSatisfaccion.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SATISFACCION AL CLIENTE", lblMensaje));

                    Button btnAdmin1 = new Button("A1");
                    btnAdmin1.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin1.setPrefSize(65, 70);
                    btnAdmin1.setLayoutX(145);
                    btnAdmin1.setLayoutY(685);
                    btnAdmin1.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CONTABLE", lblMensaje));

                    Button btnAdmin2 = new Button("A2");
                    btnAdmin2.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin2.setPrefSize(85, 70);
                    btnAdmin2.setLayoutX(225);
                    btnAdmin2.setLayoutY(685);
                    btnAdmin2.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ADQUISICIONES", lblMensaje));

                    Button btnAdmin3 = new Button("A3");
                    btnAdmin3.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin3.setPrefSize(63, 85);
                    btnAdmin3.setLayoutX(320);
                    btnAdmin3.setLayoutY(685);
                    btnAdmin3.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SEGURIDAD FISICA", lblMensaje));

                    Button btnAdmin4 = new Button("A4");
                    btnAdmin4.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnAdmin4.setPrefSize(60, 70);
                    btnAdmin4.setLayoutX(400);
                    btnAdmin4.setLayoutY(685);
                    btnAdmin4.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/LOGISTICA", lblMensaje));

                    Button btnTalento1 = new Button("T1");
                    btnTalento1.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento1.setPrefSize(115, 70);
                    btnTalento1.setLayoutX(585);
                    btnTalento1.setLayoutY(700);
                    btnTalento1.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CONTRATACION", lblMensaje));

                    Button btnTalento2 = new Button("T2");
                    btnTalento2.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento2.setPrefSize(130, 70);
                    btnTalento2.setLayoutX(715);
                    btnTalento2.setLayoutY(700);
                    btnTalento2.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ADMINISTRACION", lblMensaje));

                    Button btnTalento3 = new Button("T3");
                    btnTalento3.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento3.setPrefSize(135, 70);
                    btnTalento3.setLayoutX(850);
                    btnTalento3.setLayoutY(700);
                    btnTalento3.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/DESVINCULACION", lblMensaje));

                    Button btnTalento4 = new Button("T4");
                    btnTalento4.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento4.setPrefSize(110, 70);
                    btnTalento4.setLayoutX(990);
                    btnTalento4.setLayoutY(700);
                    btnTalento4.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CAPACITACION", lblMensaje));

                    Button btnTalento5 = new Button("T5");
                    btnTalento5.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnTalento5.setPrefSize(90, 70);
                    btnTalento5.setLayoutX(480);
                    btnTalento5.setLayoutY(700);
                    btnTalento5.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SELECCION", lblMensaje));

                    Button btnGestionIT = new Button("Gestión de IT");
                    btnGestionIT.setStyle("-fx-background-color: rgba(255,100,255,0.4); -fx-border-color: #000;");
                    btnGestionIT.setPrefSize(60, 70);
                    btnGestionIT.setLayoutX(1140);
                    btnGestionIT.setLayoutY(700);
                    btnGestionIT.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/GESTION IT", lblMensaje));

                    Button btnDireccionEstrategica = new Button("DIRECCION ESTRATEGICA");
                    btnDireccionEstrategica.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnDireccionEstrategica.setPrefSize(100, 75);
                    btnDireccionEstrategica.setLayoutX(300);
                    btnDireccionEstrategica.setLayoutY(190);
                    btnDireccionEstrategica.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/DIRECCION ESTRATEGICA", lblMensaje));

                    Button btnRequisitosLegales = new Button("REQUISITOS LEGALES");
                    btnRequisitosLegales.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnRequisitosLegales.setPrefSize(90, 75);
                    btnRequisitosLegales.setLayoutX(425);
                    btnRequisitosLegales.setLayoutY(190);
                    btnRequisitosLegales.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/REQUISITOS LEGALES", lblMensaje));

                    Button btnFirmaContrato = new Button("FIRMA CONTRATO");
                    btnFirmaContrato.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnFirmaContrato.setPrefSize(82, 75);
                    btnFirmaContrato.setLayoutX(558);
                    btnFirmaContrato.setLayoutY(190);
                    btnFirmaContrato.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/FIRMA CONTRATO", lblMensaje));

                    Button btnNecesidadesPartes = new Button("NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS");
                    btnNecesidadesPartes.setStyle("-fx-background-color: rgba(255,200,0,0.4); -fx-border-color: #000;");
                    btnNecesidadesPartes.setPrefSize(100, 140);
                    btnNecesidadesPartes.setLayoutX(17);
                    btnNecesidadesPartes.setLayoutY(400);
                    btnNecesidadesPartes.setOnAction(e -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS", lblMensaje));

                    Pane overlay = new Pane();
                    overlay.setPickOnBounds(false);
                    overlay.getChildren().addAll(
                        mapaView,
                        btnDireccionEstrategica, btnRequisitosLegales, btnFirmaContrato, btnNecesidadesPartes,
                        btnSistemasGestion,
                        btnGestionComercial, btnAnalisis, btnInduccion, btnOperaciones, btnSupervision, btnSatisfaccion,
                        btnAdmin1, btnAdmin2, btnAdmin3, btnAdmin4,
                        btnTalento1, btnTalento2, btnTalento3, btnTalento4, btnTalento5,
                        btnGestionIT
                    );
                    panelCentral.getChildren().add(overlay);
                } catch (Exception ex) {
                    lblMensaje.setText("No se pudo cargar el mapa de procesos.");
                }
            } else {
                lblMensaje.setText("Acceso al mapa de procesos restringido.");
                panelCentral.getChildren().clear();
            }
        });
        btnTabla.setOnAction(_ -> {
            if (rol.equals("administradora")) {
                lblMensaje.setText("Abriendo tabla...");
            } else {
                lblMensaje.setText("Acceso a la tabla restringido.");
            }
        });

        BorderPane root = new BorderPane();
        root.setLeft(vboxMenu);
        root.setCenter(panelCentral);

        Scene scene = new Scene(root);
        stage.setTitle("Panel Principal");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();
    }

    private void mostrarDialogoCrearUsuario(Label lblMensaje) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Crear nuevo usuario");
        dialog.setHeaderText("Ingrese el nuevo usuario y contraseña separados por coma (usuario,contraseña,rol):");
        dialog.setContentText("Datos:");
        dialog.showAndWait().ifPresent(input -> {
            String[] partes = input.split(",");
            if (partes.length == 3) {
                usuarioService.crearUsuario(partes[0], partes[1], partes[2]);
                lblMensaje.setText("Usuario creado: " + partes[0] + " (rol: " + partes[2] + ")");
            } else {
                lblMensaje.setText("Formato incorrecto. Use: usuario,contraseña,rol");
            }
        });
    }

    // Método utilitario para abrir carpetas
    private void abrirCarpeta(String folderPath, Label lblMensaje) {
        try {
            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
        } catch (Exception ex) {
            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
        }
    }
}
