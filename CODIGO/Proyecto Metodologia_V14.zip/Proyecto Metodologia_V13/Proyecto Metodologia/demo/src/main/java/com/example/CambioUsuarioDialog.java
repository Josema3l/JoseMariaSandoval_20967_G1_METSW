package com.example;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CambioUsuarioDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioUsuarioDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar Nombre de Usuario");
        stageCambio.initModality(Modality.WINDOW_MODAL);
        stageCambio.initOwner(parentStage);
        stageCambio.setResizable(false);

        // Container principal con gradiente moderno
        VBox mainContainer = new VBox();
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #f8f9fa, #e9ecef);
            -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 0);
            """);

        // Header con título
        VBox headerBox = new VBox(10);
        headerBox.setPadding(new Insets(30, 30, 20, 30));
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: linear-gradient(to right, #667eea, #764ba2);");

        Label titulo = new Label("Cambiar Nombre de Usuario");
        titulo.setStyle("""
            -fx-font-size: 24px;
            -fx-font-weight: bold;
            -fx-text-fill: white;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.3), 2, 0, 1, 1);
            """);

        Label subtitulo = new Label("Actualice el nombre de usuario");
        subtitulo.setStyle("""
            -fx-font-size: 14px;
            -fx-text-fill: rgba(255,255,255,0.9);
            """);

        headerBox.getChildren().addAll(titulo, subtitulo);

        // Formulario con GridPane
        GridPane formGrid = new GridPane();
        formGrid.setHgap(15);
        formGrid.setVgap(20);
        formGrid.setPadding(new Insets(30, 40, 30, 40));
        formGrid.setAlignment(Pos.CENTER);

        // Configurar columnas
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setHalignment(HPos.RIGHT);
        col1.setPrefWidth(150);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPrefWidth(280);
        formGrid.getColumnConstraints().addAll(col1, col2);

        // Estilo común para labels
        String labelStyle = """
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-text-fill: #2c3e50;
            """;

        // Estilo común para campos
        String fieldStyle = """
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-padding: 12;
            -fx-font-size: 14px;
            -fx-effect: innershadow(one-pass-box, rgba(0,0,0,0.1), 2, 0, 0, 1);
            """;

        String fieldFocusStyle = fieldStyle + """
            -fx-border-color: #667eea;
            -fx-border-width: 2;
            """;

        int rowIndex = 0;

        // Determinar si el usuario actual tiene privilegios administrativos
        boolean esPrivilegiado = rol.equalsIgnoreCase("Tester") || rol.equalsIgnoreCase("Administradora");
        
        // Campo Usuario Actual
        Label lblUsuarioActual = new Label(esPrivilegiado ? "Usuario a modificar:" : "Su usuario:");
        lblUsuarioActual.setStyle(labelStyle);
        ComboBox<String> comboUsuarioActual = new ComboBox<>();
        comboUsuarioActual.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 8;
            -fx-background-radius: 8;
            -fx-font-size: 14px;
            """);

        // Configurar combo box según el rol
        if (esPrivilegiado) {
            comboUsuarioActual.getItems().addAll(usuarioService.getTodosLosUsuarios());
            comboUsuarioActual.setPromptText("Seleccione usuario");
        } else {
            comboUsuarioActual.getItems().add(usuario);
            comboUsuarioActual.setValue(usuario);
            comboUsuarioActual.setDisable(true);
        }

        formGrid.add(lblUsuarioActual, 0, rowIndex);
        formGrid.add(comboUsuarioActual, 1, rowIndex++);

        // CheckBox para cambio administrativo (solo para usuarios privilegiados)
        CheckBox chkCambioAdministrativo = null;
        if (esPrivilegiado) {
            chkCambioAdministrativo = new CheckBox("Cambio administrativo (sin verificar contraseña actual)");
            chkCambioAdministrativo.setStyle("""
                -fx-text-fill: #2c3e50;
                -fx-font-size: 12px;
                -fx-font-weight: 600;
                """);
            
            GridPane.setColumnSpan(chkCambioAdministrativo, 2);
            GridPane.setHalignment(chkCambioAdministrativo, HPos.CENTER);
            formGrid.add(chkCambioAdministrativo, 0, rowIndex++);
        }

        // Campo Nuevo Usuario
        Label lblNuevoUsuario = new Label("Nuevo nombre de usuario:");
        lblNuevoUsuario.setStyle(labelStyle);
        TextField txtNuevoUsuario = new TextField();
        txtNuevoUsuario.setStyle(fieldStyle);
        txtNuevoUsuario.setPromptText("Ingrese nuevo nombre de usuario");
        txtNuevoUsuario.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtNuevoUsuario.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        formGrid.add(lblNuevoUsuario, 0, rowIndex);
        formGrid.add(txtNuevoUsuario, 1, rowIndex++);

        // Campo Contraseña Actual
        Label lblContrasenaActual = new Label("Contraseña actual:");
        lblContrasenaActual.setStyle(labelStyle);
        PasswordField txtContrasenaActual = new PasswordField();
        txtContrasenaActual.setStyle(fieldStyle);
        txtContrasenaActual.setPromptText("Ingrese contraseña actual");
        txtContrasenaActual.focusedProperty().addListener((obs, oldVal, newVal) -> {
            txtContrasenaActual.setStyle(newVal ? fieldFocusStyle : fieldStyle);
        });

        formGrid.add(lblContrasenaActual, 0, rowIndex);
        formGrid.add(txtContrasenaActual, 1, rowIndex++);

        // Listener para cambio administrativo
        final CheckBox finalChk = chkCambioAdministrativo;
        if (chkCambioAdministrativo != null) {
            chkCambioAdministrativo.setOnAction(e -> {
                boolean isSelected = finalChk.isSelected();
                txtContrasenaActual.setDisable(isSelected);
                lblContrasenaActual.setDisable(isSelected);
                if (isSelected) {
                    txtContrasenaActual.clear();
                }
            });
        }

        // Botones con estilo moderno
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20, 30, 30, 30));

        Button btnCambiar = new Button("Cambiar Usuario");
        btnCambiar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #28a745, #20a144);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCambiar.setOnMouseEntered(e -> btnCambiar.setStyle(btnCambiar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCambiar.setOnMouseExited(e -> btnCambiar.setStyle(btnCambiar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("""
            -fx-background-color: linear-gradient(to bottom, #6c757d, #5a6268);
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: 600;
            -fx-background-radius: 8;
            -fx-padding: 12 24;
            -fx-cursor: hand;
            -fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 4, 0, 0, 2);
            """);
        btnCancelar.setOnMouseEntered(e -> btnCancelar.setStyle(btnCancelar.getStyle() + "-fx-scale-y: 1.05; -fx-scale-x: 1.05;"));
        btnCancelar.setOnMouseExited(e -> btnCancelar.setStyle(btnCancelar.getStyle().replace("-fx-scale-y: 1.05; -fx-scale-x: 1.05;", "")));
        btnCancelar.setOnAction(e -> stageCambio.close());

        buttonBox.getChildren().addAll(btnCambiar, btnCancelar);

        // Ensamblar la interfaz
        mainContainer.getChildren().addAll(headerBox, formGrid, buttonBox);

        // Configurar escena
        Scene scene = new Scene(mainContainer, 600, 600);
        stageCambio.setScene(scene);

        // Manejar tecla ESC
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        // Referencia final para usar en el lambda
        final CheckBox finalChkCambioAdministrativo = chkCambioAdministrativo;

        // Lógica para cambiar el nombre de usuario
        btnCambiar.setOnAction(e -> {
            String usuarioObjetivo = comboUsuarioActual.getValue();
            String nuevoUsuario = txtNuevoUsuario.getText().trim();
            String contrasenaActual = txtContrasenaActual.getText().trim();

            // Validaciones básicas
            if (usuarioObjetivo == null || usuarioObjetivo.isEmpty()) {
                DialogUtils.showError("Debe seleccionar un usuario.");
                return;
            }

            if (nuevoUsuario.isEmpty()) {
                DialogUtils.showError("Debe especificar un nuevo nombre de usuario.");
                return;
            }

            // Verificar si el nuevo usuario ya existe
            if (usuarioService.getTodosLosUsuarios().contains(nuevoUsuario)) {
                DialogUtils.showError("El nombre de usuario ya está en uso.");
                return;
            }

            // Verificar si es el mismo nombre
            if (usuarioObjetivo.equals(nuevoUsuario)) {
                DialogUtils.showError("El nuevo nombre debe ser diferente al actual.");
                return;
            }

            // Determinar si es un cambio administrativo
            boolean esCambioAdministrativo = esPrivilegiado && 
                                           finalChkCambioAdministrativo != null && 
                                           finalChkCambioAdministrativo.isSelected();

            // Verificación de contraseña según el tipo de cambio
            if (!esCambioAdministrativo) {
                if (contrasenaActual.isEmpty()) {
                    DialogUtils.showError("Debe ingresar la contraseña actual.");
                    return;
                }

                // Para usuarios privilegiados, verificar la contraseña del usuario objetivo
                String usuarioParaVerificar = esPrivilegiado ? usuarioObjetivo : usuario;
                if (!usuarioService.verificarCredenciales(usuarioParaVerificar, contrasenaActual)) {
                    DialogUtils.showError("Contraseña actual incorrecta.");
                    return;
                }
            }

            // Realizar el cambio
            try {
                usuarioService.cambiarCredenciales(
                    usuarioObjetivo,
                    nuevoUsuario,
                    null // No cambiar la contraseña
                );
                
                String mensaje = esCambioAdministrativo ? 
                    "Nombre de usuario cambiado exitosamente (cambio administrativo)." : 
                    "Nombre de usuario cambiado exitosamente.";
                
                DialogUtils.showSuccess(mensaje);
                stageCambio.close();
            } catch (Exception ex) {
                DialogUtils.showError("Error al cambiar el nombre de usuario: " + ex.getMessage());
            }
        });

        stageCambio.showAndWait();
    }
}