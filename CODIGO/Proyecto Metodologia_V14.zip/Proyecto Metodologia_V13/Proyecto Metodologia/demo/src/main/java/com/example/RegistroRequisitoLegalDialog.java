package com.example;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class RegistroRequisitoLegalDialog {
    private final Stage parentStage;
    private final RequisitoLegalService requisitoLegalService;
    private List<File> archivosSeleccionados;

    public RegistroRequisitoLegalDialog(Stage parentStage) {
        this.parentStage = parentStage;
        this.requisitoLegalService = new RequisitoLegalService();
        this.archivosSeleccionados = new ArrayList<>();
    }

    public void mostrar() {
        Stage registroStage = new Stage();
        registroStage.setWidth(900); 
        registroStage.setHeight(650);
        registroStage.setTitle("⚖️ Registro de Requisito Legal - Sistema Moderno");
        
        // Header moderno más compacto
        Label lblTitulo = new Label("⚖️ Registro de Requisito Legal");
        lblTitulo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 24px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 0 0 5 0; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 2, 0, 0, 1);"
        );
        
        Label lblSubtitulo = new Label("Complete todos los campos requeridos para registrar el requisito legal");
        lblSubtitulo.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 12px; " +
            "-fx-text-fill: #7f8c8d; " +
            "-fx-padding: 0 0 15 0;"
        );
        
        // Campos modernos con estilo más compacto
        TextField txtNombreRequisitoLegal = new TextField();
        txtNombreRequisitoLegal.setPromptText("Ej: Licencia Ambiental, Permiso Sanitario, etc.");
        txtNombreRequisitoLegal.setPrefHeight(35);
        txtNombreRequisitoLegal.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 6; " +
            "-fx-background-radius: 6; " +
            "-fx-padding: 8; " +
            "-fx-font-size: 13px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        DatePicker dtpFechaEmision = new DatePicker();
        dtpFechaEmision.setPrefHeight(35);
        dtpFechaEmision.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 6; " +
            "-fx-background-radius: 6; " +
            "-fx-font-size: 13px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        DatePicker dtpFechaVencimiento = new DatePicker();
        dtpFechaVencimiento.setPrefHeight(35);
        dtpFechaVencimiento.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 6; " +
            "-fx-background-radius: 6; " +
            "-fx-font-size: 13px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        DatePicker dtpFechaProximaRenovacion = new DatePicker();
        dtpFechaProximaRenovacion.setPrefHeight(35);
        dtpFechaProximaRenovacion.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 6; " +
            "-fx-background-radius: 6; " +
            "-fx-font-size: 13px; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        CheckBox chkNoVence = new CheckBox("🔄 No vence");
        chkNoVence.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 13px; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-font-weight: bold;"
        );

        // Manejo de checkbox para deshabilitar ambos DatePicker
        chkNoVence.setOnAction(_ -> {
            if (chkNoVence.isSelected()) {
                dtpFechaVencimiento.setDisable(true);
                dtpFechaVencimiento.setValue(null);
                dtpFechaProximaRenovacion.setDisable(true);
                dtpFechaProximaRenovacion.setValue(null);
            } else {
                dtpFechaVencimiento.setDisable(false);
                dtpFechaProximaRenovacion.setDisable(false);
            }
        });

        // Sección para archivos moderna y compacta
        Label lblArchivos = new Label("📎 Documentos adjuntos:");
        lblArchivos.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 5 0 3 0;"
        );
        
        ListView<String> listViewArchivos = new ListView<>();
        listViewArchivos.setPrefHeight(100);
        listViewArchivos.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 6; " +
            "-fx-background-radius: 6; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 12px;"
        );

        Button btnSeleccionarArchivos = new Button("📂 Seleccionar");
        btnSeleccionarArchivos.setPrefWidth(140);
        btnSeleccionarArchivos.setPrefHeight(35);
        btnSeleccionarArchivos.setStyle(
            "-fx-background-color: linear-gradient(to right, #8e44ad, #9b59b6); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 12px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 6; " +
            "-fx-border-radius: 6; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnSeleccionarArchivos.setOnAction(_ -> seleccionarArchivos(listViewArchivos));

        Button btnEliminarArchivo = new Button("🗑️ Eliminar");
        btnEliminarArchivo.setPrefWidth(140);
        btnEliminarArchivo.setPrefHeight(35);
        btnEliminarArchivo.setStyle(
            "-fx-background-color: linear-gradient(to right, #e74c3c, #ec7063); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 12px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 6; " +
            "-fx-border-radius: 6; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnEliminarArchivo.setOnAction(_ -> eliminarArchivoSeleccionado(listViewArchivos));

        HBox hboxArchivos = new HBox(10, btnSeleccionarArchivos, btnEliminarArchivo);
        hboxArchivos.setAlignment(Pos.CENTER_LEFT);

        // Layout moderno con GridPane en 2 columnas
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(15);
        grid.setStyle("-fx-padding: 20;");
        
        // Labels modernos más compactos
        String labelStyle = 
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 13px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #34495e;";
        
        // Primera fila
        Label lblNombre = new Label("⚖️ Nombre del Requisito Legal:");
        lblNombre.setStyle(labelStyle);
        grid.add(lblNombre, 0, 0);
        grid.add(txtNombreRequisitoLegal, 1, 0);
        
        // Segunda fila
        Label lblFechaEmision = new Label("📅 Fecha de emisión:");
        lblFechaEmision.setStyle(labelStyle);
        grid.add(lblFechaEmision, 0, 1);
        grid.add(dtpFechaEmision, 1, 1);
        
        // Tercera fila
        Label lblFechaVencimiento = new Label("⏰ Fecha de vencimiento:");
        lblFechaVencimiento.setStyle(labelStyle);
        grid.add(lblFechaVencimiento, 0, 2);
        HBox hboxVencimiento = new HBox(10, dtpFechaVencimiento, chkNoVence);
        hboxVencimiento.setAlignment(Pos.CENTER_LEFT);
        grid.add(hboxVencimiento, 1, 2);
        
        // Cuarta fila
        Label lblFechaRenovacion = new Label("🔄 Fecha próxima de renovación:");
        lblFechaRenovacion.setStyle(labelStyle);
        grid.add(lblFechaRenovacion, 0, 3);
        grid.add(dtpFechaProximaRenovacion, 1, 3);
        
        // Quinta fila - Archivos
        grid.add(lblArchivos, 0, 4);
        grid.add(listViewArchivos, 1, 4);
        grid.add(hboxArchivos, 1, 5);

        // Botones más compactos
        Button btnGuardar = new Button("💾 Guardar Requisito Legal");
        btnGuardar.setPrefWidth(200);
        btnGuardar.setPrefHeight(40);
        btnGuardar.setStyle(
            "-fx-background-color: linear-gradient(to right, #8e44ad, #9b59b6); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8; " +
            "-fx-border-radius: 8; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnGuardar.setOnAction(_ -> {
            String nombreRequisitoLegal = txtNombreRequisitoLegal.getText().trim();
            LocalDate fechaEmision = dtpFechaEmision.getValue();
            String valorNV = "NV";
            String fechaVencimientoStr = chkNoVence.isSelected() ? valorNV : (dtpFechaVencimiento.getValue() != null ? dtpFechaVencimiento.getValue().toString() : null);
            String fechaProximaRenovacionStr = chkNoVence.isSelected() ? valorNV : (dtpFechaProximaRenovacion.getValue() != null ? dtpFechaProximaRenovacion.getValue().toString() : null);

            // Validación de campos obligatorios
            if (nombreRequisitoLegal.isEmpty() || fechaEmision == null) {
                DialogUtils.mostrarAviso(grid, "Por favor, complete todos los campos obligatorios: Nombre del requisito legal y Fecha de emisión.", false, null);
                return;
            }

            // Verificar que el requisito legal no exista ya - por ahora sin validación
            // TODO: Implementar método existeRequisito en RequisitoLegalService
            /*
            if (requisitoLegalService.existeRequisito(nombreRequisitoLegal)) {
                DialogUtils.mostrarAviso(grid, "Ya existe un requisito legal con el nombre: " + nombreRequisitoLegal + ". Por favor, use un nombre diferente.", false, null);
                return;
            }
            */

            // Validación de fechas solo si no es "No vence"
            if (!chkNoVence.isSelected()) {
                if (fechaVencimientoStr == null || fechaProximaRenovacionStr == null) {
                    DialogUtils.mostrarAviso(grid, "Si el requisito vence, debe ingresar tanto la fecha de vencimiento como la fecha de próxima renovación.", false, null);
                    return;
                }

                LocalDate fechaVencimiento = dtpFechaVencimiento.getValue();
                LocalDate fechaProximaRenovacion = dtpFechaProximaRenovacion.getValue();
                
                if (fechaVencimiento != null && fechaVencimiento.isBefore(fechaEmision)) {
                    DialogUtils.mostrarAviso(grid, "La fecha de vencimiento no puede ser anterior a la fecha de emisión.", false, null);
                    return;
                }
                if (fechaProximaRenovacion != null) {
                    if (!fechaProximaRenovacion.isAfter(fechaEmision)) {
                        DialogUtils.mostrarAviso(grid, "La fecha próxima de renovación debe ser mayor que la fecha de emisión.", false, null);
                        return;
                    }
                    if (fechaVencimiento != null && !fechaProximaRenovacion.isBefore(fechaVencimiento)) {
                        DialogUtils.mostrarAviso(grid, "La fecha próxima de renovación debe ser menor que la fecha de vencimiento.", false, null);
                        return;
                    }
                }
            }
            
            // Validar que al menos se haya seleccionado un archivo
            if (archivosSeleccionados == null || archivosSeleccionados.isEmpty()) {
                DialogUtils.mostrarAviso(grid, "Debe adjuntar al menos un archivo para registrar el requisito legal.", false, null);
                return;
            }

            try {
                // Convertir fechas string a LocalDate para el servicio
                LocalDate fechaVencimientoLD = chkNoVence.isSelected() ? null : dtpFechaVencimiento.getValue();
                LocalDate fechaProximaRenovacionLD = chkNoVence.isSelected() ? null : dtpFechaProximaRenovacion.getValue();
                
                // Guardar requisito legal usando el servicio
                String resultado = requisitoLegalService.guardarRequisitoLegal(
                    nombreRequisitoLegal,
                    fechaEmision,
                    fechaVencimientoLD,
                    fechaProximaRenovacionLD,
                    archivosSeleccionados
                );

                if (resultado != null && !resultado.startsWith("Error")) {
                    DialogUtils.mostrarAviso(grid, "Requisito legal registrado exitosamente.", true, () -> {
                        txtNombreRequisitoLegal.clear();
                        dtpFechaEmision.setValue(null);
                        dtpFechaVencimiento.setValue(null);
                        dtpFechaProximaRenovacion.setValue(null);
                        chkNoVence.setSelected(false);
                        dtpFechaVencimiento.setDisable(false);
                        dtpFechaProximaRenovacion.setDisable(false);
                        archivosSeleccionados.clear();
                        listViewArchivos.getItems().clear();
                    });
                } else {
                    DialogUtils.mostrarAviso(grid, "Error al guardar el requisito legal: " + resultado, false, null);
                }

            } catch (Exception ex) {
                DialogUtils.mostrarAviso(grid, "Error al guardar el requisito legal: " + ex.getMessage(), false, null);
                ex.printStackTrace();
            }
        });

        Button btnCancelar = new Button("❌ Cancelar");
        btnCancelar.setPrefWidth(130);
        btnCancelar.setPrefHeight(40);
        btnCancelar.setStyle(
            "-fx-background-color: linear-gradient(to right, #e74c3c, #ec7063); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8; " +
            "-fx-border-radius: 8; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(_ -> registroStage.close());

        HBox hboxBotones = new HBox(15, btnGuardar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        hboxBotones.setStyle("-fx-padding: 15 0;");
        grid.add(hboxBotones, 0, 6, 2, 1); // Span across both columns

        // Header y contenedor principal más compacto
        VBox headerContainer = new VBox(3);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.getChildren().addAll(lblTitulo, lblSubtitulo);
        
        VBox mainContainer = new VBox(15);
        mainContainer.setAlignment(Pos.TOP_CENTER);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-padding: 20; " +
            "-fx-background-radius: 10; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 8, 0, 0, 2);"
        );
        mainContainer.getChildren().addAll(headerContainer, grid);
        
        // ScrollPane para manejar contenido que no quepa
        javafx.scene.control.ScrollPane scrollPane = new javafx.scene.control.ScrollPane();
        scrollPane.setContent(mainContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        scrollPane.setHbarPolicy(javafx.scene.control.ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(javafx.scene.control.ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setStyle("-fx-background-color: transparent;");
        
        // Contenedor de fondo
        javafx.scene.layout.StackPane backgroundPane = new javafx.scene.layout.StackPane();
        backgroundPane.setStyle("-fx-background-color: linear-gradient(135deg, #764ba2 0%, #667eea 100%); -fx-padding: 15;");
        backgroundPane.getChildren().add(scrollPane);

        Scene scene = new Scene(backgroundPane, 900, 650);
        registroStage.setScene(scene);
        registroStage.initOwner(parentStage);
        registroStage.show();

        // Cerrar conexión cuando se cierre la ventana
        registroStage.setOnCloseRequest(_ -> cerrarConexion());
    }

    private void seleccionarArchivos(ListView<String> listViewArchivos) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivos");

        // Configurar filtros de archivo (igual que en documentos)
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Documentos Excel", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp"),
            new FileChooser.ExtensionFilter("Archivos de texto", "*.txt", "*.rtf")
        );

        List<File> archivos = fileChooser.showOpenMultipleDialog(parentStage);
        if (archivos != null) {
            for (File archivo : archivos) {
                if (!archivosSeleccionados.contains(archivo)) {
                    archivosSeleccionados.add(archivo);
                    listViewArchivos.getItems().add(archivo.getName() + " (" + formatFileSize(archivo.length()) + ")");
                }
            }
        }
    }

    private void eliminarArchivoSeleccionado(ListView<String> listViewArchivos) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            archivosSeleccionados.remove(selectedIndex);
            listViewArchivos.getItems().remove(selectedIndex);
        }
    }

    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024.0));
        return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
    }

    public void cerrarConexion() {
        if (requisitoLegalService != null) {
            requisitoLegalService.close();
        }
    }
}
