package com.example;

import java.time.LocalDate;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PanelController {
    private final UsuarioService usuarioService;
    private final DocumentoService documentoService = new DocumentoService();
    // private Stage mainStage; // removed duplicate

    public PanelController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // setMainStage is defined only once at the top of the class

    public void mostrarPantallaPanel(Stage stage, String usuario, String rol) {
        // Botones del menú principal con diseño moderno
        Button btnMapa = new Button("📋 Mapa de Procesos");
        btnMapa.setPrefWidth(280);
        btnMapa.setPrefHeight(55);
        btnMapa.setStyle(
            "-fx-background-color: linear-gradient(to right, #667eea, #764ba2); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        );

        Button btnTabla = new Button("📄 Control de Documentos");
        btnTabla.setPrefWidth(280);
        btnTabla.setPrefHeight(55);
        btnTabla.setStyle(
            "-fx-background-color: linear-gradient(to right, #11998e, #38ef7d); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        );
        
        Button btnGestionRequisitos = new Button("⚖️ Requisitos Legales");
        btnGestionRequisitos.setPrefWidth(280);
        btnGestionRequisitos.setPrefHeight(55);
        btnGestionRequisitos.setStyle(
            "-fx-background-color: linear-gradient(to right, #fc4a1a, #f7b733); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        );
        
        Button btnCorreoPersonalizado = new Button("✉️ Correo Personalizado");
        btnCorreoPersonalizado.setPrefWidth(280);
        btnCorreoPersonalizado.setPrefHeight(55);
        btnCorreoPersonalizado.setStyle(
            "-fx-background-color: linear-gradient(to right, #667eea, #764ba2); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        );

        Button btnCerrar = new Button("🚪 Cerrar Sesión");
        btnCerrar.setPrefWidth(280);
        btnCerrar.setPrefHeight(55);
        btnCerrar.setStyle(
            "-fx-background-color: linear-gradient(to right, #eb3349, #f45c43); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        );

        // Efectos hover para los botones
        addHoverEffect(btnMapa, "linear-gradient(to right, #667eea, #764ba2)", "linear-gradient(to right, #7b8cec, #8a5cae)");
        addHoverEffect(btnTabla, "linear-gradient(to right, #11998e, #38ef7d)", "linear-gradient(to right, #17a2a2, #4cf287)");
        addHoverEffect(btnGestionRequisitos, "linear-gradient(to right, #fc4a1a, #f7b733)", "linear-gradient(to right, #fd5e2e, #f8c247)");
        addHoverEffect(btnCorreoPersonalizado, "linear-gradient(to right, #667eea, #764ba2)", "linear-gradient(to right, #7b8cec, #8a5cae)");
        addHoverEffect(btnCerrar, "linear-gradient(to right, #eb3349, #f45c43)", "linear-gradient(to right, #ed4759, #f56d57)");

        btnCorreoPersonalizado.setOnAction(_ -> {
            new CorreoPersonalizadoDialog().mostrar(stage);
        });

        // Botón de enviar recordatorios (solo para Administradora)
        Button btnEnviarRecordatorios = new Button("🔔 Enviar Recordatorios");
        btnEnviarRecordatorios.setPrefWidth(280);
        btnEnviarRecordatorios.setPrefHeight(55);
        btnEnviarRecordatorios.setStyle(
            "-fx-background-color: linear-gradient(to right, #ffecd2, #fcb69f); " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        );
        addHoverEffect(btnEnviarRecordatorios, "linear-gradient(to right, #ffecd2, #fcb69f)", "linear-gradient(to right, #fff0d6, #fdc4a9)");

        Label lblMensaje = new Label();
        lblMensaje.setStyle("-fx-font-size: 14px; -fx-text-fill: #2c3e50; -fx-font-weight: bold; -fx-padding: 10 0;");

        // Menú hamburguesa moderno
        MenuButton menuHamburguesa = new MenuButton();
        menuHamburguesa.setText("");
        menuHamburguesa.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-background-radius: 25; " +
            "-fx-border-radius: 25; " +
            "-fx-padding: 12; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2);"
        );
        
        javafx.scene.shape.SVGPath iconoHamburguesa = new javafx.scene.shape.SVGPath();
        iconoHamburguesa.setContent("M3 7h18M3 12h18M3 17h18");
        iconoHamburguesa.setStroke(javafx.scene.paint.Color.web("#2c3e50"));
        iconoHamburguesa.setStrokeWidth(2.5);
        iconoHamburguesa.setFill(javafx.scene.paint.Color.TRANSPARENT);
        iconoHamburguesa.setScaleX(1.2);
        iconoHamburguesa.setScaleY(1.2);
        menuHamburguesa.setGraphic(iconoHamburguesa);
        menuHamburguesa.setPrefSize(50, 50);
        menuHamburguesa.setPopupSide(javafx.geometry.Side.BOTTOM);

        MenuItem cambiarUsuario = new MenuItem("👤 Cambiar usuario");
        cambiarUsuario.setOnAction(_ -> {
            new CambioUsuarioDialog(usuarioService, usuario, rol, stage).mostrar();
        });
        MenuItem cambiarContrasena = new MenuItem("🔑 Cambiar contraseña");
        cambiarContrasena.setOnAction(_ -> {
            new CambioContrasenaDialog(usuarioService, usuario, rol, stage).mostrar();
        });

        if (rol.equalsIgnoreCase("Administradora") || rol.equalsIgnoreCase("Tester")) {
            MenuItem crearUsuario = new MenuItem("➕ Crear nuevo usuario");
            crearUsuario.setOnAction(_ -> mostrarDialogoCrearUsuario(lblMensaje));
            menuHamburguesa.getItems().addAll(crearUsuario, cambiarUsuario, cambiarContrasena);
        } else if (rol.equalsIgnoreCase("Cliente")) {
            menuHamburguesa.getItems().addAll(cambiarUsuario, cambiarContrasena);
        }

        // Panel central moderno
        StackPane panelCentral = new StackPane();
        String gradient = rol.equals("Administradora")
            ? "-fx-background-color: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"
            : "-fx-background-color: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);";
        panelCentral.setStyle(gradient);

        // Header de bienvenida modernizado
        VBox headerBienvenida = new VBox(10);
        headerBienvenida.setAlignment(Pos.CENTER);
        
        Label lblSaludo = new Label("¡Hola, " + usuario + "!");
        lblSaludo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 48px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: rgba(54, 71, 90, 1); " +
            "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.3), 0, 0, 0, 3);"
        );

        // Icono decorativo
        Label iconoBienvenida = new Label("🎯");
        iconoBienvenida.setStyle("-fx-font-size: 72px; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 2);");

        headerBienvenida.getChildren().addAll(iconoBienvenida, lblSaludo);

        panelCentral.getChildren().add(headerBienvenida);
        StackPane.setAlignment(headerBienvenida, Pos.CENTER);
        
        // Menú lateral moderno
        VBox vboxMenu = new VBox();
        vboxMenu.setSpacing(20);
        vboxMenu.setPadding(new javafx.geometry.Insets(30, 25, 30, 25));
        
        // Solo Administradora ve el botón de recordatorios
        if (rol.equals("Administradora")) {
            vboxMenu.getChildren().add(btnEnviarRecordatorios);
            btnEnviarRecordatorios.setOnAction(_ -> revisarYEnviarRecordatorios(lblMensaje));
        }
        
        vboxMenu.getChildren().addAll(btnMapa, btnTabla, btnGestionRequisitos, btnCorreoPersonalizado, btnCerrar, lblMensaje);
        vboxMenu.setAlignment(Pos.TOP_CENTER);
        vboxMenu.setPrefWidth(330);
        vboxMenu.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-border-color: rgba(0,0,0,0.1); " +
            "-fx-border-width: 0 1px 0 0; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 2, 0);"
        );

        // --- Botón Cerrar Mapa (siempre presente pero oculto, se muestra solo con el mapa) ---
        Button btnCerrarMapaLateral = new Button("✖️ Cerrar mapa");
        btnCerrarMapaLateral.setPrefWidth(280);
        btnCerrarMapaLateral.setPrefHeight(45);
        btnCerrarMapaLateral.setStyle(
            "-fx-background-color: linear-gradient(to right, #eb3349, #f45c43); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-padding: 12 20; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 6, 0, 0, 2);"
        );
        btnCerrarMapaLateral.setVisible(false);
        btnCerrarMapaLateral.setManaged(false);
        
        // Espaciador para empujar el botón hacia abajo
        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        VBox.setVgrow(spacer, javafx.scene.layout.Priority.ALWAYS);
        vboxMenu.getChildren().addAll(spacer, btnCerrarMapaLateral);

        btnCerrar.setOnAction(_ -> new LoginController().mostrarPantallaLogin(stage));
        // Acciones de cambio de usuario y contraseña eliminadas del menú lateral (ahora solo en menú hamburguesa)
        btnMapa.setOnAction(_ -> {
            if (rol.equals("Administradora")) {
                // Quitar mensaje antiguo y usar aviso moderno
                panelCentral.getChildren().clear();
                try {
                    Image mapaImg = new Image(getClass().getResourceAsStream("/mapa_procesos.png"));
                    ImageView mapaView = new ImageView(mapaImg);
                    mapaView.setPreserveRatio(true);
                    mapaView.setFitWidth(1200); // Aumentado para cubrir mejor el área disponible
                    mapaView.setStyle("-fx-effect: dropshadow(gaussian, #34495e, 30, 0.3, 0, 0);");

                    // --- Botones modernos sobre el mapa ---
                    String botonMapaBase = 
                        "-fx-background-radius: 18; " +
                        "-fx-font-weight: bold; " +
                        "-fx-font-size: 12px; " +
                        "-fx-border-width: 3; " +
                        "-fx-border-radius: 18; " +
                        "-fx-cursor: hand; " +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3); " +
                        "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;";
                    Button btnSistemasGestion = new Button("");
                    btnSistemasGestion.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;" + botonMapaBase);
                    btnSistemasGestion.setPrefSize(82, 79); // Aumentado proporcionalmente
                    btnSistemasGestion.setLayoutX(770); // 612 * 1.37 ≈ 837
                    btnSistemasGestion.setLayoutY(180); // 145 * 1.37 ≈ 198
                    btnSistemasGestion.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/MEJORA CONTINUA"));
                    
                    Button btnGestionComercial = new Button("Gestión de Comercialización");
                    btnGestionComercial.setPrefSize(78, 89); // Aumentado proporcionalmente
                    btnGestionComercial.setLayoutX(296); // 236 * 1.37 ≈ 323
                    btnGestionComercial.setLayoutY(442); // 346 * 1.37 ≈ 474
                    btnGestionComercial.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/GESTION DE COMERCIALIZACION"));
                    addMapButtonHoverEffect(btnGestionComercial, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");
                    
                    Button btnAnalisis = new Button("Análisis Vulnerabilidad");
                    btnAnalisis.setPrefSize(145, 120); // Aumentado proporcionalmente
                    btnAnalisis.setLayoutX(421); // 334 * 1.37 ≈ 457
                    btnAnalisis.setLayoutY(410); // 323 * 1.37 ≈ 442
                    btnAnalisis.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/ANALISIS VULNERABILIDAD"));
                    addMapButtonHoverEffect(btnAnalisis, "linear-gradient(to bottom, #ffb347, #ffcc33)", "linear-gradient(to bottom, #ffc266, #ffd966)", "#2c3e50");
                    
                    Button btnInduccion = new Button("Inducción Vigilante");
                    btnInduccion.setPrefSize(100, 120); // Aumentado proporcionalmente
                    btnInduccion.setLayoutX(580); // 460 * 1.37 ≈ 630
                    btnInduccion.setLayoutY(410); // 323 * 1.37 ≈ 442
                    btnInduccion.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/INDUCCION VIGILANTE"));
                    addMapButtonHoverEffect(btnInduccion, "linear-gradient(to bottom, #f7971e, #ffd200)", "linear-gradient(to bottom, #ffa347, #ffde33)", "#2c3e50");
                    
                    Button btnOperaciones = new Button("Operaciones Fija - Móvil");
                    btnOperaciones.setPrefSize(120, 120); // Aumentado proporcionalmente
                    btnOperaciones.setLayoutX(695); // 551 * 1.37 ≈ 755
                    btnOperaciones.setLayoutY(410); // 323 * 1.37 ≈ 442
                    btnOperaciones.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/OPERACIONES FIJA-MOVIL"));
                    addMapButtonHoverEffect(btnOperaciones, "linear-gradient(to bottom, #00c6ff, #0072ff)", "linear-gradient(to bottom, #33d1ff, #3385ff)", "white");
                    
                    Button btnSupervision = new Button("Supervisión Control");
                    btnSupervision.setPrefSize(120, 120); // Aumentado proporcionalmente
                    btnSupervision.setLayoutX(825); // 860 * 1.37 ≈ 1178
                    btnSupervision.setLayoutY(410); // 425 * 1.37 ≈ 582
                    btnSupervision.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SUPERVISION CONTROL"));
                    addMapButtonHoverEffect(btnSupervision, "linear-gradient(to bottom, #f7971e, #ffd200)", "linear-gradient(to bottom, #ffa347, #ffde33)", "#2c3e50");
                    
                    Button btnSatisfaccion = new Button("Satisfacción al Cliente");
                    btnSatisfaccion.setPrefSize(50, 69); // Aumentado proporcionalmente
                    btnSatisfaccion.setLayoutX(1015); // 1060 * 1.37 ≈ 1452
                    btnSatisfaccion.setLayoutY(442); // 450 * 1.37 ≈ 617
                    btnSatisfaccion.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SATISFACCION AL CLIENTE"));
                    addMapButtonHoverEffect(btnSatisfaccion, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");
                    
                    // Botones administrativos modernizados
                    Button btnAdmin1 = new Button("A1");
                    btnAdmin1.setPrefSize(73, 70); // Aumentado proporcionalmente
                    btnAdmin1.setLayoutX(132); // 145 * 1.37 ≈ 199
                    btnAdmin1.setLayoutY(658); // 685 * 1.37 ≈ 938
                    btnAdmin1.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/CONTABLE"));
                    addMapButtonHoverEffect(btnAdmin1, "linear-gradient(to bottom, #f7971e, #ffd200)", "linear-gradient(to bottom, #ffa347, #ffde33)", "#2c3e50");
                    
                    Button btnAdmin2 = new Button("A2");
                    btnAdmin2.setPrefSize(90, 70); // Aumentado proporcionalmente
                    btnAdmin2.setLayoutX(212); // 225 * 1.37 ≈ 308
                    btnAdmin2.setLayoutY(658); // 685 * 1.37 ≈ 938
                    btnAdmin2.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/ADQUISICIONES"));
                    addMapButtonHoverEffect(btnAdmin2, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");
                    Button btnAdmin3 = new Button("A3");
                    btnAdmin3.setPrefSize(70, 78); // Aumentado proporcionalmente
                    btnAdmin3.setLayoutX(305); // 320 * 1.37 ≈ 438
                    btnAdmin3.setLayoutY(658); // 685 * 1.37 ≈ 938
                    btnAdmin3.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SEGURIDAD FISICA"));
                    addMapButtonHoverEffect(btnAdmin3, "linear-gradient(to bottom, #ffb347, #ffcc33)", "linear-gradient(to bottom, #ffc266, #ffd966)", "#2c3e50");
                    
                    Button btnAdmin4 = new Button("A4");
                    btnAdmin4.setPrefSize(75, 70); // Aumentado proporcionalmente
                    btnAdmin4.setLayoutX(379); // 400 * 1.37 ≈ 548
                    btnAdmin4.setLayoutY(658); // 685 * 1.37 ≈ 938
                    btnAdmin4.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/LOGISTICA"));
                    addMapButtonHoverEffect(btnAdmin4, "linear-gradient(to bottom, #00c6ff, #0072ff)", "linear-gradient(to bottom, #33d1ff, #3385ff)", "white");
                    
                    // Botones de talento humano modernizados
                    Button btnTalento1 = new Button("T1");
                    btnTalento1.setPrefSize(88, 80); // Aumentado proporcionalmente
                    btnTalento1.setLayoutX(460); // 585 * 1.37 ≈ 801
                    btnTalento1.setLayoutY(665); // 700 * 1.37 ≈ 959
                    btnTalento1.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/CONTRATACION"));
                    addMapButtonHoverEffect(btnTalento1, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");
                    
                    Button btnTalento2 = new Button("T2");
                    btnTalento2.setPrefSize(115, 80); // Aumentado proporcionalmente
                    btnTalento2.setLayoutX(560); // 715 * 1.37 ≈ 980
                    btnTalento2.setLayoutY(665); // 700 * 1.37 ≈ 959
                    btnTalento2.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/ADMINISTRACION"));
                    addMapButtonHoverEffect(btnTalento2, "linear-gradient(to bottom, #ffb347, #ffcc33)", "linear-gradient(to bottom, #ffc266, #ffd966)", "#2c3e50");
                    Button btnTalento3 = new Button("T3");
                    btnTalento3.setPrefSize(130, 80); // Aumentado proporcionalmente
                    btnTalento3.setLayoutX(682); // 850 * 1.37 ≈ 1165
                    btnTalento3.setLayoutY(665); // 700 * 1.37 ≈ 959
                    btnTalento3.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/DESVINCULACION"));
                    addMapButtonHoverEffect(btnTalento3, "linear-gradient(to bottom, #00c6ff, #0072ff)", "linear-gradient(to bottom, #33d1ff, #3385ff)", "white");
                    
                    Button btnTalento4 = new Button("T4");
                    btnTalento4.setPrefSize(133, 80); // Aumentado proporcionalmente
                    btnTalento4.setLayoutX(815); // 990 * 1.37 ≈ 1356
                    btnTalento4.setLayoutY(665); // 700 * 1.37 ≈ 959
                    btnTalento4.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/CAPACITACION"));
                    addMapButtonHoverEffect(btnTalento4, "linear-gradient(to bottom, #f7971e, #ffd200)", "linear-gradient(to bottom, #ffa347, #ffde33)", "#2c3e50");
                    
                    Button btnTalento5 = new Button("T5");
                    btnTalento5.setPrefSize(115, 80); // Aumentado proporcionalmente
                    btnTalento5.setLayoutX(948); // 480 * 1.37 ≈ 658
                    btnTalento5.setLayoutY(665); // 700 * 1.37 ≈ 959
                    btnTalento5.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/SELECCION"));
                    addMapButtonHoverEffect(btnTalento5, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");
                    
                    // Botones estratégicos modernizados
                    Button btnGestionIT = new Button("Gestión de IT");
                    btnGestionIT.setPrefSize(62, 55); // Aumentado proporcionalmente
                    btnGestionIT.setLayoutX(1095); // 1140 * 1.37 ≈ 1562
                    btnGestionIT.setLayoutY(675); // 700 * 1.37 ≈ 959
                    btnGestionIT.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/GESTION IT"));
                    addMapButtonHoverEffect(btnGestionIT, "linear-gradient(to bottom, #00c6ff, #0072ff)", "linear-gradient(to bottom, #33d1ff, #3385ff)", "white");
                    
                    Button btnDireccionEstrategica = new Button("DIRECCION ESTRATEGICA");
                    btnDireccionEstrategica.setPrefSize(110, 79); // Aumentado proporcionalmente
                    btnDireccionEstrategica.setLayoutX(280); // 300 * 1.37 ≈ 411
                    btnDireccionEstrategica.setLayoutY(180); // 190 * 1.37 ≈ 260
                    btnDireccionEstrategica.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/DIRECCION ESTRATEGICA"));
                    addMapButtonHoverEffect(btnDireccionEstrategica, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");
                    Button btnRequisitosLegales = new Button("REQUISITOS LEGALES");
                    btnRequisitosLegales.setPrefSize(90, 79); // Aumentado proporcionalmente
                    btnRequisitosLegales.setLayoutX(407); // 425 * 1.37 ≈ 582
                    btnRequisitosLegales.setLayoutY(180); // 190 * 1.37 ≈ 260
                    btnRequisitosLegales.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/REQUISITOS LEGALES"));
                    addMapButtonHoverEffect(btnRequisitosLegales, "linear-gradient(to bottom, #ffb347, #ffcc33)", "linear-gradient(to bottom, #ffc266, #ffd966)", "#2c3e50");
                    
                    Button btnFirmaContrato = new Button("FIRMA CONTRATO");
                    btnFirmaContrato.setPrefSize(80, 79); // Aumentado proporcionalmente
                    btnFirmaContrato.setLayoutX(537); // 558 * 1.37 ≈ 764
                    btnFirmaContrato.setLayoutY(180); // 190 * 1.37 ≈ 260
                    btnFirmaContrato.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/FIRMA CONTRATO"));
                    addMapButtonHoverEffect(btnFirmaContrato, "linear-gradient(to bottom, #00c6ff, #0072ff)", "linear-gradient(to bottom, #33d1ff, #3385ff)", "white");
                    
                    Button btnNecesidadesPartes = new Button("NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS");
                    btnNecesidadesPartes.setPrefSize(105, 150); // Aumentado proporcionalmente
                    btnNecesidadesPartes.setLayoutX(10); // 17 * 1.37 ≈ 23
                    btnNecesidadesPartes.setLayoutY(380); // 400 * 1.37 ≈ 548
                    btnNecesidadesPartes.setOnAction(_ -> abrirCarpeta("C:/GESTION_INTEGRAL/Carpetas documentos/NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS"));
                    addMapButtonHoverEffect(btnNecesidadesPartes, "linear-gradient(to bottom, #43cea2, #185a9d)", "linear-gradient(to bottom, #52d4b1, #1f6bb0)", "white");

                    Pane overlay = new Pane();
                    overlay.setPickOnBounds(false);
                    overlay.getChildren().addAll(
                        mapaView,
                        btnDireccionEstrategica, btnRequisitosLegales, btnFirmaContrato, btnNecesidadesPartes,
                        btnSistemasGestion,
                        btnGestionComercial, btnAnalisis, btnInduccion, btnOperaciones, btnSupervision, btnSatisfaccion,
                        btnAdmin1, btnAdmin2, btnAdmin3, btnAdmin4,
                        btnTalento1, btnTalento2, btnTalento3, btnTalento4, btnTalento5,
                        btnGestionIT
                    );
                    panelCentral.getChildren().add(overlay);
                    // Mostrar botón lateral para cerrar mapa
                    btnCerrarMapaLateral.setVisible(true);
                    btnCerrarMapaLateral.setManaged(true);
                    btnCerrarMapaLateral.setOnAction(_ -> {
                        panelCentral.getChildren().clear();
                        btnCerrarMapaLateral.setVisible(false);
                        btnCerrarMapaLateral.setManaged(false);

                        panelCentral.getChildren().add(headerBienvenida); // Volver al mensaje de bienvenida
                        StackPane.setAlignment(headerBienvenida, Pos.CENTER);
                    });
                } catch (Exception ex) {
                    DialogUtils.mostrarAviso(panelCentral, "No se pudo cargar el mapa de procesos.", false, null);
                }
            } else {
                DialogUtils.mostrarAviso(panelCentral, "Acceso al mapa de procesos restringido.", false, null);
                panelCentral.getChildren().clear();
                btnCerrarMapaLateral.setVisible(false);
                btnCerrarMapaLateral.setManaged(false);
                panelCentral.getChildren().add(headerBienvenida); // Volver al mensaje de bienvenida
                StackPane.setAlignment(headerBienvenida, Pos.CENTER);
            }
        });
        btnTabla.setOnAction(_ -> {
            mostrarVentanaTablaControl();
        });

        btnGestionRequisitos.setOnAction(_ -> {
            mostrarVentanaRequisitoLegal();
        });

        // Layout principal modernizado
        BorderPane root = new BorderPane();
        root.setLeft(vboxMenu);
        root.setCenter(panelCentral);
        root.setStyle("-fx-background-color: #f8f9fa;");
        
        // Header moderno con menú hamburguesa
        StackPane topStack = new StackPane(menuHamburguesa);
        topStack.setStyle(
            "-fx-background-color: rgba(255,255,255,0.95); " +
            "-fx-padding: 15 20; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 2);"
        );
        topStack.setAlignment(Pos.TOP_LEFT);
        BorderPane.setMargin(topStack, new javafx.geometry.Insets(0));
        root.setTop(topStack);

        Scene scene = new Scene(root);
        stage.setTitle("Sistema de Gestión Documental - Panel Principal");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();

        // Los recordatorios solo se envían cuando se presiona el botón, no al iniciar la app
    }

    private Stage mainStage;

    private void mostrarDialogoCrearUsuario(Label lblMensaje) {
        new CrearUsuarioDialog(usuarioService, (Stage) lblMensaje.getScene().getWindow()).mostrar(lblMensaje);
    }

    
private void abrirCarpeta(String folderPath) {
    try {
        java.io.File carpeta = new java.io.File(folderPath);
        
        // Verificar si la carpeta existe
        if (!carpeta.exists()) {
            // Crear la carpeta y todas las carpetas padre necesarias
            boolean creada = carpeta.mkdirs();
            if (creada) {
                DialogUtils.mostrarAviso(null, "Carpeta creada exitosamente:\n" + folderPath, true, null);
            } else {
                DialogUtils.mostrarAviso(null, "No se pudo crear la carpeta:\n" + folderPath, false, null);
                return; // Salir si no se pudo crear
            }
        }
        
        // Intentar abrir la carpeta
        java.awt.Desktop.getDesktop().open(carpeta);
        
        // Si llegamos aquí, la carpeta se abrió exitosamente
        if (carpeta.exists()) {
            DialogUtils.mostrarAviso(null, "Carpeta abierta correctamente:\n" + carpeta.getName(), true, null);
        }
        
    } catch (Exception ex) {
        DialogUtils.mostrarAviso(null, "Error al abrir/crear la carpeta:\n" + ex.getMessage(), false, null);
        ex.printStackTrace();
    }
}

    // Nueva ventana para Tabla de control
    private void mostrarVentanaTablaControl() {
        new TablaControlView(this).mostrar();
    }

    // Nueva ventana para Requisitos Legales
    private void mostrarVentanaRequisitoLegal() {
        new TablaRequisitoLegalView(mainStage).mostrar();
    }

    // Mostrar documentos registrados en una tabla
    public void mostrarDocumentosRegistrados() {
        // Modularizado: ahora en TablaControlView
        TablaControlView.mostrarDocumentosRegistradosEstatico();
    }

    // Mostrar formulario de registro de documento
    public void mostrarFormularioRegistro() {
        new RegistroDocumentoDialog(mainStage).mostrar();
    }

    // Set the main stage for dialog ownership
    public void setMainStage(Stage stage) {
        this.mainStage = stage;
    }

    private void revisarYEnviarRecordatorios(Label lblMensaje) {
        // Leer documentos y requisitos legales desde MongoDB y enviar recordatorios en un hilo en segundo plano
        new Thread(() -> {
            boolean huboError = false;
            StringBuilder resultado = new StringBuilder();
            try {
                // Revisar documentos normales
                java.util.List<org.bson.Document> documentos = documentoService.obtenerTodosLosDocumentos();
                int enviadosDocumentos = 0;
                for (org.bson.Document doc : documentos) {
                    String usuario = doc.getString("usuario");
                    String nombreDocumento = doc.getString("nombreDocumento");
                    Object fechaEmisionObj = doc.get("fechaEmision");
                    Object fechaVencimientoObj = doc.get("fechaVencimiento");
                    Object fechaProximaRenovacionObj = doc.get("fechaProximaRenovacion");

                    LocalDate fechaEmision = null;
                    LocalDate fechaVencimiento = null;
                    LocalDate fechaProximaRenovacion = null;
                    try {
                        if (fechaEmisionObj instanceof java.util.Date) {
                            fechaEmision = ((java.util.Date) fechaEmisionObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaEmisionObj instanceof String && !"NV".equals(fechaEmisionObj)) {
                            fechaEmision = LocalDate.parse((String) fechaEmisionObj);
                        }
                        if (fechaVencimientoObj instanceof java.util.Date) {
                            fechaVencimiento = ((java.util.Date) fechaVencimientoObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaVencimientoObj instanceof String && !"NV".equals(fechaVencimientoObj)) {
                            fechaVencimiento = LocalDate.parse((String) fechaVencimientoObj);
                        }
                        if (fechaProximaRenovacionObj instanceof java.util.Date) {
                            fechaProximaRenovacion = ((java.util.Date) fechaProximaRenovacionObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaProximaRenovacionObj instanceof String && !"NV".equals(fechaProximaRenovacionObj)) {
                            fechaProximaRenovacion = LocalDate.parse((String) fechaProximaRenovacionObj);
                        }
                    } catch (Exception ex) {
                        System.err.println("Documento ignorado por fecha inválida: " + nombreDocumento);
                        huboError = true;
                        continue;
                    }
                    
                    if ("NV".equals(fechaVencimientoObj) || "NV".equals(fechaProximaRenovacionObj)) {
                        continue;
                    }
                    
                    if (fechaProximaRenovacion != null && fechaVencimiento != null &&
                        !fechaProximaRenovacion.isAfter(LocalDate.now()) &&
                        !fechaVencimiento.isBefore(LocalDate.now())) {
                        boolean exito = enviarRecordatorio(usuario, nombreDocumento, fechaEmision, fechaVencimiento, fechaProximaRenovacion, lblMensaje);
                        if (!exito) huboError = true;
                        enviadosDocumentos++;
                    }
                }

                // Revisar requisitos legales
                RequisitoLegalService requisitoLegalService = new RequisitoLegalService();
                java.util.List<org.bson.Document> requisitosLegales = requisitoLegalService.obtenerTodosLosRequisitosLegales();
                int enviadosRequisitos = 0;
                for (org.bson.Document req : requisitosLegales) {
                    String nombreRequisitoLegal = req.getString("nombreRequisitoLegal");
                    Object fechaEmisionObj = req.get("fechaEmision");
                    Object fechaVencimientoObj = req.get("fechaVencimiento");
                    Object fechaProximaRenovacionObj = req.get("fechaProximaRenovacion");

                    LocalDate fechaEmision = null;
                    LocalDate fechaVencimiento = null;
                    LocalDate fechaProximaRenovacion = null;
                    try {
                        if (fechaEmisionObj instanceof java.util.Date) {
                            fechaEmision = ((java.util.Date) fechaEmisionObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaEmisionObj instanceof String && !"NV".equals(fechaEmisionObj)) {
                            fechaEmision = LocalDate.parse((String) fechaEmisionObj);
                        }
                        if (fechaVencimientoObj instanceof java.util.Date) {
                            fechaVencimiento = ((java.util.Date) fechaVencimientoObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaVencimientoObj instanceof String && !"NV".equals(fechaVencimientoObj)) {
                            fechaVencimiento = LocalDate.parse((String) fechaVencimientoObj);
                        }
                        if (fechaProximaRenovacionObj instanceof java.util.Date) {
                            fechaProximaRenovacion = ((java.util.Date) fechaProximaRenovacionObj).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        } else if (fechaProximaRenovacionObj instanceof String && !"NV".equals(fechaProximaRenovacionObj)) {
                            fechaProximaRenovacion = LocalDate.parse((String) fechaProximaRenovacionObj);
                        }
                    } catch (Exception ex) {
                        System.err.println("Requisito legal ignorado por fecha inválida: " + nombreRequisitoLegal);
                        huboError = true;
                        continue;
                    }
                    
                    if ("NV".equals(fechaVencimientoObj) || "NV".equals(fechaProximaRenovacionObj)) {
                        continue;
                    }
                    
                    if (fechaProximaRenovacion != null && fechaVencimiento != null &&
                        !fechaProximaRenovacion.isAfter(LocalDate.now()) &&
                        !fechaVencimiento.isBefore(LocalDate.now())) {
                        boolean exito = enviarRecordatorioRequisitoLegal(nombreRequisitoLegal, fechaEmision, fechaVencimiento, fechaProximaRenovacion, lblMensaje);
                        if (!exito) huboError = true;
                        enviadosRequisitos++;
                    }
                }

                if (!huboError) {
                    resultado.append("Recordatorios enviados correctamente:\n");
                    resultado.append("- Documentos: " + enviadosDocumentos + "\n");
                    resultado.append("- Requisitos Legales: " + enviadosRequisitos);
                } else {
                    resultado.append("Algunos elementos fueron ignorados por formato de fecha inválido.");
                }
                requisitoLegalService.close();
            } catch (Exception e) {
                resultado.append("Error al revisar documentos y requisitos legales: " + e.getMessage());
                e.printStackTrace();
            }
            // Mostrar aviso emergente en vez de solo debajo de los botones
            javafx.application.Platform.runLater(() -> {
                DialogUtils.mostrarAviso(null, resultado.toString(), true, null);
            });
        }).start();
    }

    private boolean enviarRecordatorio(String Usuario,String nombreDocumento, LocalDate fechaEmision, LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, Label lblMensaje) {
        // Configuración del correo
        String remitente = "santy.rojas.2005.santylol@gmail.com"; // Cambia por tu correo
        String password = "mtxxorlkbnpwjdkt"; // Cambia por tu contraseña de aplicación
        String destinatario = "josema19082005@gmail.com"; // Cambia por el destinatario
        String asunto = "Recordatorio de renovación de documento";
        String cuerpo = "Recordatorio: El documento de nombre " + nombreDocumento + " compartido por el usuario '" + Usuario + "' tiene fecha de renovación próxima o vencida."
                + "\nFecha de emisión: " + fechaEmision
                + "\nFecha de vencimiento: " + fechaVencimiento
                + "\nFecha próxima de renovación: " + fechaProximaRenovacion;

        boolean exito = CorreoUtils.enviarRecordatorio(remitente, password, destinatario, asunto, cuerpo);
        if (exito) {
            lblMensaje.setText("Correo enviado correctamente a " + destinatario);
        } else {
            lblMensaje.setText("No se pudo enviar el correo a " + destinatario);
        }
        return exito;
    }

    private boolean enviarRecordatorioRequisitoLegal(String nombreRequisitoLegal, LocalDate fechaEmision, LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, Label lblMensaje) {
        // Configuración del correo
        String remitente = "santy.rojas.2005.santylol@gmail.com"; // Cambia por tu correo
        String password = "mtxxorlkbnpwjdkt"; // Cambia por tu contraseña de aplicación
        String destinatario = "josema19082005@gmail.com"; // Cambia por el destinatario
        String asunto = "Recordatorio de renovación de requisito legal";
        String cuerpo = "Recordatorio: El requisito legal '" + nombreRequisitoLegal + "' tiene fecha de renovación próxima o vencida."
                + "\nFecha de emisión: " + fechaEmision
                + "\nFecha de vencimiento: " + fechaVencimiento
                + "\nFecha próxima de renovación: " + fechaProximaRenovacion;

        boolean exito = CorreoUtils.enviarRecordatorio(remitente, password, destinatario, asunto, cuerpo);
        if (exito) {
            lblMensaje.setText("Correo de requisito legal enviado correctamente a " + destinatario);
        } else {
            lblMensaje.setText("No se pudo enviar el correo de requisito legal a " + destinatario);
        }
        return exito;
    }

    // Método auxiliar para agregar efectos hover a los botones
    private void addHoverEffect(Button button, String normalStyle, String hoverStyle) {
        String baseStyle = 
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 12; " +
            "-fx-border-radius: 12; " +
            "-fx-padding: 15 25; " +
            "-fx-cursor: hand; ";

        button.setOnMouseEntered(e -> button.setStyle(
            "-fx-background-color: " + hoverStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 10, 0, 0, 4);"
        ));

        button.setOnMouseExited(e -> button.setStyle(
            "-fx-background-color: " + normalStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);"
        ));
    }

    // Método auxiliar para agregar efectos hover modernos a los botones del mapa
    private void addMapButtonHoverEffect(Button button, String normalColor, String hoverColor, String textColor) {
        String baseStyle = 
            "-fx-background-radius: 18; " +
            "-fx-font-weight: bold; " +
            "-fx-font-size: 12px; " +
            "-fx-border-width: 3; " +
            "-fx-border-radius: 18; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-text-fill: transparent; ";

        String normalStyle = "-fx-background-color: transparent; " +
                           "-fx-border-color: transparent; " + baseStyle +
                           "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3);";

        String hoverStyleStr = "-fx-background-color: transparent; " +
                              "-fx-border-color: transparent; " + baseStyle +
                              "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.5), 12, 0, 0, 5); " +
                              "-fx-scale-x: 1.05; -fx-scale-y: 1.05;";

        button.setStyle(normalStyle);
        
        button.setOnMouseEntered(e -> button.setStyle(hoverStyleStr));
        button.setOnMouseExited(e -> button.setStyle(normalStyle));
    }
}
