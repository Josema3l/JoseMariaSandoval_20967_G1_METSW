package com.example;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.concurrent.Task;
import org.bson.Document;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

public class ArchivoManagerDialogRequisito {
    private final Stage stage;
    private final RequisitoLegalService requisitoService;
    private final ListView<String> archivosListView;
    private final ObservableList<String> archivosObservableList;
    private final String nombreRequisitoLegal;
    private final Label infoLabel;
    private final Button eliminarBtn;
    private final Button descargarBtn;

    public ArchivoManagerDialogRequisito(String nombreRequisitoLegal, RequisitoLegalService requisitoService) {
        this.nombreRequisitoLegal = nombreRequisitoLegal;
        this.requisitoService = requisitoService;
        this.archivosObservableList = FXCollections.observableArrayList();
        this.archivosListView = new ListView<>(archivosObservableList);
        
        // Configurar stage
        this.stage = new Stage();
        this.stage.initModality(Modality.APPLICATION_MODAL);
        this.stage.setTitle("📁 Gestión de Archivos - " + nombreRequisitoLegal);
        this.stage.setWidth(600);
        this.stage.setHeight(500);
        this.stage.setResizable(true);

        // Crear componentes de interfaz
        this.infoLabel = new Label();
        this.eliminarBtn = new Button("🗑️ Eliminar");
        this.descargarBtn = new Button("💾 Descargar");

        setupInterface();
        cargarArchivos();
    }

    private void setupInterface() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background: linear-gradient(to bottom, #f8f9fa, #e9ecef);");

        // Título y información
        Label titleLabel = new Label("📁 Gestión de Archivos");
        titleLabel.setStyle("""
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 24px;
            -fx-font-weight: bold;
            -fx-text-fill: #2c3e50;
            """);

        Label subtitleLabel = new Label("Requisito Legal: " + nombreRequisitoLegal);
        subtitleLabel.setStyle("""
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 14px;
            -fx-text-fill: #34495e;
            -fx-font-style: italic;
            """);

        infoLabel.setStyle("""
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 12px;
            -fx-text-fill: #7f8c8d;
            """);

        VBox headerBox = new VBox(5, titleLabel, subtitleLabel, infoLabel);
        headerBox.setAlignment(Pos.CENTER);

        // Configurar ListView
        archivosListView.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #bdc3c7;
            -fx-border-width: 1px;
            -fx-border-radius: 8px;
            -fx-background-radius: 8px;
            """);
        archivosListView.setPrefHeight(250);

        // Configurar selección
        archivosListView.getSelectionModel().selectedItemProperty().addListener(
            (@SuppressWarnings("unused") var obs, @SuppressWarnings("unused") var oldSelection, @SuppressWarnings("unused") var newSelection) -> updateButtonStates()
        );

        // Botones de acción
        Button agregarBtn = new Button("📎 Agregar Archivo");
        agregarBtn.setStyle("""
            -fx-background-color: #27ae60;
            -fx-text-fill: white;
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 12px;
            -fx-font-weight: bold;
            -fx-padding: 8 16 8 16;
            -fx-background-radius: 6px;
            -fx-cursor: hand;
            """);
        agregarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> agregarBtn.setStyle(agregarBtn.getStyle() + "-fx-background-color: #2ecc71;"));
        agregarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> agregarBtn.setStyle(agregarBtn.getStyle().replace("-fx-background-color: #2ecc71;", "-fx-background-color: #27ae60;")));
        agregarBtn.setOnAction((@SuppressWarnings("unused") var e) -> agregarArchivo());

        eliminarBtn.setStyle("""
            -fx-background-color: #e74c3c;
            -fx-text-fill: white;
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 12px;
            -fx-font-weight: bold;
            -fx-padding: 8 16 8 16;
            -fx-background-radius: 6px;
            -fx-cursor: hand;
            """);
        eliminarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> eliminarBtn.setStyle(eliminarBtn.getStyle() + "-fx-background-color: #c0392b;"));
        eliminarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> eliminarBtn.setStyle(eliminarBtn.getStyle().replace("-fx-background-color: #c0392b;", "-fx-background-color: #e74c3c;")));
        eliminarBtn.setOnAction((@SuppressWarnings("unused") var e) -> eliminarArchivo());

        descargarBtn.setStyle("""
            -fx-background-color: #3498db;
            -fx-text-fill: white;
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 12px;
            -fx-font-weight: bold;
            -fx-padding: 8 16 8 16;
            -fx-background-radius: 6px;
            -fx-cursor: hand;
            """);
        descargarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> descargarBtn.setStyle(descargarBtn.getStyle() + "-fx-background-color: #2980b9;"));
        descargarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> descargarBtn.setStyle(descargarBtn.getStyle().replace("-fx-background-color: #2980b9;", "-fx-background-color: #3498db;")));
        descargarBtn.setOnAction((@SuppressWarnings("unused") var e) -> descargarArchivo());

        Button cerrarBtn = new Button("❌ Cerrar");
        cerrarBtn.setStyle("""
            -fx-background-color: #95a5a6;
            -fx-text-fill: white;
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 12px;
            -fx-font-weight: bold;
            -fx-padding: 8 16 8 16;
            -fx-background-radius: 6px;
            -fx-cursor: hand;
            """);
        cerrarBtn.setOnMouseEntered((@SuppressWarnings("unused") var e) -> cerrarBtn.setStyle(cerrarBtn.getStyle() + "-fx-background-color: #7f8c8d;"));
        cerrarBtn.setOnMouseExited((@SuppressWarnings("unused") var e) -> cerrarBtn.setStyle(cerrarBtn.getStyle().replace("-fx-background-color: #7f8c8d;", "-fx-background-color: #95a5a6;")));
        cerrarBtn.setOnAction((@SuppressWarnings("unused") var e) -> stage.close());

        // Layout de botones
        HBox buttonBox = new HBox(10, agregarBtn, eliminarBtn, descargarBtn);
        buttonBox.setAlignment(Pos.CENTER);

        HBox closeButtonBox = new HBox(cerrarBtn);
        closeButtonBox.setAlignment(Pos.CENTER);

        // Contenedor para la lista
        VBox listContainer = new VBox(10);
        Label listLabel = new Label("📋 Archivos Asociados:");
        listLabel.setStyle("""
            -fx-font-family: 'Segoe UI';
            -fx-font-size: 14px;
            -fx-font-weight: bold;
            -fx-text-fill: #2c3e50;
            """);
        listContainer.getChildren().addAll(listLabel, archivosListView);

        root.getChildren().addAll(headerBox, listContainer, buttonBox, closeButtonBox);
        
        updateButtonStates();

        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    private void cargarArchivos() {
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                Document requisito = requisitoService.obtenerRequisitoPorNombre(nombreRequisitoLegal);
                if (requisito != null) {
                    @SuppressWarnings("unchecked")
                    List<String> nombresArchivos = (List<String>) requisito.get("nombresArchivos");
                    if (nombresArchivos != null) {
                        Platform.runLater(() -> {
                            archivosObservableList.clear();
                            archivosObservableList.addAll(nombresArchivos);
                            updateInfoLabel();
                        });
                    } else {
                        Platform.runLater(() -> {
                            archivosObservableList.clear();
                            updateInfoLabel();
                        });
                    }
                }
                return null;
            }
        };

        Thread thread = new Thread(task);
        thread.setDaemon(true);
        thread.start();
    }

    private void updateInfoLabel() {
        int totalArchivos = archivosObservableList.size();
        infoLabel.setText("Total de archivos: " + totalArchivos);
    }

    private void updateButtonStates() {
        boolean haySeleccion = archivosListView.getSelectionModel().getSelectedItem() != null;
        eliminarBtn.setDisable(!haySeleccion);
        descargarBtn.setDisable(!haySeleccion);
    }

    private void agregarArchivo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivo para requisito legal");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Hojas de cálculo", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );

        File archivoSeleccionado = fileChooser.showOpenDialog(stage);
        if (archivoSeleccionado != null) {
            Task<Boolean> task = new Task<Boolean>() {
                @Override
                protected Boolean call() throws Exception {
                    return requisitoService.agregarArchivo(nombreRequisitoLegal, archivoSeleccionado);
                }

                @Override
                protected void succeeded() {
                    if (getValue()) {
                        Platform.runLater(() -> {
                            DialogUtils.showSuccess("Archivo agregado exitosamente");
                            cargarArchivos();
                        });
                    } else {
                        Platform.runLater(() -> 
                            DialogUtils.showError("Error al agregar el archivo")
                        );
                    }
                }

                @Override
                protected void failed() {
                    Platform.runLater(() -> 
                        DialogUtils.showError("Error al agregar el archivo: " + getException().getMessage())
                    );
                }
            };

            Thread thread = new Thread(task);
            thread.setDaemon(true);
            thread.start();
        }
    }

    private void eliminarArchivo() {
        int indiceSeleccionado = archivosListView.getSelectionModel().getSelectedIndex();
        String archivoSeleccionado = archivosListView.getSelectionModel().getSelectedItem();
        
        if (indiceSeleccionado >= 0 && archivoSeleccionado != null) {
            Optional<ButtonType> resultado = DialogUtils.showConfirmation(
                "Confirmar eliminación",
                "¿Está seguro de que desea eliminar el archivo '" + archivoSeleccionado + "'?"
            );

            if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return requisitoService.eliminarArchivo(nombreRequisitoLegal, indiceSeleccionado);
                    }

                    @Override
                    protected void succeeded() {
                        if (getValue()) {
                            Platform.runLater(() -> {
                                DialogUtils.showSuccess("Archivo eliminado exitosamente");
                                cargarArchivos();
                            });
                        } else {
                            Platform.runLater(() -> 
                                DialogUtils.showError("Error al eliminar el archivo")
                            );
                        }
                    }

                    @Override
                    protected void failed() {
                        Platform.runLater(() -> 
                            DialogUtils.showError("Error al eliminar el archivo: " + getException().getMessage())
                        );
                    }
                };

                Thread thread = new Thread(task);
                thread.setDaemon(true);
                thread.start();
            }
        }
    }

    private void descargarArchivo() {
        int indiceSeleccionado = archivosListView.getSelectionModel().getSelectedIndex();
        String archivoSeleccionado = archivosListView.getSelectionModel().getSelectedItem();
        
        if (indiceSeleccionado >= 0 && archivoSeleccionado != null) {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("Seleccionar carpeta de destino");
            
            // Establecer directorio inicial
            try {
                String userHome = System.getProperty("user.home");
                Path downloadsPath = Paths.get(userHome, "Downloads");
                if (Files.exists(downloadsPath)) {
                    directoryChooser.setInitialDirectory(downloadsPath.toFile());
                } else {
                    directoryChooser.setInitialDirectory(new File(userHome));
                }
            } catch (Exception e) {
                // Si hay error, usar directorio actual
                directoryChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
            }

            File directorioDestino = directoryChooser.showDialog(stage);
            if (directorioDestino != null) {
                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return requisitoService.descargarArchivoDeRequisito(
                            nombreRequisitoLegal, 
                            indiceSeleccionado, 
                            directorioDestino.getAbsolutePath()
                        );
                    }

                    @Override
                    protected void succeeded() {
                        if (getValue()) {
                            Platform.runLater(() -> 
                                DialogUtils.showSuccess(
                                    "Archivo descargado exitosamente en:\n" + 
                                    directorioDestino.getAbsolutePath()
                                )
                            );
                        } else {
                            Platform.runLater(() -> 
                                DialogUtils.showError("Error al descargar el archivo")
                            );
                        }
                    }

                    @Override
                    protected void failed() {
                        Platform.runLater(() -> 
                            DialogUtils.showError("Error al descargar el archivo: " + getException().getMessage())
                        );
                    }
                };

                Thread thread = new Thread(task);
                thread.setDaemon(true);
                thread.start();
            }
        }
    }

    public void show() {
        stage.show();
    }

    public void showAndWait() {
        stage.showAndWait();
    }
}
