package com.example;

import java.time.LocalDate;
import java.util.List;

import org.bson.Document;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TablaRequisitoLegalView {
    private final Stage parentStage;
    private final RequisitoLegalService requisitoLegalService;

    public TablaRequisitoLegalView(Stage parentStage) {
        this.parentStage = parentStage;
        this.requisitoLegalService = new RequisitoLegalService();
    }

    public void mostrar() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("⚖️ Centro de Control de Requisitos Legales");
        
        // Header moderno con título
        Label lblTitulo = new Label("Centro de Control de Requisitos Legales");
        lblTitulo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 32px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 20 0; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 2, 0, 0, 1);"
        );
        
        Label lblSubtitulo = new Label("Gestione todos sus requisitos legales de manera eficiente y segura");
        lblSubtitulo.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 16px; " +
            "-fx-text-fill: #7f8c8d; " +
            "-fx-padding: 0 0 30 0;"
        );
        
        // Botones modernos con iconos y efectos
        Button btnRegistrar = new Button("⚖️ Registrar Requisito Legal");
        btnRegistrar.setPrefWidth(320);
        btnRegistrar.setPrefHeight(80);
        btnRegistrar.setStyle(
            "-fx-background-color: linear-gradient(to right, #8e44ad, #9b59b6); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 15; " +
            "-fx-border-radius: 15; " +
            "-fx-padding: 20 30; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        Button btnVer = new Button("📊 Ver Requisitos Registrados");
        btnVer.setPrefWidth(320);
        btnVer.setPrefHeight(80);
        btnVer.setStyle(
            "-fx-background-color: linear-gradient(to right, #e67e22, #f39c12); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 15; " +
            "-fx-border-radius: 15; " +
            "-fx-padding: 20 30; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        
        // Efectos hover para los botones
        addModernHoverEffect(btnRegistrar, 
            "linear-gradient(to right, #8e44ad, #9b59b6)", 
            "linear-gradient(to right, #9b59b6, #bb8fce)");
        addModernHoverEffect(btnVer, 
            "linear-gradient(to right, #e67e22, #f39c12)", 
            "linear-gradient(to right, #f39c12, #f7b731)");
        
        // Contenedor principal moderno
        VBox headerContainer = new VBox(5);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.getChildren().addAll(lblTitulo, lblSubtitulo);
        
        VBox buttonContainer = new VBox(25);
        buttonContainer.setAlignment(Pos.CENTER);
        buttonContainer.getChildren().addAll(btnRegistrar, btnVer);
        
        VBox mainContainer = new VBox(40);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPrefSize(500, 400);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-padding: 40 50; " +
            "-fx-background-radius: 20; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 15, 0, 0, 5);"
        );
        mainContainer.getChildren().addAll(headerContainer, buttonContainer);
        
        // Contenedor de fondo
        javafx.scene.layout.StackPane backgroundPane = new javafx.scene.layout.StackPane();
        backgroundPane.setStyle("-fx-background-color: linear-gradient(135deg, #764ba2 0%, #667eea 100%);");
        backgroundPane.getChildren().add(mainContainer);
        
        Scene scene = new Scene(backgroundPane, 600, 500);
        tablaStage.setScene(scene);
        tablaStage.show();

        btnRegistrar.setOnAction(_ -> {
            tablaStage.close();
            new RegistroRequisitoLegalDialog(parentStage).mostrar();
        });
        
        btnVer.setOnAction(_ -> {
            tablaStage.close();
            mostrarRequisitosRegistrados();
        });
        
        // Cerrar conexión cuando se cierre la ventana
        tablaStage.setOnCloseRequest(_ -> cerrarConexion());
    }

    public void mostrarRequisitosRegistrados() {
        Stage docsStage = new Stage();
        docsStage.setTitle("⚖️ Requisitos Legales Registrados - Vista Completa");
        
        // Header moderno
        Label lblTitulo = new Label("⚖️ Requisitos Legales Registrados");
        lblTitulo.setStyle(
            "-fx-font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; " +
            "-fx-font-size: 28px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: #2c3e50; " +
            "-fx-padding: 20 0 10 0; " +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 2, 0, 0, 1);"
        );
        
        Label lblSubtitulo = new Label("Gestione y visualice todos sus requisitos legales registrados");
        lblSubtitulo.setStyle(
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; " +
            "-fx-font-size: 14px; " +
            "-fx-text-fill: #7f8c8d; " +
            "-fx-padding: 0 0 20 0;"
        );
        
        // Crear la tabla con estilo moderno
        TableView<RequisitoLegalTableRow> table = new TableView<>();
        table.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        table.setStyle(
            "-fx-background-color: white; " +
            "-fx-border-color: #e0e0e0; " +
            "-fx-border-width: 1; " +
            "-fx-border-radius: 10; " +
            "-fx-background-radius: 10; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 8, 0, 0, 2);"
        );

        // Configurar columnas con estilo moderno
        TableColumn<RequisitoLegalTableRow, String> colNombre = new TableColumn<>("⚖️ Requisito Legal");
        colNombre.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNombreRequisitoLegal()));
        colNombre.setPrefWidth(280);
        colNombre.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");

        TableColumn<RequisitoLegalTableRow, String> colFechaEmision = new TableColumn<>("📅 Fecha de Emisión");
        colFechaEmision.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaEmision()));
        colFechaEmision.setPrefWidth(150);
        colFechaEmision.setStyle("-fx-alignment: CENTER;");
        
        TableColumn<RequisitoLegalTableRow, String> colFechaVencimiento = new TableColumn<>("⏰ Fecha de Vencimiento");
        colFechaVencimiento.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaVencimiento()));
        colFechaVencimiento.setPrefWidth(170);
        colFechaVencimiento.setStyle("-fx-alignment: CENTER;");
        
        TableColumn<RequisitoLegalTableRow, String> colFechaRenovacion = new TableColumn<>("🔄 Próxima Renovación");
        colFechaRenovacion.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFechaProximaRenovacion()));
        colFechaRenovacion.setPrefWidth(170);
        colFechaRenovacion.setStyle("-fx-alignment: CENTER;");

        TableColumn<RequisitoLegalTableRow, String> colEstado = new TableColumn<>("📊 Estado");
        colEstado.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEstado()));
        colEstado.setPrefWidth(120);
        colEstado.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");
        
        TableColumn<RequisitoLegalTableRow, String> colArchivos = new TableColumn<>("📎 Archivos");
        colArchivos.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCantidadArchivos()));
        colArchivos.setPrefWidth(90);
        colArchivos.setStyle("-fx-alignment: CENTER; -fx-font-weight: bold;");

        table.getColumns().addAll(colNombre, colFechaEmision, colFechaVencimiento, colFechaRenovacion, colEstado, colArchivos);

        // Crear menú contextual moderno
        ContextMenu contextMenu = new ContextMenu();
        MenuItem menuGestionarArchivos = new MenuItem("📁 Gestionar archivos");
        MenuItem menuEliminarRequisito = new MenuItem("🗑️ Eliminar requisito");
        
        menuGestionarArchivos.setStyle("-fx-font-family: 'Segoe UI'; -fx-font-size: 14px;");
        menuEliminarRequisito.setStyle("-fx-font-family: 'Segoe UI'; -fx-font-size: 14px;");
        
        menuGestionarArchivos.setOnAction(_ -> {
            RequisitoLegalTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    ArchivoManagerDialogRequisito archivoManager = new ArchivoManagerDialogRequisito(
                        selected.getNombreRequisitoLegal(), 
                        requisitoLegalService
                    );
                    archivoManager.showAndWait();
                    cargarRequisitos(table); // Recargar para actualizar la vista
                } catch (Exception e) {
                    DialogUtils.showError("Error al abrir gestor de archivos: " + e.getMessage());
                }
            } else {
                DialogUtils.showError("Por favor seleccione un requisito legal para gestionar sus archivos");
            }
        });
        
        menuEliminarRequisito.setOnAction(_ -> {
            RequisitoLegalTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarRequisito(selected.getNombreRequisitoLegal(), table);
            }
        });
        
        contextMenu.getItems().addAll(menuGestionarArchivos, menuEliminarRequisito);
        table.setContextMenu(contextMenu);
        
        // Cargar datos
        cargarRequisitos(table);
        
        // Botones modernos con iconos
        Button btnGestionarArchivos = new Button("📁 Gestionar Archivos");
        btnGestionarArchivos.setPrefWidth(180);
        btnGestionarArchivos.setPrefHeight(45);
        btnGestionarArchivos.setStyle(
            "-fx-background-color: linear-gradient(to right, #8e44ad, #9b59b6); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnGestionarArchivos.setOnAction(_ -> {
            RequisitoLegalTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    ArchivoManagerDialogRequisito archivoManager = new ArchivoManagerDialogRequisito(
                        selected.getNombreRequisitoLegal(), 
                        requisitoLegalService
                    );
                    archivoManager.showAndWait();
                    cargarRequisitos(table); // Recargar para actualizar la vista
                } catch (Exception e) {
                    DialogUtils.showError("Error al abrir gestor de archivos: " + e.getMessage());
                }
            } else {
                DialogUtils.showError("Selecciona un requisito para gestionar sus archivos.");
            }
        });
        
        Button btnActualizar = new Button("🔄 Actualizar");
        btnActualizar.setPrefWidth(130);
        btnActualizar.setPrefHeight(45);
        btnActualizar.setStyle(
            "-fx-background-color: linear-gradient(to right, #3498db, #5dade2); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnActualizar.setOnAction(_ -> cargarRequisitos(table));
        
        Button btnEliminar = new Button("🗑️ Eliminar Requisito");
        btnEliminar.setPrefWidth(180);
        btnEliminar.setPrefHeight(45);
        btnEliminar.setStyle(
            "-fx-background-color: linear-gradient(to right, #e74c3c, #ec7063); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnEliminar.setOnAction(_ -> {
            RequisitoLegalTableRow selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                eliminarRequisito(selected.getNombreRequisitoLegal(), table);
            } else {
                DialogUtils.mostrarAviso(null, "Selecciona un requisito para eliminar.", false, null);
            }
        });
        
        Button btnCerrar = new Button("❌ Cerrar");
        btnCerrar.setPrefWidth(110);
        btnCerrar.setPrefHeight(45);
        btnCerrar.setStyle(
            "-fx-background-color: linear-gradient(to right, #95a5a6, #bdc3c7); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2); " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif;"
        );
        btnCerrar.setOnAction(_ -> docsStage.close());
        
        // Aplicar efectos hover a los botones
        addTableButtonHoverEffect(btnGestionarArchivos, "linear-gradient(to right, #8e44ad, #9b59b6)", "linear-gradient(to right, #9b59b6, #bb8fce)");
        addTableButtonHoverEffect(btnActualizar, "linear-gradient(to right, #3498db, #5dade2)", "linear-gradient(to right, #5dade2, #85c1e9)");
        addTableButtonHoverEffect(btnEliminar, "linear-gradient(to right, #e74c3c, #ec7063)", "linear-gradient(to right, #ec7063, #f1948a)");
        addTableButtonHoverEffect(btnCerrar, "linear-gradient(to right, #95a5a6, #bdc3c7)", "linear-gradient(to right, #bdc3c7, #d5dbdb)");
        
        HBox hboxBotones = new HBox(15, btnGestionarArchivos, btnActualizar, btnEliminar, btnCerrar);
        hboxBotones.setAlignment(Pos.CENTER);
        hboxBotones.setStyle("-fx-padding: 20 0;");
        
        // Layout principal moderno
        VBox headerContainer = new VBox(5);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.getChildren().addAll(lblTitulo, lblSubtitulo);
        
        VBox mainContainer = new VBox(20);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ffffff, #f8f9fa); " +
            "-fx-padding: 25; " +
            "-fx-background-radius: 15; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 12, 0, 0, 4);"
        );
        mainContainer.getChildren().addAll(headerContainer, table, hboxBotones);
        
        // Contenedor de fondo
        javafx.scene.layout.StackPane backgroundPane = new javafx.scene.layout.StackPane();
        backgroundPane.setStyle("-fx-background-color: linear-gradient(135deg, #764ba2 0%, #667eea 100%); -fx-padding: 20;");
        backgroundPane.getChildren().add(mainContainer);
        
        Scene scene = new Scene(backgroundPane, 1400, 700);
        docsStage.setScene(scene);
        docsStage.show();
        
        // Cerrar conexión cuando se cierre la ventana
        docsStage.setOnCloseRequest(_ -> cerrarConexion());
    }

    
    private void cargarRequisitos(TableView<RequisitoLegalTableRow> table) {
        try {
            List<Document> requisitosLegales = requisitoLegalService.obtenerTodosLosRequisitosLegales();
            ObservableList<RequisitoLegalTableRow> rows = FXCollections.observableArrayList();
            
            for (Document req : requisitosLegales) {
                RequisitoLegalTableRow row = new RequisitoLegalTableRow(
                    obtenerStringSeguro(req, "nombreRequisitoLegal"),
                    obtenerFechaComoString(req, "fechaEmision"),
                    obtenerFechaComoString(req, "fechaVencimiento"),
                    obtenerFechaComoString(req, "fechaProximaRenovacion"),
                    calcularEstado(req.get("fechaVencimiento")),
                    obtenerCantidadArchivos(req)
                );
                rows.add(row);
            }
            
            table.setItems(rows);
        } catch (Exception e) {
            DialogUtils.mostrarAviso(null, "Error al cargar los requisitos legales: " + e.getMessage(), false, null);
            e.printStackTrace();
        }
    }
    
    private String obtenerStringSeguro(Document doc, String campo) {
        Object valor = doc.get(campo);
        return valor != null ? valor.toString() : "";
    }
    
    private String obtenerFechaComoString(Document doc, String campo) {
        Object fecha = doc.get(campo);
        if (fecha == null) {
            return "";
        }
        // Permitir 'nv' o 'NV' como 'No vence' solo para vencimiento y próxima renovación
        if (fecha instanceof String) {
            String fechaStr = ((String) fecha).trim();
            if (fechaStr.equalsIgnoreCase("nv")) {
                return "No Vence";
            }
        }
        // Si es una fecha de Java (Date)
        if (fecha instanceof java.util.Date) {
            java.util.Date date = (java.util.Date) fecha;
            java.time.LocalDate localDate = date.toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();
            return localDate.toString();
        }
        // Si es un LocalDate
        if (fecha instanceof java.time.LocalDate) {
            return fecha.toString();
        }
        // Si es un string
        return fecha.toString();
    }
    
    private String obtenerCantidadArchivos(Document documento) {
        List<String> archivos = documento.getList("nombresArchivos", String.class);
        if (archivos != null) {
            return String.valueOf(archivos.size());
        }
        return "0";
    }
    
    private void eliminarRequisito(String nombreRequisito, TableView<RequisitoLegalTableRow> table) {
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Confirmar eliminación");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText("¿Estás seguro de que deseas eliminar el requisito legal '" + nombreRequisito + "'?\n" +
                                   "Esta acción también eliminará todos los archivos asociados.");
        
        if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            try {
                // TODO: Implementar método eliminarRequisito en RequisitoLegalService
                DialogUtils.mostrarAviso(null, "Función de eliminación en desarrollo para requisitos legales.", false, null);
                /*
                if (requisitoLegalService.eliminarRequisito(nombreRequisito)) {
                    cargarRequisitos(table); // Recargar la tabla
                    DialogUtils.mostrarAviso(null, "Requisito legal eliminado exitosamente.", true, null);
                } else {
                    DialogUtils.mostrarAviso(null, "Error al eliminar el requisito legal.", false, null);
                }
                */
            } catch (Exception e) {
                DialogUtils.mostrarAviso(null, "Error al eliminar el requisito legal: " + e.getMessage(), false, null);
                e.printStackTrace();
            }
        }
    }
    
    public void cerrarConexion() {
        if (requisitoLegalService != null) {
            requisitoLegalService.close();
        }
    }

    private String calcularEstado(Object fechaVencimiento) {
        if (fechaVencimiento == null || "NV".equals(fechaVencimiento) || "No Vence".equals(fechaVencimiento)) {
            return "Vigente";
        }
        
        if (fechaVencimiento instanceof java.sql.Date) {
            LocalDate fechaVenc = ((java.sql.Date) fechaVencimiento).toLocalDate();
            LocalDate ahora = LocalDate.now();
            
            if (fechaVenc.isBefore(ahora)) {
                return "VENCIDO";
            } else if (fechaVenc.minusDays(30).isBefore(ahora)) {
                return "Por vencer";
            } else {
                return "Vigente";
            }
        }
        
        return "Vigente";
    }

    // Método auxiliar para efectos hover modernos
    private void addModernHoverEffect(Button button, String normalStyle, String hoverStyle) {
        String baseStyle = 
            "-fx-text-fill: white; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 15; " +
            "-fx-border-radius: 15; " +
            "-fx-padding: 20 30; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; ";

        button.setOnMouseEntered(_ -> button.setStyle(
            "-fx-background-color: " + hoverStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 6); " +
            "-fx-scale-x: 1.02; -fx-scale-y: 1.02;"
        ));

        button.setOnMouseExited(_ -> button.setStyle(
            "-fx-background-color: " + normalStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 4);"
        ));
    }

    // Método auxiliar para efectos hover en botones de tabla
    private void addTableButtonHoverEffect(Button button, String normalStyle, String hoverStyle) {
        String baseStyle = 
            "-fx-text-fill: white; " +
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 10; " +
            "-fx-border-radius: 10; " +
            "-fx-cursor: hand; " +
            "-fx-font-family: 'Segoe UI', Arial, sans-serif; ";

        button.setOnMouseEntered(_ -> button.setStyle(
            "-fx-background-color: " + hoverStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 3); " +
            "-fx-scale-x: 1.05; -fx-scale-y: 1.05;"
        ));

        button.setOnMouseExited(_ -> button.setStyle(
            "-fx-background-color: " + normalStyle + "; " + baseStyle +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 6, 0, 0, 2);"
        ));
    }

    // Clase interna para representar una fila de la tabla
    public static class RequisitoLegalTableRow {
        
        private final String nombreRequisitoLegal;
        private final String fechaEmision;
        private final String fechaVencimiento;
        private final String fechaProximaRenovacion;
        private final String estado;
        private final String cantidadArchivos;

        public RequisitoLegalTableRow(String nombreRequisitoLegal, String fechaEmision, String fechaVencimiento,
                                    String fechaProximaRenovacion, String estado, String cantidadArchivos) {
            this.nombreRequisitoLegal = nombreRequisitoLegal;
            this.fechaEmision = fechaEmision;
            this.fechaVencimiento = fechaVencimiento;
            this.fechaProximaRenovacion = fechaProximaRenovacion;
            this.estado = estado;
            this.cantidadArchivos = cantidadArchivos;
        }

        public String getNombreRequisitoLegal() {
            return nombreRequisitoLegal;
        }

        public String getFechaEmision() {
            return fechaEmision;
        }

        public String getFechaVencimiento() {
            return fechaVencimiento;
        }

        public String getFechaProximaRenovacion() {
            return fechaProximaRenovacion;
        }

        public String getEstado() {
            return estado;
        }

        public String getCantidadArchivos() {
            return cantidadArchivos;
        }
    }
}
