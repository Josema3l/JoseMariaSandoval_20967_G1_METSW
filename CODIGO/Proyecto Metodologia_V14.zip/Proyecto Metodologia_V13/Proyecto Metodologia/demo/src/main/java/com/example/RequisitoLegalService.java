package com.example;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;

public class RequisitoLegalService {
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "sistema_requisitos_legales";
    private static final String COLLECTION_NAME = "requisitos_legales";
    
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;
    private GridFSBucket gridFSBucket;

    public RequisitoLegalService() {
        connect();
    }

    // Convierte un String de fecha a java.sql.Date, o devuelve la cadena "NV" si corresponde.
    private Object parseFechaString(String fecha) {
        if (fecha == null) return null;
        if ("NV".equals(fecha)) return fecha;
        if ("No Vence".equalsIgnoreCase(fecha)) return "NV";
        try {
            return java.sql.Date.valueOf(fecha);
        } catch (Exception e) {
            return null;
        }
    }

    private void connect() {
        try {
            mongoClient = MongoClients.create(CONNECTION_STRING);
            database = mongoClient.getDatabase(DATABASE_NAME);
            collection = database.getCollection(COLLECTION_NAME);
            gridFSBucket = GridFSBuckets.create(database, "requisitos_archivos");
        } catch (Exception e) {
            System.err.println("Error al conectar con MongoDB: " + e.getMessage());
            throw new RuntimeException("No se pudo conectar a la base de datos", e);
        }
    }

    private ObjectId subirArchivo(File archivo) {
        try (FileInputStream streamArchivo = new FileInputStream(archivo)) {
            GridFSUploadOptions options = new GridFSUploadOptions()
                .metadata(new Document("originalName", archivo.getName())
                         .append("contentType", determinarTipoContenido(archivo.getName())));
            
            return gridFSBucket.uploadFromStream(archivo.getName(), streamArchivo, options);
        } catch (IOException e) {
            System.err.println("Error al subir archivo " + archivo.getName() + ": " + e.getMessage());
            return null;
        }
    }

    private String determinarTipoContenido(String nombreArchivo) {
        String extension = nombreArchivo.substring(nombreArchivo.lastIndexOf('.') + 1).toLowerCase();
        switch (extension) {
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "txt": return "text/plain";
            default: return "application/octet-stream";
        }
    }

    public boolean descargarArchivo(ObjectId archivoId, String rutaDestino) {
        try (FileOutputStream streamDestino = new FileOutputStream(rutaDestino)) {
            gridFSBucket.downloadToStream(archivoId, streamDestino);
            return true;
        } catch (IOException e) {
            System.err.println("Error al descargar archivo: " + e.getMessage());
            return false;
        }
    }

    public String guardarRequisitoLegal(String nombreRequisitoLegal, LocalDate fechaEmision, 
                                      LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, 
                                      List<File> archivos) {
        try {
            Document requisitoLegal = new Document();
            requisitoLegal.append("nombreRequisitoLegal", nombreRequisitoLegal);
            requisitoLegal.append("fechaEmision", fechaEmision != null ? java.sql.Date.valueOf(fechaEmision) : null);

            // Manejo especial para fechas que pueden ser "No Vence"
            if (fechaVencimiento != null) {
                requisitoLegal.append("fechaVencimiento", java.sql.Date.valueOf(fechaVencimiento));
            } else {
                requisitoLegal.append("fechaVencimiento", "NV");
            }

            if (fechaProximaRenovacion != null) {
                requisitoLegal.append("fechaProximaRenovacion", java.sql.Date.valueOf(fechaProximaRenovacion));
            } else {
                requisitoLegal.append("fechaProximaRenovacion", "NV");
            }

            requisitoLegal.append("fechaCreacion", new Date());

            // Subir archivos
            List<ObjectId> archivosIds = new ArrayList<>();
            List<String> nombresArchivos = new ArrayList<>();
            
            for (File archivo : archivos) {
                ObjectId archivoId = subirArchivo(archivo);
                if (archivoId != null) {
                    archivosIds.add(archivoId);
                    nombresArchivos.add(archivo.getName());
                }
            }
            
            requisitoLegal.append("archivosIds", archivosIds);
            requisitoLegal.append("nombresArchivos", nombresArchivos);

            collection.insertOne(requisitoLegal);
            return "Requisito legal guardado exitosamente";
        } catch (Exception e) {
            System.err.println("Error al guardar requisito legal: " + e.getMessage());
            return "Error al guardar requisito legal: " + e.getMessage();
        }
    }

    public List<Document> obtenerTodosLosRequisitosLegales() {
        List<Document> requisitosLegales = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                requisitosLegales.add(cursor.next());
            }
        } catch (Exception e) {
            System.err.println("Error al obtener requisitos legales: " + e.getMessage());
        }
        return requisitosLegales;
    }

    public boolean existeRequisito(String nombreRequisitoLegal) {
        try {
            Document filtro = new Document("nombreRequisitoLegal", nombreRequisitoLegal);
            return collection.countDocuments(filtro) > 0;
        } catch (Exception e) {
            System.err.println("Error al verificar si existe el requisito: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarRequisito(String nombreRequisitoLegal) {
        try {
            // Primero obtener el documento para eliminar los archivos asociados
            Document filtro = new Document("nombreRequisitoLegal", nombreRequisitoLegal);
            Document requisito = collection.find(filtro).first();
            
            if (requisito != null) {
                // Eliminar archivos de GridFS si existen
                @SuppressWarnings("unchecked")
                List<ObjectId> archivosIds = (List<ObjectId>) requisito.get("archivosIds");
                if (archivosIds != null) {
                    for (ObjectId archivoId : archivosIds) {
                        try {
                            gridFSBucket.delete(archivoId);
                        } catch (Exception e) {
                            System.err.println("Error al eliminar archivo con ID " + archivoId + ": " + e.getMessage());
                        }
                    }
                }
                
                // Eliminar el documento de la colección
                collection.deleteOne(filtro);
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error al eliminar requisito legal: " + e.getMessage());
            return false;
        }
    }

    public Document obtenerRequisitoPorNombre(String nombreRequisitoLegal) {
        try {
            Document filtro = new Document("nombreRequisitoLegal", nombreRequisitoLegal);
            return collection.find(filtro).first();
        } catch (Exception e) {
            System.err.println("Error al obtener requisito legal: " + e.getMessage());
            return null;
        }
    }

    public boolean agregarArchivo(String nombreRequisitoLegal, File archivo) {
        try {
            Document filtro = new Document("nombreRequisitoLegal", nombreRequisitoLegal);
            Document requisito = collection.find(filtro).first();
            
            if (requisito != null) {
                ObjectId archivoId = subirArchivo(archivo);
                if (archivoId != null) {
                    // Actualizar las listas de archivos
                    @SuppressWarnings("unchecked")
                    List<ObjectId> archivosIds = (List<ObjectId>) requisito.get("archivosIds");
                    @SuppressWarnings("unchecked")
                    List<String> nombresArchivos = (List<String>) requisito.get("nombresArchivos");
                    
                    if (archivosIds == null) archivosIds = new ArrayList<>();
                    if (nombresArchivos == null) nombresArchivos = new ArrayList<>();
                    
                    archivosIds.add(archivoId);
                    nombresArchivos.add(archivo.getName());
                    
                    Document actualizacion = new Document("$set", new Document()
                        .append("archivosIds", archivosIds)
                        .append("nombresArchivos", nombresArchivos));
                    
                    collection.updateOne(filtro, actualizacion);
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error al agregar archivo: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarArchivo(String nombreRequisitoLegal, int indiceArchivo) {
        try {
            Document filtro = new Document("nombreRequisitoLegal", nombreRequisitoLegal);
            Document requisito = collection.find(filtro).first();
            
            if (requisito != null) {
                @SuppressWarnings("unchecked")
                List<ObjectId> archivosIds = (List<ObjectId>) requisito.get("archivosIds");
                @SuppressWarnings("unchecked")
                List<String> nombresArchivos = (List<String>) requisito.get("nombresArchivos");
                
                if (archivosIds != null && nombresArchivos != null && 
                    indiceArchivo >= 0 && indiceArchivo < archivosIds.size()) {
                    
                    // Eliminar archivo de GridFS
                    ObjectId archivoId = archivosIds.get(indiceArchivo);
                    gridFSBucket.delete(archivoId);
                    
                    // Remover de las listas
                    archivosIds.remove(indiceArchivo);
                    nombresArchivos.remove(indiceArchivo);
                    
                    // Actualizar el documento
                    Document actualizacion = new Document("$set", new Document()
                        .append("archivosIds", archivosIds)
                        .append("nombresArchivos", nombresArchivos));
                    
                    collection.updateOne(filtro, actualizacion);
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error al eliminar archivo: " + e.getMessage());
            return false;
        }
    }

    public boolean descargarArchivoDeRequisito(String nombreRequisitoLegal, int indiceArchivo, String rutaDestino) {
        try {
            Document filtro = new Document("nombreRequisitoLegal", nombreRequisitoLegal);
            Document requisito = collection.find(filtro).first();
            
            if (requisito != null) {
                @SuppressWarnings("unchecked")
                List<ObjectId> archivosIds = (List<ObjectId>) requisito.get("archivosIds");
                @SuppressWarnings("unchecked")
                List<String> nombresArchivos = (List<String>) requisito.get("nombresArchivos");
                
                if (archivosIds != null && indiceArchivo >= 0 && indiceArchivo < archivosIds.size()) {
                    ObjectId archivoId = archivosIds.get(indiceArchivo);
                    String nombreArchivo = nombresArchivos.get(indiceArchivo);
                    
                    // Crear la ruta completa de destino
                    String rutaCompleta = rutaDestino + File.separator + nombreArchivo;
                    return descargarArchivo(archivoId, rutaCompleta);
                }
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error al descargar archivo de requisito: " + e.getMessage());
            return false;
        }
    }

    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
