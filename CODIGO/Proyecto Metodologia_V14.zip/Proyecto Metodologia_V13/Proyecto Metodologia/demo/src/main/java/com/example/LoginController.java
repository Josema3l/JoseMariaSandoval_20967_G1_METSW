package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController {
    private UsuarioService usuarioService = new UsuarioService();
    private int intentos = 0;
    private long tiempoBloqueo = 0; // tiempo en milisegundos

    public void mostrarPantallaLogin(Stage stage) {
        // Logo con estilo mejorado
        Image logoImg = new Image(getClass().getResourceAsStream("/logo.png"));
        ImageView logoView = new ImageView(logoImg);
        logoView.setFitWidth(100);
        logoView.setPreserveRatio(true);
        logoView.setStyle("-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 2);");

        // Título principal
        Label lblTitulo = new Label("Bienvenido");
        lblTitulo.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");

        Label lblSubtitulo = new Label("Sistema de Gestión Documental");
        lblSubtitulo.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d; -fx-padding: 0 0 20 0;");

        // Campos de entrada con estilo mejorado
        Label lblUsuario = new Label("Usuario:");
        lblUsuario.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #34495e;");
        
        TextField txtUsuario = new TextField();
        txtUsuario.setPrefWidth(280);
        txtUsuario.setPrefHeight(40);
        txtUsuario.setPromptText("Ingrese su nombre de usuario");
        txtUsuario.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 2px; " +
            "-fx-border-radius: 8px; " +
            "-fx-background-radius: 8px; " +
            "-fx-padding: 10px; " +
            "-fx-font-size: 14px; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 1);"
        );

        Label lblContrasena = new Label("Contraseña:");
        lblContrasena.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #34495e;");
        
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setPrefWidth(280);
        txtContrasena.setPrefHeight(40);
        txtContrasena.setPromptText("Ingrese su contraseña");
        txtContrasena.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-border-color: #bdc3c7; " +
            "-fx-border-width: 2px; " +
            "-fx-border-radius: 8px; " +
            "-fx-background-radius: 8px; " +
            "-fx-padding: 10px; " +
            "-fx-font-size: 14px; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 1);"
        );

        // Botón de login con estilo mejorado
        Button btnLogin = new Button("Iniciar Sesión");
        btnLogin.setPrefWidth(280);
        btnLogin.setPrefHeight(45);
        btnLogin.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #3498db, #2980b9); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8px; " +
            "-fx-border-radius: 8px; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);"
        );

        // Efecto hover para el botón login
        btnLogin.setOnMouseEntered(e -> btnLogin.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #5dade2, #3498db); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8px; " +
            "-fx-border-radius: 8px; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 10, 0, 0, 3);"
        ));

        btnLogin.setOnMouseExited(e -> btnLogin.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #3498db, #2980b9); " +
            "-fx-text-fill: white; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 8px; " +
            "-fx-border-radius: 8px; " +
            "-fx-cursor: hand; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);"
        ));

        // Botón de recuperar contraseña con estilo mejorado
        Button btnRecuperar = new Button("¿Olvidaste tu contraseña?");
        btnRecuperar.setPrefWidth(280);
        btnRecuperar.setPrefHeight(35);
        btnRecuperar.setStyle(
            "-fx-background-color: transparent; " +
            "-fx-text-fill: #e67e22; " +
            "-fx-font-size: 13px; " +
            "-fx-underline: true; " +
            "-fx-cursor: hand; " +
            "-fx-border-color: transparent; " +
            "-fx-background-radius: 5px;"
        );

        // Efecto hover para el botón recuperar
        btnRecuperar.setOnMouseEntered(e -> btnRecuperar.setStyle(
            "-fx-background-color: #fdf2e9; " +
            "-fx-text-fill: #d35400; " +
            "-fx-font-size: 13px; " +
            "-fx-underline: true; " +
            "-fx-cursor: hand; " +
            "-fx-border-color: #e67e22; " +
            "-fx-border-width: 1px; " +
            "-fx-background-radius: 5px; " +
            "-fx-border-radius: 5px;"
        ));

        btnRecuperar.setOnMouseExited(e -> btnRecuperar.setStyle(
            "-fx-background-color: transparent; " +
            "-fx-text-fill: #e67e22; " +
            "-fx-font-size: 13px; " +
            "-fx-underline: true; " +
            "-fx-cursor: hand; " +
            "-fx-border-color: transparent; " +
            "-fx-background-radius: 5px;"
        ));

        Label lblMensaje = new Label();
        lblMensaje.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 12px;");

        // Configurar eventos
        btnLogin.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage, btnLogin));
        txtContrasena.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage, btnLogin));
        btnRecuperar.setOnAction(_ -> mostrarRecuperarContrasena(stage));

        // Crear layout principal con mejor espaciado
        VBox formContainer = new VBox(15);
        formContainer.getChildren().addAll(
            lblUsuario, txtUsuario,
            lblContrasena, txtContrasena,
            btnLogin, btnRecuperar, lblMensaje
        );
        formContainer.setAlignment(Pos.CENTER);
        formContainer.setStyle(
            "-fx-background-color: #ffffff; " +
            "-fx-padding: 40px; " +
            "-fx-background-radius: 15px; " +
            "-fx-border-radius: 15px; " +
            "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 20, 0, 0, 5);"
        );

        VBox headerContainer = new VBox(10, logoView, lblTitulo, lblSubtitulo);
        headerContainer.setAlignment(Pos.CENTER);

        VBox mainContainer = new VBox(30, headerContainer, formContainer);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setMaxWidth(400);

        StackPane root = new StackPane(mainContainer);
        root.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #ecf0f1, #bdc3c7); " +
            "-fx-padding: 40px;"
        );

        Scene scene = new Scene(root, 500, 700);
        stage.setTitle("Sistema de Gestión Documental - Login");
        stage.setScene(scene);
        stage.setMaximized(false);
        stage.setWidth(500);
        stage.setHeight(700);
        stage.centerOnScreen();
        stage.show();
    }

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error de inicio de sesión");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void verificarLogin(TextField txtUsuario, PasswordField txtContrasena, Label lblMensaje, Stage stage, Button btnLogin) {
        long ahora = System.currentTimeMillis();
        if (ahora < tiempoBloqueo) {
            mostrarError("Demasiados intentos. Intenta de nuevo en 5 minutos.");
            btnLogin.setDisable(true);
            return;
        } else {
            btnLogin.setDisable(false);
        }

        String usuario = txtUsuario.getText();
        String contrasena = txtContrasena.getText();
        if (usuarioService.verificarUsuario(usuario, contrasena)) {
            intentos = 0;
            String rol = usuarioService.getRol(usuario);
            if (rol == null || rol.isEmpty()) {
                mostrarError("El usuario no tiene un rol asignado o no es válido.");
                return;
            }
            
            // Verificar si está usando una contraseña temporal
            if (usuarioService.esContrasenaTemporal(contrasena)) {
                mostrarDialogoCambioContrasenaObligatorio(usuario, stage, rol);
            } else {
                new PanelController(usuarioService).mostrarPantallaPanel(stage, usuario, rol);
            }
        } else {
            intentos++;
            if (intentos >= 3) {
                mostrarError("Demasiados intentos. Intenta de nuevo en 5 minutos.");
                tiempoBloqueo = System.currentTimeMillis() + 5 * 60 * 1000; // 5 minutos
                btnLogin.setDisable(true);
                new Thread(() -> {
                    try {
                        Thread.sleep(5 * 60 * 1000);
                    } catch (InterruptedException e) {
                        // Ignorar
                    }
                    javafx.application.Platform.runLater(() -> {
                        intentos = 0;
                        btnLogin.setDisable(false);
                        lblMensaje.setText("");
                    });
                }).start();
            } else {
                mostrarError("Usuario o contraseña incorrectos. Intento " + intentos + " de 3.");
            }
        }
    }

    private void mostrarRecuperarContrasena(Stage stage) {
        new RecuperarContrasenaDialog(usuarioService, stage).mostrar();
    }

    private void mostrarDialogoCambioContrasenaObligatorio(String usuario, Stage stage, String rol) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Contraseña temporal");
        alert.setHeaderText("Debe cambiar su contraseña");
        alert.setContentText("Está utilizando una contraseña temporal. Por seguridad, debe cambiar su contraseña antes de continuar.");
        
        alert.showAndWait().ifPresent(response -> {
            // Crear diálogo para cambio de contraseña
            Stage cambioStage = new Stage();
            cambioStage.setTitle("Cambiar contraseña");
            VBox formBox = new VBox(15);
            formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 25 25 20 25; -fx-border-radius: 12; -fx-background-radius: 12;");
            formBox.setAlignment(javafx.geometry.Pos.CENTER);

            Label titulo = new Label("Cambiar contraseña");
            titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

            Label lblNuevaContrasena = new Label("Nueva contraseña:");
            PasswordField txtNuevaContrasena = new PasswordField();
            txtNuevaContrasena.setPrefWidth(200);

            Label lblConfirmarContrasena = new Label("Confirmar contraseña:");
            PasswordField txtConfirmarContrasena = new PasswordField();
            txtConfirmarContrasena.setPrefWidth(200);

            Button btnCambiar = new Button("Cambiar contraseña");
            btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");

            formBox.getChildren().addAll(titulo, lblNuevaContrasena, txtNuevaContrasena, 
                                        lblConfirmarContrasena, txtConfirmarContrasena, btnCambiar);

            btnCambiar.setOnAction(e -> {
                String nuevaContrasena = txtNuevaContrasena.getText();
                String confirmarContrasena = txtConfirmarContrasena.getText();

                if (nuevaContrasena == null || nuevaContrasena.trim().isEmpty() ||
                    confirmarContrasena == null || confirmarContrasena.trim().isEmpty()) {
                    mostrarError("Debe completar todos los campos");
                    return;
                }

                if (!nuevaContrasena.equals(confirmarContrasena)) {
                    mostrarError("Las contraseñas no coinciden");
                    return;
                }

                if (nuevaContrasena.length() < 6) {
                    mostrarError("La contraseña debe tener al menos 6 caracteres");
                    return;
                }

                usuarioService.actualizarContrasena(usuario, nuevaContrasena);
                cambioStage.close();
                new PanelController(usuarioService).mostrarPantallaPanel(stage, usuario, rol);
            });

            javafx.scene.Scene cambioScene = new javafx.scene.Scene(formBox);
            cambioStage.setScene(cambioScene);
            cambioStage.initOwner(stage);
            cambioStage.setOnCloseRequest(event -> {
                event.consume(); // Prevenir cerrar sin cambiar contraseña
                mostrarError("Debe cambiar su contraseña temporal antes de continuar");
            });
            cambioStage.showAndWait();
        });
    }

    public java.util.Map<String, String[]> getUsuarios() {
        return usuarioService.getUsuarios();
    }
}
