package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CrearUsuarioDialog {
    private final UsuarioService usuarioService;
    private final Stage parentStage;

    public CrearUsuarioDialog(UsuarioService usuarioService, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.parentStage = parentStage;
    }

    public void mostrar(Label lblMensaje) {
        Stage stage = new Stage();
        stage.setTitle("Crear nuevo usuario");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);
        Label titulo = new Label("Crear nuevo usuario");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");

        Label lblUsuario = new Label("Usuario:");
        TextField txtUsuario = new TextField();
        txtUsuario.setPrefWidth(220);
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setPrefWidth(220);
        Label lblRol = new Label("Rol:");
        ComboBox<String> comboRol = new ComboBox<>();
        comboRol.getItems().addAll("Administradora", "Cliente", "Tester");
        comboRol.setPromptText("Seleccione rol");
        comboRol.setPrefWidth(220);

        VBox campos = new VBox(10, lblUsuario, txtUsuario, lblContrasena, txtContrasena, lblRol, comboRol);
        formBox.getChildren().addAll(titulo, campos);

        Button btnCrear = new Button("Crear");
        btnCrear.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(e -> stage.close());
        HBox hboxBotones = new HBox(16, btnCrear, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        Scene scene = new Scene(formBox);
        stage.setScene(scene);

        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stage.close();
            }
        });

        btnCrear.setOnAction(e -> {
            String usuario = txtUsuario.getText();
            String contrasena = txtContrasena.getText();
            String rol = comboRol.getValue();
            if (usuario == null || usuario.isEmpty() || contrasena == null || contrasena.isEmpty() || rol == null || rol.isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "Debe completar todos los campos y seleccionar un rol", false, null);
                return;
            }
            usuarioService.crearUsuario(usuario, contrasena, rol);
            DialogUtils.mostrarAviso(formBox, "Usuario creado: " + usuario + " (rol: " + rol + ")", true, stage::close);
        });

        stage.initOwner(parentStage);
        stage.showAndWait();
    }
}
