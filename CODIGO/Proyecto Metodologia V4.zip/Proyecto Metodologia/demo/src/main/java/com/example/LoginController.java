package com.example;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

public class LoginController {
    private UsuarioService usuarioService = new UsuarioService();

    public void mostrarPantallaLogin(Stage stage) {
        Image logoImg = new Image(getClass().getResourceAsStream("/logo.png"));
        ImageView logoView = new ImageView(logoImg);
        logoView.setFitWidth(120);
        logoView.setPreserveRatio(true);

        Label lblUsuario = new Label("Usuario:");
        TextField txtUsuario = new TextField();
        txtUsuario.setMaxWidth(160);
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setMaxWidth(160);
        Button btnLogin = new Button("Iniciar sesión");
        Label lblMensaje = new Label();
        btnLogin.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage));
        txtContrasena.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage));
        VBox vbox = new VBox(12, logoView, lblUsuario, txtUsuario, lblContrasena, txtContrasena, btnLogin, lblMensaje);
        vbox.setAlignment(Pos.CENTER);
        StackPane root = new StackPane(vbox);
        root.setStyle("-fx-background-color: #f0f0f0;");
        Scene scene = new Scene(root, 400, 340);
        stage.setTitle("Login JavaFX");
        stage.setScene(scene);
        stage.setMaximized(false);
        stage.setWidth(400);
        stage.setHeight(340);
        stage.centerOnScreen();
        stage.show();
    }

    private void verificarLogin(TextField txtUsuario, PasswordField txtContrasena, Label lblMensaje, Stage stage) {
        String usuario = txtUsuario.getText();
        String contrasena = txtContrasena.getText();
        if (usuarioService.verificarUsuario(usuario, contrasena)) {
            String rol = usuarioService.getRol(usuario);
            new PanelController(usuarioService).mostrarPantallaPanel(stage, usuario, rol);
        } else {
            lblMensaje.setText("Usuario o contraseña incorrectos");
        }
    }

    // Permitir acceso a los usuarios para poblar el ComboBox
    public java.util.Map<String, String[]> getUsuarios() {
        return usuarioService.getUsuarios();
    }
}
