package com.example;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class RegistroDocumentoDialog {
    private final Stage parentStage;
    private final DocumentoService documentoService;
    private List<File> archivosSeleccionados;

    public RegistroDocumentoDialog(Stage parentStage) {
        this.parentStage = parentStage;
        this.documentoService = new DocumentoService();
        this.archivosSeleccionados = new ArrayList<>();
    }

    public void mostrar() {
        Stage registroStage = new Stage();
        registroStage.setTitle("Registrar documento legal");
        Label lblMensaje = new Label();
        TextField txtUsuario = new TextField();
        TextField txtNombreDocumento = new TextField();
        DatePicker dtpFechaEmision = new DatePicker();
        DatePicker dtpFechaVencimiento = new DatePicker();
        DatePicker dtpFechaProximaRenovacion = new DatePicker();
        javafx.scene.control.CheckBox chkNoVence = new javafx.scene.control.CheckBox("No vence");

        // Manejo de checkbox para deshabilitar ambos DatePicker
        chkNoVence.setOnAction(e -> {
            if (chkNoVence.isSelected()) {
                dtpFechaVencimiento.setDisable(true);
                dtpFechaVencimiento.setValue(null);
                dtpFechaProximaRenovacion.setDisable(true);
                dtpFechaProximaRenovacion.setValue(null);
            } else {
                dtpFechaVencimiento.setDisable(false);
                dtpFechaProximaRenovacion.setDisable(false);
            }
        });

        // Sección para archivos
        Label lblArchivos = new Label("Archivos adjuntos:");
        ListView<String> listViewArchivos = new ListView<>();
        listViewArchivos.setPrefHeight(100);

        Button btnSeleccionarArchivos = new Button("Seleccionar archivos");
        btnSeleccionarArchivos.setOnAction(e -> seleccionarArchivos(listViewArchivos));

        Button btnEliminarArchivo = new Button("Eliminar seleccionado");
        btnEliminarArchivo.setOnAction(e -> eliminarArchivoSeleccionado(listViewArchivos));

        HBox hboxArchivos = new HBox(10, btnSeleccionarArchivos, btnEliminarArchivo);
        hboxArchivos.setAlignment(Pos.CENTER_LEFT);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Usuario que subió el documento:"), 0, 0);
        grid.add(txtUsuario, 1, 0);
        grid.add(new Label("Nombre del documento:"), 0, 1);
        grid.add(txtNombreDocumento, 1, 1);
        grid.add(new Label("Fecha de emisión:"), 0, 2);
        grid.add(dtpFechaEmision, 1, 2);
        grid.add(new Label("Fecha de vencimiento:"), 0, 3);
        HBox hboxVencimiento = new HBox(10, dtpFechaVencimiento, chkNoVence);
        grid.add(hboxVencimiento, 1, 3);
        grid.add(new Label("Fecha próxima de renovación:"), 0, 4);
        grid.add(dtpFechaProximaRenovacion, 1, 4);
        grid.add(lblArchivos, 0, 5);
        grid.add(listViewArchivos, 1, 5);
        grid.add(hboxArchivos, 1, 6);
        grid.add(lblMensaje, 0, 7, 2, 1);

        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(_ -> {
            String usuario = txtUsuario.getText();
            String nombreDocumento = txtNombreDocumento.getText();
            LocalDate fechaEmision = dtpFechaEmision.getValue();
            String valorNV = "NV";
            String fechaVencimientoStr = chkNoVence.isSelected() ? valorNV : (dtpFechaVencimiento.getValue() != null ? dtpFechaVencimiento.getValue().toString() : null);
            String fechaProximaRenovacionStr = chkNoVence.isSelected() ? valorNV : (dtpFechaProximaRenovacion.getValue() != null ? dtpFechaProximaRenovacion.getValue().toString() : null);


            if (usuario.isEmpty() || nombreDocumento.isEmpty() || fechaEmision == null ||
                (!chkNoVence.isSelected() && (fechaVencimientoStr == null || fechaProximaRenovacionStr == null))) {
                DialogUtils.mostrarAviso(grid, "Por favor, complete todos los campos correctamente. Si selecciona 'No vence', no debe ingresar fechas de vencimiento ni de renovación.", false, null);
                return;
            }
            
            // Validar que al menos se haya seleccionado un archivo
            if (archivosSeleccionados == null || archivosSeleccionados.isEmpty()) {
                DialogUtils.mostrarAviso(grid, "Debe adjuntar al menos un archivo para registrar el documento.", false, null);
                return;
            }

            // Validación de fechas solo si no es "No vence"
            if (!chkNoVence.isSelected()) {
                LocalDate fechaVencimiento = dtpFechaVencimiento.getValue();
                LocalDate fechaProximaRenovacion = dtpFechaProximaRenovacion.getValue();
                if (fechaVencimiento != null && fechaVencimiento.isBefore(fechaEmision)) {
                    DialogUtils.mostrarAviso(grid, "La fecha de vencimiento no puede ser anterior a la fecha de emisión.", false, null);
                    return;
                }
                if (fechaProximaRenovacion != null) {
                    if (!fechaProximaRenovacion.isAfter(fechaEmision)) {
                        DialogUtils.mostrarAviso(grid, "La fecha próxima de renovación debe ser mayor que la fecha de emisión.", false, null);
                        return;
                    }
                    if (fechaVencimiento != null && !fechaProximaRenovacion.isBefore(fechaVencimiento)) {
                        DialogUtils.mostrarAviso(grid, "La fecha próxima de renovación debe ser menor que la fecha de vencimiento.", false, null);
                        return;
                    }
                }
            }

            try {
                // Guardar documento usando el servicio
                boolean guardado = documentoService.guardarDocumento(
                    usuario, nombreDocumento,
                    fechaEmision,
                    fechaVencimientoStr,
                    fechaProximaRenovacionStr,
                    archivosSeleccionados
                );

                if (guardado) {
                    DialogUtils.mostrarAviso(grid, "Documento registrado exitosamente.", true, () -> {
                        txtUsuario.clear();
                        txtNombreDocumento.clear();
                        dtpFechaEmision.setValue(null);
                        dtpFechaVencimiento.setValue(null);
                        dtpFechaProximaRenovacion.setValue(null);
                        archivosSeleccionados.clear();
                        listViewArchivos.getItems().clear();
                    });
                } else {
                    DialogUtils.mostrarAviso(grid, "Error al guardar el documento.", false, null);
                }

            } catch (Exception ex) {
                DialogUtils.mostrarAviso(grid, "Error al guardar el documento: " + ex.getMessage(), false, null);
                ex.printStackTrace();
            }
        });

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(e -> registroStage.close());

        HBox hboxBotones = new HBox(10, btnGuardar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        grid.add(hboxBotones, 0, 8, 2, 1);

        Scene scene = new Scene(grid, 650, 500);
        registroStage.setScene(scene);
        registroStage.initOwner(parentStage);
        registroStage.show();

        // Cerrar conexión cuando se cierre la ventana
        registroStage.setOnCloseRequest(e -> cerrarConexion());
    }

    private void seleccionarArchivos(ListView<String> listViewArchivos) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivos");

        // Configurar filtros de archivo
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Documentos Excel", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp"),
            new FileChooser.ExtensionFilter("Archivos de texto", "*.txt", "*.rtf")
        );

        List<File> archivos = fileChooser.showOpenMultipleDialog(parentStage);
        if (archivos != null) {
            for (File archivo : archivos) {
                if (!archivosSeleccionados.contains(archivo)) {
                    archivosSeleccionados.add(archivo);
                    listViewArchivos.getItems().add(archivo.getName() + " (" + formatFileSize(archivo.length()) + ")");
                }
            }
        }
    }

    private void eliminarArchivoSeleccionado(ListView<String> listViewArchivos) {
        int selectedIndex = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            archivosSeleccionados.remove(selectedIndex);
            listViewArchivos.getItems().remove(selectedIndex);
        }
    }

    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024.0));
        return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
    }

    public void cerrarConexion() {
        if (documentoService != null) {
            documentoService.cerrarConexion();
        }
    }
}