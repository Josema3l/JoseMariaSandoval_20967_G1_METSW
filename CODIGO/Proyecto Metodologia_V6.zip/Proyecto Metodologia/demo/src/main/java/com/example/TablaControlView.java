package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
// imports cleaned up
import javafx.collections.FXCollections;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class TablaControlView {
    private final PanelController panelController;

    public TablaControlView(PanelController panelController) {
        this.panelController = panelController;
    }

    public void mostrar() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("Tabla de control de documentos legales");
        javafx.scene.control.Button btnRegistrar = new javafx.scene.control.Button("Registrar documento");
        javafx.scene.control.Button btnVer = new javafx.scene.control.Button("Ver documentos registrados");
        VBox vbox = new VBox(20, btnRegistrar, btnVer);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPrefSize(400, 200);
        Scene scene = new Scene(vbox);
        tablaStage.setScene(scene);
        tablaStage.show();

        btnRegistrar.setOnAction(_ -> {
            tablaStage.close();
            panelController.mostrarFormularioRegistro();
        });
        btnVer.setOnAction(_ -> {
            tablaStage.close();
            panelController.mostrarDocumentosRegistrados();
        });
    }

    // Static method for modularized document viewing
    public static void mostrarDocumentosRegistrados() {
        Stage docsStage = new Stage();
        docsStage.setTitle("Documentos registrados");
        TableView<String[]> table = new TableView<>();
        String[] headers = {"Código nro", "Requisito Legal", "Cómo se aplica", "Por qué lo aplica", "Fecha de emisión", "Fecha de vencimiento", "Fecha próxima de renovación"};
        for (int i = 0; i < headers.length; i++) {
            final int colIdx = i;
            TableColumn<String[], String> col = new TableColumn<>(headers[i]);
            col.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue()[colIdx]));
            col.setPrefWidth(150);
            table.getColumns().add(col);
        }
        // Leer documentos.txt
        List<String[]> rows = new ArrayList<>();
        try {
            Path path = Paths.get("documentos.txt");
            if (Files.exists(path)) {
                List<String> lines = Files.readAllLines(path);
                for (String line : lines) {
                    String[] parts = line.split(";");
                    if (parts.length == headers.length) {
                        rows.add(parts);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        table.setItems(FXCollections.observableArrayList(rows));

        VBox vbox = new VBox(table);
        Scene scene = new Scene(vbox);
        docsStage.setScene(scene);
        docsStage.show();
    }
}
