package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CambioUsuarioDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioUsuarioDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar usuario");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);
        Label titulo = new Label("Cambiar usuario");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");
        Label lblUsuarioActual = new Label("Usuario actual:");
        ComboBox<String> comboUsuarioActual = new ComboBox<>();
        comboUsuarioActual.setPrefWidth(220);
        Label lblNuevoUsuario = new Label("Nuevo usuario:");
        TextField txtNuevoUsuario = new TextField();
        txtNuevoUsuario.setPrefWidth(220);
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setPrefWidth(220);

        if (!rol.equalsIgnoreCase("Cliente")) {
            for (String u : usuarioService.getTodosLosUsuarios()) {
                comboUsuarioActual.getItems().add(u);
            }
            comboUsuarioActual.setEditable(false);
            comboUsuarioActual.setPromptText("Seleccione usuario actual");
            comboUsuarioActual.setStyle("-fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 6 10 6 10;");
        } else {
            comboUsuarioActual.getItems().add(usuario);
            comboUsuarioActual.setValue(usuario);
            comboUsuarioActual.setDisable(true);
        }

        VBox campos = new VBox(10, lblUsuarioActual, comboUsuarioActual, lblNuevoUsuario, txtNuevoUsuario);
        if (rol.equalsIgnoreCase("Cliente")) {
            campos.getChildren().addAll(lblContrasena, txtContrasena);
        }
        formBox.getChildren().addAll(titulo, campos);

        Button btnCambiar = new Button("Cambiar");
        btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(e -> stageCambio.close());
        HBox hboxBotones = new HBox(16, btnCambiar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        Scene scene = new Scene(formBox);
        stageCambio.setScene(scene);

        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        btnCambiar.setOnAction(e -> {
            boolean exito = false;
            if (rol.equalsIgnoreCase("Cliente")) {
                String usuarioActualIngresado = comboUsuarioActual.getValue();
                String nuevoUsuario = txtNuevoUsuario.getText();
                String contrasena = txtContrasena.getText();
                if (usuarioActualIngresado == null || usuarioActualIngresado.isEmpty() || nuevoUsuario == null || nuevoUsuario.isEmpty() || contrasena == null || contrasena.isEmpty()) {
                    DialogUtils.mostrarAviso(formBox, "Debe completar todos los campos.", false, null);
                    return;
                }
                if (!usuarioActualIngresado.equals(usuario)) {
                    DialogUtils.mostrarAviso(formBox, "El usuario actual ingresado no coincide con el usuario en sesión.", false, null);
                    return;
                }
                if (!usuarioService.verificarCredenciales(usuario, contrasena)) {
                    DialogUtils.mostrarAviso(formBox, "Contraseña incorrecta.", false, () -> {});
                    return;
                }
                usuarioService.cambiarCredenciales(usuario, nuevoUsuario, null);
                exito = true;
            } else {
                String usuarioObjetivo = comboUsuarioActual.getValue();
                String nuevoUsuario = txtNuevoUsuario.getText();
                if (usuarioObjetivo == null || usuarioObjetivo.isEmpty() || nuevoUsuario == null || nuevoUsuario.isEmpty()) {
                    DialogUtils.mostrarAviso(formBox, "Debe completar todos los campos.", false, () -> {});
                    return;
                }
                usuarioService.cambiarCredenciales(usuarioObjetivo, nuevoUsuario, null);
                exito = true;
            }
            if (exito) {
                DialogUtils.mostrarAviso(formBox, "Usuario cambiado exitosamente.", true, () -> stageCambio.close());
            } else {
                DialogUtils.mostrarAviso(formBox, "No se pudo cambiar el usuario.", false, () -> {});
            }
        });

        stageCambio.initOwner(parentStage);
        stageCambio.showAndWait();
    }
}
