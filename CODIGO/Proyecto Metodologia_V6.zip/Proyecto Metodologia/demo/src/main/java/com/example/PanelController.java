package com.example;

import java.time.LocalDate;
// importaciones eliminadas por modularización de correo
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PanelController {
    private final UsuarioService usuarioService;
    // private Stage mainStage; // removed duplicate

    public PanelController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // setMainStage is defined only once at the top of the class

    public void mostrarPantallaPanel(Stage stage, String usuario, String rol) {
        Label lbl = new Label("Bienvenido/a: " + usuario);
        lbl.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        Button btnMapa = new Button("Mapa de Procesos");
        btnMapa.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        Button btnTabla = new Button("Tabla de control");
        btnTabla.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        Button btnCerrar = new Button("Cerrar sesión");
        btnCerrar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        // Botones de cambio de usuario y contraseña eliminados (ahora solo en menú hamburguesa)
        Button btnEnviarRecordatorios = new Button("Enviar recordatorios");
        btnEnviarRecordatorios.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 16px; -fx-background-radius: 10; -fx-padding: 10 20 10 20;");
        Label lblMensaje = new Label();
        lblMensaje.setStyle("-fx-font-size: 15px; -fx-text-fill: #8e44ad; -fx-font-weight: bold;");

        HBox topBar = new HBox(10);
        topBar.setAlignment(Pos.TOP_LEFT);
        // Rediseño del botón desplegable (menú hamburguesa)
        MenuButton menuHamburguesa = new MenuButton();
        menuHamburguesa.setText("");
        menuHamburguesa.setStyle("-fx-background-color: transparent; -fx-padding: 0; -fx-border-width: 0;");
        // Ícono SVG hamburguesa
        javafx.scene.shape.SVGPath iconoHamburguesa = new javafx.scene.shape.SVGPath();
        iconoHamburguesa.setContent("M3 7h18M3 12h18M3 17h18");
        iconoHamburguesa.setStroke(javafx.scene.paint.Color.web("#2c3e50"));
        iconoHamburguesa.setStrokeWidth(3);
        iconoHamburguesa.setFill(javafx.scene.paint.Color.TRANSPARENT);
        iconoHamburguesa.setScaleX(1.5);
        iconoHamburguesa.setScaleY(1.5);
        menuHamburguesa.setGraphic(iconoHamburguesa);
        menuHamburguesa.setPrefSize(48, 48);
        menuHamburguesa.setPopupSide(javafx.geometry.Side.BOTTOM);
        // Menú para cambiar usuario
        MenuItem cambiarUsuario = new MenuItem("Cambiar usuario");
        cambiarUsuario.setOnAction(_ -> {
            new CambioUsuarioDialog(usuarioService, usuario, rol, stage).mostrar();
        });
        // Menú para cambiar contraseña
        MenuItem cambiarContrasena = new MenuItem("Cambiar contraseña");
        cambiarContrasena.setOnAction(_ -> {
            new CambioContrasenaDialog(usuarioService, usuario, rol, stage).mostrar();
        });
        // Opciones según el rol
        if (rol.equalsIgnoreCase("Administradora") || rol.equalsIgnoreCase("Tester")) {
            MenuItem crearUsuario = new MenuItem("Crear nuevo usuario");
            crearUsuario.setOnAction(_ -> mostrarDialogoCrearUsuario(lblMensaje));
            menuHamburguesa.getItems().addAll(crearUsuario, cambiarUsuario, cambiarContrasena);
        } else if (rol.equalsIgnoreCase("Cliente")) {
            menuHamburguesa.getItems().addAll(cambiarUsuario, cambiarContrasena);
        }
        topBar.getChildren().add(menuHamburguesa);

        StackPane panelCentral = new StackPane();
        // Fondo degradado para el panel central
        String gradient = rol.equals("Administradora")
            ? "-fx-background-color: linear-gradient(to bottom right, #e0eafc, #cfdef3, #f9f9f9);"
            : "-fx-background-color: linear-gradient(to bottom right, #b2fefa, #e0c3fc);";
        panelCentral.setStyle(gradient);

        VBox vboxMenu = new VBox();
        vboxMenu.setSpacing(30);
        // Solo Administradora ve el botón de recordatorios
        if (rol.equals("Administradora")) {
            vboxMenu.getChildren().add(btnEnviarRecordatorios);
            btnEnviarRecordatorios.setOnAction(_ -> revisarYEnviarRecordatorios(lblMensaje));
        }
        vboxMenu.getChildren().addAll(lbl, btnMapa, btnTabla, btnCerrar, lblMensaje);
        vboxMenu.setAlignment(Pos.TOP_CENTER);
        vboxMenu.setPrefWidth(270);
        vboxMenu.setStyle("-fx-background-color: linear-gradient(to bottom, #f8ffae, #43c6ac); -fx-border-color: #2980b9; -fx-border-width: 0 2px 0 0;");

        // --- Botón Cerrar Mapa (siempre presente pero oculto, se muestra solo con el mapa) ---
        Button btnCerrarMapaLateral = new Button("Cerrar mapa");
        btnCerrarMapaLateral.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8; -fx-padding: 8 18 8 18;");
        btnCerrarMapaLateral.setVisible(false);
        btnCerrarMapaLateral.setManaged(false);
        // Espaciador para empujar el botón hacia abajo
        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        VBox.setVgrow(spacer, javafx.scene.layout.Priority.ALWAYS);
        vboxMenu.getChildren().addAll(spacer, btnCerrarMapaLateral);

        btnCerrar.setOnAction(_ -> new LoginController().mostrarPantallaLogin(stage));
        // Acciones de cambio de usuario y contraseña eliminadas del menú lateral (ahora solo en menú hamburguesa)
        btnMapa.setOnAction(_ -> {
            if (rol.equals("Administradora")) {
                // Quitar mensaje antiguo y usar aviso moderno
                panelCentral.getChildren().clear();
                try {
                    Image mapaImg = new Image(getClass().getResourceAsStream("/mapa_procesos.png"));
                    ImageView mapaView = new ImageView(mapaImg);
                    mapaView.setPreserveRatio(true);
                    mapaView.setFitWidth(1250);
                    mapaView.setStyle("-fx-effect: dropshadow(gaussian, #34495e, 30, 0.3, 0, 0);");

                    // --- Botones sobre el mapa (no tocar) ---
                    String botonMapaBase = "-fx-background-radius: 15; -fx-font-weight: bold; -fx-font-size: 13px; -fx-border-width: 2; -fx-border-radius: 15;";
                    Button btnSistemasGestion = new Button("");
                    btnSistemasGestion.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;" + botonMapaBase);
                    btnSistemasGestion.setPrefSize(85, 75);
                    btnSistemasGestion.setLayoutX(805);
                    btnSistemasGestion.setLayoutY(190);
                    btnSistemasGestion.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/MEJORA CONTINUA", lblMensaje));
                    Button btnGestionComercial = new Button("Gestión de Comercialización");
                    btnGestionComercial.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnGestionComercial.setPrefSize(80, 90);
                    btnGestionComercial.setLayoutX(310);
                    btnGestionComercial.setLayoutY(455);
                    btnGestionComercial.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/GESTION DE COMERCIALIZACION", lblMensaje));
                    Button btnAnalisis = new Button("Análisis Vulnerabilidad");
                    btnAnalisis.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnAnalisis.setPrefSize(150, 120);
                    btnAnalisis.setLayoutX(440);
                    btnAnalisis.setLayoutY(425);
                    btnAnalisis.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ANALISIS VULNERABILIDAD", lblMensaje));
                    Button btnInduccion = new Button("Inducción Vigilante");
                    btnInduccion.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnInduccion.setPrefSize(105, 120);
                    btnInduccion.setLayoutX(605);
                    btnInduccion.setLayoutY(425);
                    btnInduccion.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/INDUCCION VIGILANTE", lblMensaje));
                    Button btnOperaciones = new Button("Operaciones Fija - Móvil");
                    btnOperaciones.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnOperaciones.setPrefSize(125, 120);
                    btnOperaciones.setLayoutX(725);
                    btnOperaciones.setLayoutY(425);
                    btnOperaciones.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/OPERACIONES FIJA-MOVIL", lblMensaje));
                    Button btnSupervision = new Button("Supervisión Control");
                    btnSupervision.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnSupervision.setPrefSize(118, 120);
                    btnSupervision.setLayoutX(860);
                    btnSupervision.setLayoutY(425);
                    btnSupervision.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SUPERVISION CONTROL", lblMensaje));
                    Button btnSatisfaccion = new Button("Satisfacción al Cliente");
                    btnSatisfaccion.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnSatisfaccion.setPrefSize(45, 65);
                    btnSatisfaccion.setLayoutX(1060);
                    btnSatisfaccion.setLayoutY(450);
                    btnSatisfaccion.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SATISFACCION AL CLIENTE", lblMensaje));
                    Button btnAdmin1 = new Button("A1");
                    btnAdmin1.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnAdmin1.setPrefSize(65, 70);
                    btnAdmin1.setLayoutX(145);
                    btnAdmin1.setLayoutY(685);
                    btnAdmin1.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CONTABLE", lblMensaje));
                    Button btnAdmin2 = new Button("A2");
                    btnAdmin2.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnAdmin2.setPrefSize(85, 70);
                    btnAdmin2.setLayoutX(225);
                    btnAdmin2.setLayoutY(685);
                    btnAdmin2.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ADQUISICIONES", lblMensaje));
                    Button btnAdmin3 = new Button("A3");
                    btnAdmin3.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnAdmin3.setPrefSize(63, 85);
                    btnAdmin3.setLayoutX(320);
                    btnAdmin3.setLayoutY(685);
                    btnAdmin3.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SEGURIDAD FISICA", lblMensaje));
                    Button btnAdmin4 = new Button("A4");
                    btnAdmin4.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnAdmin4.setPrefSize(60, 70);
                    btnAdmin4.setLayoutX(400);
                    btnAdmin4.setLayoutY(685);
                    btnAdmin4.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/LOGISTICA", lblMensaje));
                    Button btnTalento1 = new Button("T1");
                    btnTalento1.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnTalento1.setPrefSize(115, 70);
                    btnTalento1.setLayoutX(585);
                    btnTalento1.setLayoutY(700);
                    btnTalento1.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CONTRATACION", lblMensaje));
                    Button btnTalento2 = new Button("T2");
                    btnTalento2.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnTalento2.setPrefSize(130, 70);
                    btnTalento2.setLayoutX(715);
                    btnTalento2.setLayoutY(700);
                    btnTalento2.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/ADMINISTRACION", lblMensaje));
                    Button btnTalento3 = new Button("T3");
                    btnTalento3.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnTalento3.setPrefSize(135, 70);
                    btnTalento3.setLayoutX(850);
                    btnTalento3.setLayoutY(700);
                    btnTalento3.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/DESVINCULACION", lblMensaje));
                    Button btnTalento4 = new Button("T4");
                    btnTalento4.setStyle("-fx-background-color: linear-gradient(to bottom, #f7971e, #ffd200); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnTalento4.setPrefSize(110, 70);
                    btnTalento4.setLayoutX(990);
                    btnTalento4.setLayoutY(700);
                    btnTalento4.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/CAPACITACION", lblMensaje));
                    Button btnTalento5 = new Button("T5");
                    btnTalento5.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnTalento5.setPrefSize(90, 70);
                    btnTalento5.setLayoutX(480);
                    btnTalento5.setLayoutY(700);
                    btnTalento5.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/SELECCION", lblMensaje));
                    Button btnGestionIT = new Button("Gestión de IT");
                    btnGestionIT.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnGestionIT.setPrefSize(60, 70);
                    btnGestionIT.setLayoutX(1140);
                    btnGestionIT.setLayoutY(700);
                    btnGestionIT.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/GESTION IT", lblMensaje));
                    Button btnDireccionEstrategica = new Button("DIRECCION ESTRATEGICA");
                    btnDireccionEstrategica.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnDireccionEstrategica.setPrefSize(100, 75);
                    btnDireccionEstrategica.setLayoutX(300);
                    btnDireccionEstrategica.setLayoutY(190);
                    btnDireccionEstrategica.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/DIRECCION ESTRATEGICA", lblMensaje));
                    Button btnRequisitosLegales = new Button("REQUISITOS LEGALES");
                    btnRequisitosLegales.setStyle("-fx-background-color: linear-gradient(to bottom, #ffb347, #ffcc33); -fx-text-fill: #2c3e50; -fx-border-color: #f39c12;" + botonMapaBase);
                    btnRequisitosLegales.setPrefSize(90, 75);
                    btnRequisitosLegales.setLayoutX(425);
                    btnRequisitosLegales.setLayoutY(190);
                    btnRequisitosLegales.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/REQUISITOS LEGALES", lblMensaje));
                    Button btnFirmaContrato = new Button("FIRMA CONTRATO");
                    btnFirmaContrato.setStyle("-fx-background-color: linear-gradient(to bottom, #00c6ff, #0072ff); -fx-text-fill: white; -fx-border-color: #0072ff;" + botonMapaBase);
                    btnFirmaContrato.setPrefSize(82, 75);
                    btnFirmaContrato.setLayoutX(558);
                    btnFirmaContrato.setLayoutY(190);
                    btnFirmaContrato.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/FIRMA CONTRATO", lblMensaje));
                    Button btnNecesidadesPartes = new Button("NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS");
                    btnNecesidadesPartes.setStyle("-fx-background-color: linear-gradient(to bottom, #43cea2, #185a9d); -fx-text-fill: white; -fx-border-color: #185a9d;" + botonMapaBase);
                    btnNecesidadesPartes.setPrefSize(100, 140);
                    btnNecesidadesPartes.setLayoutX(17);
                    btnNecesidadesPartes.setLayoutY(400);
                    btnNecesidadesPartes.setOnAction(_ -> abrirCarpeta("C:/Users/santy/OneDrive/Documentos/Carpetas documentos/NECESIDADES Y EXPECTATIVAS DE LAS PARTES INTERESADAS", lblMensaje));

                    Pane overlay = new Pane();
                    overlay.setPickOnBounds(false);
                    overlay.getChildren().addAll(
                        mapaView,
                        btnDireccionEstrategica, btnRequisitosLegales, btnFirmaContrato, btnNecesidadesPartes,
                        btnSistemasGestion,
                        btnGestionComercial, btnAnalisis, btnInduccion, btnOperaciones, btnSupervision, btnSatisfaccion,
                        btnAdmin1, btnAdmin2, btnAdmin3, btnAdmin4,
                        btnTalento1, btnTalento2, btnTalento3, btnTalento4, btnTalento5,
                        btnGestionIT
                    );
                    panelCentral.getChildren().add(overlay);
                    // Mostrar botón lateral para cerrar mapa
                    btnCerrarMapaLateral.setVisible(true);
                    btnCerrarMapaLateral.setManaged(true);
                    btnCerrarMapaLateral.setOnAction(_ -> {
                        panelCentral.getChildren().clear();
                        btnCerrarMapaLateral.setVisible(false);
                        btnCerrarMapaLateral.setManaged(false);
                    });
                } catch (Exception ex) {
                    DialogUtils.mostrarAviso(panelCentral, "No se pudo cargar el mapa de procesos.", false, null);
                }
            } else {
                DialogUtils.mostrarAviso(panelCentral, "Acceso al mapa de procesos restringido.", false, null);
                panelCentral.getChildren().clear();
                btnCerrarMapaLateral.setVisible(false);
                btnCerrarMapaLateral.setManaged(false);
            }
        });
        btnTabla.setOnAction(_ -> {
            if (rol.equals("Administradora")) {
                mostrarVentanaTablaControl();
            } else {
                lblMensaje.setText("Acceso a la tabla restringido.");
            }
        });

        BorderPane root = new BorderPane();
        root.setLeft(vboxMenu);
        root.setCenter(panelCentral);
        root.setTop(topBar);

        Scene scene = new Scene(root);
        stage.setTitle("Panel Principal");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();

        // Al abrir la app, revisar documentos y enviar recordatorio si corresponde
        revisarYEnviarRecordatorios(lblMensaje);
    }

    private Stage mainStage;

    private void mostrarDialogoCrearUsuario(Label lblMensaje) {
        new CrearUsuarioDialog(usuarioService, (Stage) lblMensaje.getScene().getWindow()).mostrar(lblMensaje);
    }

    
    private void abrirCarpeta(String folderPath, Label lblMensaje) {
        try {
            java.awt.Desktop.getDesktop().open(new java.io.File(folderPath));
        } catch (Exception ex) {
            lblMensaje.setText("No se pudo abrir la carpeta de documentos.");
        }
    }

    // Nueva ventana para Tabla de control
    private void mostrarVentanaTablaControl() {
        new TablaControlView(this).mostrar();
    }

    // Mostrar documentos registrados en una tabla
    public void mostrarDocumentosRegistrados() {
        // Modularizado: ahora en TablaControlView
        TablaControlView.mostrarDocumentosRegistrados();
    }

    // Mostrar formulario de registro de documento
    public void mostrarFormularioRegistro() {
        new RegistroDocumentoDialog(mainStage).mostrar();
    }

    // Set the main stage for dialog ownership
    public void setMainStage(Stage stage) {
        this.mainStage = stage;
    }

    private void revisarYEnviarRecordatorios(Label lblMensaje) {
        // Leer documentos.txt y enviar recordatorios en un hilo en segundo plano
        new Thread(() -> {
            boolean huboError = false;
            int lineNumber = 0;
            StringBuilder resultado = new StringBuilder();
            try {
                java.nio.file.Path path = java.nio.file.Paths.get("documentos.txt");
                if (java.nio.file.Files.exists(path)) {
                    java.util.List<String> lines = java.nio.file.Files.readAllLines(path);
                    for (String line : lines) {
                        lineNumber++;
                        String[] partes = line.split(";");
                        if (partes.length >= 7) {
                            String codigo = partes[0];
                            String requisitoLegal = partes[1];
                            String comoSeAplica = partes[2];
                            String porQueLoAplica = partes[3];
                            LocalDate fechaEmision, fechaVencimiento, fechaProximaRenovacion;
                            try {
                                fechaEmision = LocalDate.parse(partes[4]);
                                fechaVencimiento = LocalDate.parse(partes[5]);
                                fechaProximaRenovacion = LocalDate.parse(partes[6]);
                            } catch (Exception ex) {
                                // Saltar línea con fecha inválida y mostrar aviso en consola
                                System.err.println("Línea " + lineNumber + " de documentos.txt ignorada por fecha inválida: " + line);
                                huboError = true;
                                continue;
                            }
                            // Si la fecha próxima de renovación es hoy o ya pasó, enviar recordatorio
                            if (!fechaProximaRenovacion.isAfter(LocalDate.now())) {
                                boolean exito = enviarRecordatorio(codigo, requisitoLegal, comoSeAplica, porQueLoAplica, fechaEmision, fechaVencimiento, fechaProximaRenovacion, lblMensaje);
                                if (!exito) huboError = true;
                            }
                        }
                    }
                    if (!huboError) {
                        resultado.append("Recordatorios enviados correctamente (si había documentos para renovar).");
                    } else {
                        resultado.append("Algunas líneas de documentos.txt fueron ignoradas por formato de fecha inválido.");
                    }
                } else {
                    resultado.append("No hay documentos registrados.");
                }
            } catch (Exception e) {
                resultado.append("Error al revisar documentos: " + e.getMessage());
                e.printStackTrace();
            }
            // Actualizar la UI en el hilo de JavaFX
            javafx.application.Platform.runLater(() -> lblMensaje.setText(resultado.toString()));
        }).start();
    }

    private boolean enviarRecordatorio(String codigo, String requisitoLegal, String comoSeAplica, String porQueLoAplica, LocalDate fechaEmision, LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, Label lblMensaje) {
        // Configuración del correo
        String remitente = "santy.rojas.2005.santylol@gmail.com"; // Cambia por tu correo
        String password = "chru xxhs tbjc udwn"; // Cambia por tu contraseña de aplicación
        String destinatario = "diegopintosegovia@gmail.com"; // Cambia por el destinatario
        String asunto = "Recordatorio de renovación de documento legal";
        String cuerpo = "Recordatorio: El documento con código " + codigo + " y requisito legal '" + requisitoLegal + "' tiene fecha de renovación próxima o vencida."
                + "\nFecha de emisión: " + fechaEmision
                + "\nFecha de vencimiento: " + fechaVencimiento
                + "\nFecha próxima de renovación: " + fechaProximaRenovacion;

        boolean exito = CorreoUtils.enviarRecordatorio(remitente, password, destinatario, asunto, cuerpo);
        if (exito) {
            lblMensaje.setText("Correo enviado correctamente a " + destinatario);
        } else {
            lblMensaje.setText("No se pudo enviar el correo a " + destinatario);
        }
        return exito;
    }
}
