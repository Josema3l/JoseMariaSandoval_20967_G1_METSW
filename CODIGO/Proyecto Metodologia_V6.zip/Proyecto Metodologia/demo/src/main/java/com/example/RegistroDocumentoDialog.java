package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import java.time.LocalDate;

public class RegistroDocumentoDialog {
    private final Stage parentStage;

    public RegistroDocumentoDialog(Stage parentStage) {
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage registroStage = new Stage();
        registroStage.setTitle("Registrar documento legal");
        Label lblMensaje = new Label();
        TextField txtCodigo = new TextField();
        TextField txtRequisitoLegal = new TextField();
        TextField txtComoSeAplica = new TextField();
        TextField txtPorQueLoAplica = new TextField();
        DatePicker dtpFechaEmision = new DatePicker();
        DatePicker dtpFechaVencimiento = new DatePicker();
        DatePicker dtpFechaProximaRenovacion = new DatePicker();

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Código nro:"), 0, 0);
        grid.add(txtCodigo, 1, 0);
        grid.add(new Label("Requisito Legal:"), 0, 1);
        grid.add(txtRequisitoLegal, 1, 1);
        grid.add(new Label("Cómo se aplica:"), 0, 2);
        grid.add(txtComoSeAplica, 1, 2);
        grid.add(new Label("Por qué lo aplica:"), 0, 3);
        grid.add(txtPorQueLoAplica, 1, 3);
        grid.add(new Label("Fecha de emisión:"), 0, 4);
        grid.add(dtpFechaEmision, 1, 4);
        grid.add(new Label("Fecha de vencimiento:"), 0, 5);
        grid.add(dtpFechaVencimiento, 1, 5);
        grid.add(new Label("Fecha próxima de renovación:"), 0, 6);
        grid.add(dtpFechaProximaRenovacion, 1, 6);
        grid.add(lblMensaje, 0, 7, 2, 1);

        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(_ -> {
            String codigo = txtCodigo.getText();
            String requisitoLegal = txtRequisitoLegal.getText();
            String comoSeAplica = txtComoSeAplica.getText();
            String porQueLoAplica = txtPorQueLoAplica.getText();
            LocalDate fechaEmision = dtpFechaEmision.getValue();
            LocalDate fechaVencimiento = dtpFechaVencimiento.getValue();
            LocalDate fechaProximaRenovacion = dtpFechaProximaRenovacion.getValue();
            if (codigo.isEmpty() || requisitoLegal.isEmpty() || comoSeAplica.isEmpty() || porQueLoAplica.isEmpty() || fechaEmision == null || fechaVencimiento == null || fechaProximaRenovacion == null) {
                DialogUtils.mostrarAviso(grid, "Por favor, complete todos los campos.", false, null);
                return;
            }
            if (fechaVencimiento.isBefore(fechaEmision) || fechaProximaRenovacion.isBefore(fechaEmision)) {
                DialogUtils.mostrarAviso(grid, "La fecha de vencimiento y la fecha próxima de renovación no pueden ser anteriores a la fecha de emisión.", false, null);
                return;
            }
            try {
                java.nio.file.Path path = java.nio.file.Paths.get("documentos.txt");
                String linea = String.join(";", codigo, requisitoLegal, comoSeAplica, porQueLoAplica, fechaEmision.toString(), fechaVencimiento.toString(), fechaProximaRenovacion.toString());
                java.nio.file.Files.write(path, java.util.Collections.singleton(linea), java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
                DialogUtils.mostrarAviso(grid, "Documento registrado exitosamente.", true, () -> {
                    txtCodigo.clear();
                    txtRequisitoLegal.clear();
                    txtComoSeAplica.clear();
                    txtPorQueLoAplica.clear();
                    dtpFechaEmision.setValue(null);
                    dtpFechaVencimiento.setValue(null);
                    dtpFechaProximaRenovacion.setValue(null);
                });
            } catch (Exception ex) {
                DialogUtils.mostrarAviso(grid, "Error al guardar el documento.", false, null);
                ex.printStackTrace();
            }
        });

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(e -> registroStage.close());
        HBox hboxBotones = new HBox(10, btnGuardar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        grid.add(hboxBotones, 0, 8, 2, 1);

        Scene scene = new Scene(grid, 600, 400);
        registroStage.setScene(scene);
        registroStage.initOwner(parentStage);
        registroStage.show();
    }
}
