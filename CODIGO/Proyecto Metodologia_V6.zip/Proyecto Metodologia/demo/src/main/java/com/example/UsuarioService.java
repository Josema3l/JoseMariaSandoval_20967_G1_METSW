package com.example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

public class UsuarioService {
    /**
     * Devuelve una lista de todos los nombres de usuario registrados.
     */
    public java.util.List<String> getTodosLosUsuarios() {
        return new java.util.ArrayList<>(usuarios.keySet());
    }
    /**
     * Verifica si el usuario y contraseña coinciden con un usuario registrado.
     * @param usuario Nombre de usuario a verificar
     * @param contrasena Contraseña a verificar
     * @return true si las credenciales son correctas, false en caso contrario
     */
    public boolean verificarCredenciales(String usuario, String contrasena) {
        return usuarios.containsKey(usuario) && usuarios.get(usuario)[0].equals(contrasena);
    }
    private Map<String, String[]> usuarios = new HashMap<>();
    private static final String USUARIOS_FILE = "usuarios.txt";

    public UsuarioService() {
        cargarUsuarios();
    }

    private void cargarUsuarios() {
        try {
            File file = new File(USUARIOS_FILE);
            if (!file.exists()) {
                // Si no existe, crear archivo con cabecera y un usuario admin por defecto
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                writer.write("usuario,contraseña,rol\nadmin,admin123,administradora\ncliente,cliente123,cliente");
                writer.close();
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String linea;
            boolean primera = true;
            while ((linea = reader.readLine()) != null) {
                if (primera) { primera = false; continue; }
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    usuarios.put(partes[0], new String[]{partes[1], partes[2]});
                }
            }
            reader.close();
        } catch (Exception e) {
            // Manejar el error apropiadamente (por ejemplo, registrar el error)
        }
    }

    public boolean verificarUsuario(String usuario, String contrasena) {
        return usuarios.containsKey(usuario) && usuarios.get(usuario)[0].equals(contrasena);
    }

    public String getRol(String usuario) {
        return usuarios.get(usuario)[1];
    }

    public void crearUsuario(String usuario, String contrasena, String rol) {
        usuarios.put(usuario, new String[]{contrasena, rol});
        guardarUsuarioEnCSV(usuario, contrasena, rol);
    }

    private void guardarUsuarioEnCSV(String usuario, String contrasena, String rol) {
        try {
            BufferedWriter fw = new BufferedWriter(new FileWriter(USUARIOS_FILE, true));
            fw.write("\n" + usuario + "," + contrasena + "," + rol);
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Permitir acceso a los usuarios para poblar el ComboBox desde LoginController
    public Map<String, String[]> getUsuarios() {
        return usuarios;
    }

    void cambiarCredenciales(String usuarioActual, String nuevoUsuario, String nuevaContrasena) {
        if (usuarios.containsKey(usuarioActual)) {
            String rol = usuarios.get(usuarioActual)[1];
            String usuarioFinal = (nuevoUsuario == null || nuevoUsuario.isEmpty()) ? usuarioActual : nuevoUsuario;
            String contrasenaFinal = (nuevaContrasena == null || nuevaContrasena.isEmpty()) ? usuarios.get(usuarioActual)[0] : nuevaContrasena;
            usuarios.remove(usuarioActual);
            usuarios.put(usuarioFinal, new String[]{contrasenaFinal, rol});
            // Reescribir todo el archivo con los usuarios actualizados
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(USUARIOS_FILE))) {
                writer.write("usuario,contraseña,rol");
                writer.newLine();
                for (Map.Entry<String, String[]> entry : usuarios.entrySet()) {
                    writer.write(entry.getKey() + "," + entry.getValue()[0] + "," + entry.getValue()[1]);
                    writer.newLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
