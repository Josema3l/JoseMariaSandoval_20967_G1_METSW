package com.example;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class DialogUtils {
    /**
     * Muestra un aviso moderno con mensaje y botón de cerrar. Ejecuta onSuccess.run() si es éxito.
     * @param owner Nodo padre para centrar el diálogo
     * @param mensaje Mensaje a mostrar
     * @param esExito Si es true, cierra el formulario al cerrar el aviso
     * @param onSuccess Acción a ejecutar si es éxito (puede ser null)
     */
    public static void mostrarAviso(Node owner, String mensaje, boolean esExito, Runnable onSuccess) {
        javafx.stage.Stage avisoStage = new javafx.stage.Stage();
        avisoStage.setTitle(esExito ? "Éxito" : "Aviso");
        Label lbl = new Label(mensaje);
        lbl.setStyle("-fx-font-size: 16px; -fx-text-fill: " + (esExito ? "#27ae60" : "#e74c3c") + "; -fx-font-weight: bold;");
        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8;");
        btnCerrar.setDefaultButton(true);
        VBox vbox = new VBox(20, lbl, btnCerrar);
        vbox.setAlignment(Pos.CENTER);
        javafx.scene.Scene scene = new javafx.scene.Scene(vbox, 400, 140);
        avisoStage.setScene(scene);
        avisoStage.setResizable(false);
        avisoStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
        if (owner != null && owner.getScene() != null && owner.getScene().getWindow() != null) {
            avisoStage.initOwner(owner.getScene().getWindow());
        }
        // Permitir cerrar con ESC
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                avisoStage.close();
            }
        });
        btnCerrar.setOnAction(e -> {
            avisoStage.close();
            if (onSuccess != null) {
                javafx.application.Platform.runLater(onSuccess);
            }
        });
        avisoStage.showAndWait();
    }
}
