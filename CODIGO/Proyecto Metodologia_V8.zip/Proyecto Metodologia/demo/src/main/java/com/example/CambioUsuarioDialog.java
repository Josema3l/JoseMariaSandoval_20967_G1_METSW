package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CambioUsuarioDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioUsuarioDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar nombre de usuario");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);
        
        Label titulo = new Label("Cambiar nombre de usuario");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");
        
        // Combo box para selección de usuario
        Label lblUsuarioActual = new Label(rol.equalsIgnoreCase("Cliente") ? "Su usuario:" : "Usuario a modificar:");
        ComboBox<String> comboUsuarioActual = new ComboBox<>();
        comboUsuarioActual.setPrefWidth(220);
        comboUsuarioActual.setStyle("-fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 6 10 6 10;");

        // Campos para el nuevo nombre de usuario
        Label lblNuevoUsuario = new Label("Nuevo nombre de usuario:");
        TextField txtNuevoUsuario = new TextField();
        txtNuevoUsuario.setPrefWidth(220);
        
        // Campo para contraseña actual (requerido para validación)
        Label lblContrasenaActual = new Label("Contraseña actual:");
        PasswordField txtContrasenaActual = new PasswordField();
        txtContrasenaActual.setPrefWidth(220);

        // Configurar combo box según el rol
        if (rol.equalsIgnoreCase("Tester")) {
            comboUsuarioActual.getItems().addAll(usuarioService.getTodosLosUsuarios());
            comboUsuarioActual.setPromptText("Seleccione usuario");
        } else {
            comboUsuarioActual.getItems().add(usuario);
            comboUsuarioActual.setValue(usuario);
            comboUsuarioActual.setDisable(true);
        }

        // Organización de los campos
        VBox campos = new VBox(10);
        campos.getChildren().addAll(
            lblUsuarioActual, comboUsuarioActual,
            lblNuevoUsuario, txtNuevoUsuario,
            lblContrasenaActual, txtContrasenaActual
        );
        
        formBox.getChildren().addAll(titulo, campos);

        // Botones de acción
        Button btnCambiar = new Button("Cambiar");
        btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setOnAction(e -> stageCambio.close());
        
        HBox hboxBotones = new HBox(16, btnCambiar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        // Configuración de la escena
        Scene scene = new Scene(formBox);
        stageCambio.setScene(scene);
        stageCambio.initOwner(parentStage);

        // Manejar tecla ESC para cerrar
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        // Lógica para cambiar el nombre de usuario
        btnCambiar.setOnAction(e -> {
            String usuarioObjetivo = comboUsuarioActual.getValue();
            String nuevoUsuario = txtNuevoUsuario.getText().trim();
            String contrasenaActual = txtContrasenaActual.getText().trim();

            // Validaciones básicas
            if (usuarioObjetivo == null || usuarioObjetivo.isEmpty()) {
                mostrarError("Debe seleccionar un usuario.");
                return;
            }

            if (nuevoUsuario.isEmpty()) {
                mostrarError("Debe especificar un nuevo nombre de usuario.");
                return;
            }

            if (contrasenaActual.isEmpty()) {
                mostrarError("Debe ingresar la contraseña actual.");
                return;
            }

            // Validaciones específicas por rol
            if (!rol.equalsIgnoreCase("Tester")) {
                if (!usuarioObjetivo.equals(usuario)) {
                    mostrarError("No puede modificar otros usuarios.");
                    return;
                }
            }

            // Verificar credenciales
            if (!usuarioService.verificarCredenciales(usuarioObjetivo, contrasenaActual)) {
                mostrarError("Contraseña actual incorrecta.");
                return;
            }

            // Verificar si el nuevo usuario ya existe
            if (usuarioService.getTodosLosUsuarios().contains(nuevoUsuario)) {
                mostrarError("El nombre de usuario ya está en uso.");
                return;
            }

            // Realizar el cambio
            try {
                usuarioService.cambiarCredenciales(
                    usuarioObjetivo,
                    nuevoUsuario,
                    null // No cambiar la contraseña
                );
                
                DialogUtils.mostrarAviso(formBox, "Nombre de usuario cambiado exitosamente.", true, stageCambio::close);
            } catch (Exception ex) {
                mostrarError("Error al cambiar el nombre de usuario: " + ex.getMessage());
            }
        });

        stageCambio.showAndWait();
    }

    private void mostrarError(String mensaje) {
        DialogUtils.mostrarAviso(parentStage.getScene().getRoot(), mensaje, false, null);
    }
}