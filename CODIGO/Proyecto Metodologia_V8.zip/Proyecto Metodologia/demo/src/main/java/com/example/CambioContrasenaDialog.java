package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CambioContrasenaDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioContrasenaDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar contraseña");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);
        Label titulo = new Label("Cambiar contraseña");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");
        Label lblUsuario = new Label("Usuario:");
        ComboBox<String> comboUsuario = new ComboBox<>();
        comboUsuario.setPrefWidth(220);

        if (rol.equalsIgnoreCase("Tester")) {
            for (String u : usuarioService.getTodosLosUsuarios()) {
                comboUsuario.getItems().add(u);
            }
            comboUsuario.setEditable(false);
            comboUsuario.setPromptText("Seleccione usuario");
            comboUsuario.setStyle("-fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 6 10 6 10;");
        } else {
            comboUsuario.getItems().add(usuario);
            comboUsuario.setValue(usuario);
            comboUsuario.setDisable(true);
        }

        Label lblContrasenaActual = new Label("Contraseña actual:");
        PasswordField txtContrasenaActual = new PasswordField();
        txtContrasenaActual.setPrefWidth(220);
        Label lblNuevaContrasena = new Label("Nueva contraseña:");
        PasswordField txtNuevaContrasena = new PasswordField();
        txtNuevaContrasena.setPrefWidth(220);
        Label lblRepetirContrasena = new Label("Repetir nueva contraseña:");
        PasswordField txtRepetirContrasena = new PasswordField();
        txtRepetirContrasena.setPrefWidth(220);

        VBox campos = new VBox(10, lblUsuario, comboUsuario);
        // Ahora siempre se pide la contraseña actual, excepto para Tester cambiando a otros usuarios
        campos.getChildren().addAll(lblContrasenaActual, txtContrasenaActual);
        campos.getChildren().addAll(lblNuevaContrasena, txtNuevaContrasena, lblRepetirContrasena, txtRepetirContrasena);
        formBox.getChildren().addAll(titulo, campos);

        Button btnCambiar = new Button("Cambiar");
        btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setDefaultButton(false);
        btnCancelar.setCancelButton(true);
        btnCancelar.setOnAction(e -> stageCambio.close());
        HBox hboxBotones = new HBox(16, btnCambiar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        Scene scene = new Scene(formBox);
        stageCambio.setScene(scene);

        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        btnCambiar.setOnAction(e -> {
            boolean exito = false;
            String usuarioObjetivo = comboUsuario.getValue();
            String contrasenaActual = txtContrasenaActual.getText();
            String nuevaContrasena = txtNuevaContrasena.getText();
            String repetirContrasena = txtRepetirContrasena.getText();
            if (usuarioObjetivo == null || usuarioObjetivo.isEmpty() || contrasenaActual == null || contrasenaActual.isEmpty() || nuevaContrasena == null || nuevaContrasena.isEmpty() || repetirContrasena == null || repetirContrasena.isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "Debe completar todos los campos.", false, () -> {});
                return;
            }
            // Solo el Tester puede cambiar la contraseña de otros usuarios, pero debe ingresar la contraseña actual del usuario objetivo
            if (!usuarioService.verificarCredenciales(usuarioObjetivo, contrasenaActual)) {
                DialogUtils.mostrarAviso(formBox, "Contraseña actual incorrecta.", false, () -> {});
                return;
            }
            if (!nuevaContrasena.equals(repetirContrasena)) {
                DialogUtils.mostrarAviso(formBox, "Las nuevas contraseñas no coinciden.", false, () -> {});
                return;
            }
            if (nuevaContrasena.equals(contrasenaActual)) {
                DialogUtils.mostrarAviso(formBox, "La nueva contraseña no puede ser igual a la actual.", false, () -> {});
                return;
            }
            usuarioService.cambiarCredenciales(usuarioObjetivo, null, nuevaContrasena);
            exito = true;
            if (exito) {
                DialogUtils.mostrarAviso(formBox, "Contraseña cambiada exitosamente.", true, () -> stageCambio.close());
            } else {
                DialogUtils.mostrarAviso(formBox, "No se pudo cambiar la contraseña.", false, () -> {});
            }
        });

        stageCambio.initOwner(parentStage);
        stageCambio.showAndWait();
    }
}
