package com.example;

import java.awt.Desktop;
import java.io.File;
import java.util.List;

import org.bson.Document; 
import org.bson.types.ObjectId;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ArchivoManagerDialog {
    private final Stage parentStage;
    private final DocumentoService documentoService;
    private final String codigoDocumento;

    public ArchivoManagerDialog(Stage parentStage, String codigoDocumento) {
        this.parentStage = parentStage;
        this.documentoService = new DocumentoService();
        this.codigoDocumento = codigoDocumento;
    }

    public void mostrar() {
        Stage archivoStage = new Stage();
        archivoStage.setTitle("Gestionar Archivos - " + codigoDocumento);

        // Obtener información del documento
        Document documento = documentoService.buscarDocumento(codigoDocumento);
        if (documento == null) {
            DialogUtils.mostrarAviso(null, "Documento no encontrado.", false, null);
            return;
        }

        // Lista de archivos
        ListView<String> listViewArchivos = new ListView<>();
        listViewArchivos.setPrefHeight(200);
        actualizarListaArchivos(listViewArchivos, documento);

        // Botones
        Button btnAgregar = new Button("Agregar archivo");
        btnAgregar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white;");
        btnAgregar.setOnAction(e -> agregarArchivo(listViewArchivos));

        Button btnDescargar = new Button("Descargar");
        btnDescargar.setOnAction(e -> descargarArchivo(listViewArchivos, documento));

        Button btnVerificar = new Button("Verificar");
        btnVerificar.setOnAction(e -> verificarArchivo(listViewArchivos, documento));

        Button btnEliminar = new Button("Eliminar");
        btnEliminar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        btnEliminar.setOnAction(e -> eliminarArchivo(listViewArchivos, documento));

        Button btnActualizar = new Button("Actualizar lista");
        btnActualizar.setOnAction(e -> {
            Document docActualizado = documentoService.buscarDocumento(codigoDocumento);
            if (docActualizado != null) {
                actualizarListaArchivos(listViewArchivos, docActualizado);
            }
        });

        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setOnAction(e -> archivoStage.close());

        // Layout
        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(
            new Label("Archivos adjuntos:"),
            listViewArchivos,
            new HBox(10, btnAgregar, btnDescargar, btnVerificar),
            new HBox(10, btnEliminar, btnActualizar, btnCerrar)
        );

        Scene scene = new Scene(layout, 500, 350);
        archivoStage.setScene(scene);
        archivoStage.initOwner(parentStage);
        archivoStage.show();

        archivoStage.setOnCloseRequest(e -> documentoService.cerrarConexion());
    }

    private void agregarArchivo(ListView<String> listView) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivo");
        
        // Configurar filtros de archivos
        fileChooser.getExtensionFilters().addAll(
        new FileChooser.ExtensionFilter("Todos los archivos", "*.*"),
        new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
        new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
        new FileChooser.ExtensionFilter("Documentos Excel", "*.xls", "*.xlsx"),
        new FileChooser.ExtensionFilter("Imágenes", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp"),
        new FileChooser.ExtensionFilter("Archivos de texto", "*.txt", "*.rtf")
    );
        
        File archivoSeleccionado = fileChooser.showOpenDialog(parentStage);
        if (archivoSeleccionado != null) {
            // Verificar tamaño del archivo (límite de 50MB)
            if (archivoSeleccionado.length() > 50 * 1024 * 1024) {
                DialogUtils.mostrarAviso(null, "El archivo es demasiado grande. El tamaño máximo permitido es 50MB.", false, null);
                return;
            }
            
            if (documentoService.agregarArchivoADocumento(codigoDocumento, archivoSeleccionado)) {
                // Actualizar la lista
                Document docActualizado = documentoService.buscarDocumento(codigoDocumento);
                if (docActualizado != null) {
                    actualizarListaArchivos(listView, docActualizado);
                }
                DialogUtils.mostrarAviso(null, "Archivo agregado exitosamente.", true, null);
            } else {
                DialogUtils.mostrarAviso(null, "Error al agregar el archivo.", false, null);
            }
        }
    }

    private void actualizarListaArchivos(ListView<String> listView, Document documento) {
        listView.getItems().clear();
        
        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null) {
            for (Document archivo : archivos) {
                String nombre = archivo.getString("nombreOriginal");
                Long tamaño = archivo.getLong("tamaño");
                String info = nombre + " (" + formatFileSize(tamaño) + ")";
                listView.getItems().add(info);
            }
        }
    }

    private void descargarArchivo(ListView<String> listView, Document documento) {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.mostrarAviso(null, "Selecciona un archivo para descargar.", false, null);
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            ObjectId archivoId = archivo.getObjectId("archivoId");
            String nombreOriginal = archivo.getString("nombreOriginal");

            // Seleccionar carpeta de destino
            DirectoryChooser directoryChooser = new DirectoryChooser();
            directoryChooser.setTitle("Seleccionar carpeta de destino");
            File carpetaDestino = directoryChooser.showDialog(parentStage);

            if (carpetaDestino != null) {
                String rutaDestino = carpetaDestino.getAbsolutePath() + File.separator + nombreOriginal;
                
                if (documentoService.descargarArchivo(archivoId, rutaDestino)) {
                    DialogUtils.mostrarAviso(null, "Archivo descargado exitosamente en:\n" + rutaDestino, true, null);
                } else {
                    DialogUtils.mostrarAviso(null, "Error al descargar el archivo.", false, null);
                }
            }
        }
    }

    private void verificarArchivo(ListView<String> listView, Document documento) {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.mostrarAviso(null, "Selecciona un archivo para verificar.", false, null);
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            String nombre = archivo.getString("nombreOriginal");
            Long tamaño = archivo.getLong("tamaño");
            Object fechaSubida = archivo.get("fechaSubida");

            String info = String.format(
                "Archivo: %s\nTamaño: %s\nFecha de subida: %s\nID: %s",
                nombre,
                formatFileSize(tamaño),
                fechaSubida.toString(),
                archivo.getObjectId("archivoId").toString()
            );

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información del archivo");
            alert.setHeaderText(null);
            alert.setContentText(info);
            alert.showAndWait();
        }
    }

    private void eliminarArchivo(ListView<String> listView, Document documento) {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.mostrarAviso(null, "Selecciona un archivo para eliminar.", false, null);
            return;
        }

        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Confirmar eliminación");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText("¿Estás seguro de que deseas eliminar este archivo?");

        if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            @SuppressWarnings("unchecked")
            List<Document> archivos = (List<Document>) documento.get("archivos");
            
            if (archivos != null && selectedIndex < archivos.size()) {
                Document archivo = archivos.get(selectedIndex);
                ObjectId archivoId = archivo.getObjectId("archivoId");

                if (documentoService.eliminarArchivo(archivoId)) {
                    // Actualizar la lista de archivos en memoria
                    archivos.remove(selectedIndex);
                    
                    // Actualizar el documento en la base de datos
                    if (documentoService.actualizarArchivosDocumento(codigoDocumento, archivos)) {
                        // Actualizar la vista
                        listView.getItems().remove(selectedIndex);
                        DialogUtils.mostrarAviso(null, "Archivo eliminado exitosamente.", true, null);
                    } else {
                        DialogUtils.mostrarAviso(null, "Error al actualizar la lista de archivos en la base de datos.", false, null);
                    }
                } else {
                    DialogUtils.mostrarAviso(null, "Error al eliminar el archivo del sistema de archivos.", false, null);
                }
            }
        }
    }

    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024.0));
        return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
    }

    // Método opcional para abrir archivo con aplicación predeterminada
    private void abrirArchivo(ListView<String> listView, Document documento) {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex < 0) {
            DialogUtils.mostrarAviso(null, "Selecciona un archivo para abrir.", false, null);
            return;
        }

        @SuppressWarnings("unchecked")
        List<Document> archivos = (List<Document>) documento.get("archivos");
        
        if (archivos != null && selectedIndex < archivos.size()) {
            Document archivo = archivos.get(selectedIndex);
            ObjectId archivoId = archivo.getObjectId("archivoId");
            String nombreOriginal = archivo.getString("nombreOriginal");

            // Crear archivo temporal
            try {
                File archivoTemp = File.createTempFile("temp_", "_" + nombreOriginal);
                archivoTemp.deleteOnExit();
                
                if (documentoService.descargarArchivo(archivoId, archivoTemp.getAbsolutePath())) {
                    // Abrir con aplicación predeterminada
                    if (Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().open(archivoTemp);
                    } else {
                        DialogUtils.mostrarAviso(null, "No se puede abrir el archivo automáticamente.", false, null);
                    }
                } else {
                    DialogUtils.mostrarAviso(null, "Error al descargar el archivo temporal.", false, null);
                }
            } catch (Exception e) {
                DialogUtils.mostrarAviso(null, "Error al abrir el archivo: " + e.getMessage(), false, null);
                e.printStackTrace();
            }
        }
    }
}