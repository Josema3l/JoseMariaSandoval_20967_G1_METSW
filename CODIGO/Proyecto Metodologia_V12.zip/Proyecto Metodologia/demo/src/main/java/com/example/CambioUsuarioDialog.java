package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CambioUsuarioDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioUsuarioDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar nombre de usuario");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);
        
        Label titulo = new Label("Cambiar nombre de usuario");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");
        
        // Determinar si el usuario actual tiene privilegios administrativos
        boolean esPrivilegiado = rol.equalsIgnoreCase("Tester") || rol.equalsIgnoreCase("Administradora");
        
        // Combo box para selección de usuario
        Label lblUsuarioActual = new Label(esPrivilegiado ? "Usuario a modificar:" : "Su usuario:");
        ComboBox<String> comboUsuarioActual = new ComboBox<>();
        comboUsuarioActual.setPrefWidth(220);
        comboUsuarioActual.setStyle("-fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 6 10 6 10;");

        // Campos para el nuevo nombre de usuario
        Label lblNuevoUsuario = new Label("Nuevo nombre de usuario:");
        TextField txtNuevoUsuario = new TextField();
        txtNuevoUsuario.setPrefWidth(220);
        
        // Campo para contraseña actual
        Label lblContrasenaActual = new Label("Contraseña actual:");
        PasswordField txtContrasenaActual = new PasswordField();
        txtContrasenaActual.setPrefWidth(220);

        // Configurar combo box según el rol
        if (esPrivilegiado) {
            comboUsuarioActual.getItems().addAll(usuarioService.getTodosLosUsuarios());
            comboUsuarioActual.setPromptText("Seleccione usuario");
        } else {
            comboUsuarioActual.getItems().add(usuario);
            comboUsuarioActual.setValue(usuario);
            comboUsuarioActual.setDisable(true);
        }

        // CheckBox para cambio administrativo (solo para usuarios privilegiados)
        CheckBox chkCambioAdministrativo = null;
        if (esPrivilegiado) {
            chkCambioAdministrativo = new CheckBox("Cambio administrativo (sin verificar contraseña actual)");
            chkCambioAdministrativo.setStyle("-fx-text-fill: #2c3e50; -fx-font-size: 12px;");
            
            // Listener para habilitar/deshabilitar campo de contraseña
            final CheckBox finalChk = chkCambioAdministrativo;
            chkCambioAdministrativo.setOnAction(e -> {
                txtContrasenaActual.setDisable(finalChk.isSelected());
                lblContrasenaActual.setDisable(finalChk.isSelected());
                if (finalChk.isSelected()) {
                    txtContrasenaActual.clear();
                }
            });
        }

        // Organización de los campos
        VBox campos = new VBox(10);
        campos.getChildren().addAll(lblUsuarioActual, comboUsuarioActual);
        
        if (chkCambioAdministrativo != null) {
            campos.getChildren().add(chkCambioAdministrativo);
        }
        
        campos.getChildren().addAll(
            lblNuevoUsuario, txtNuevoUsuario,
            lblContrasenaActual, txtContrasenaActual
        );
        
        formBox.getChildren().addAll(titulo, campos);

        // Botones de acción
        Button btnCambiar = new Button("Cambiar");
        btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setOnAction(e -> stageCambio.close());
        
        HBox hboxBotones = new HBox(16, btnCambiar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        // Configuración de la escena
        Scene scene = new Scene(formBox);
        stageCambio.setScene(scene);
        stageCambio.initOwner(parentStage);

        // Manejar tecla ESC para cerrar
        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        // Referencia final para usar en el lambda
        final CheckBox finalChkCambioAdministrativo = chkCambioAdministrativo;

        // Lógica para cambiar el nombre de usuario
        btnCambiar.setOnAction(e -> {
            String usuarioObjetivo = comboUsuarioActual.getValue();
            String nuevoUsuario = txtNuevoUsuario.getText().trim();
            String contrasenaActual = txtContrasenaActual.getText().trim();

            // Validaciones básicas
            if (usuarioObjetivo == null || usuarioObjetivo.isEmpty()) {
                mostrarError(formBox, "Debe seleccionar un usuario.");
                return;
            }

            if (nuevoUsuario.isEmpty()) {
                mostrarError(formBox, "Debe especificar un nuevo nombre de usuario.");
                return;
            }

            // Verificar si el nuevo usuario ya existe
            if (usuarioService.getTodosLosUsuarios().contains(nuevoUsuario)) {
                mostrarError(formBox, "El nombre de usuario ya está en uso.");
                return;
            }

            // Verificar si es el mismo nombre
            if (usuarioObjetivo.equals(nuevoUsuario)) {
                mostrarError(formBox, "El nuevo nombre debe ser diferente al actual.");
                return;
            }

            // Determinar si es un cambio administrativo
            boolean esCambioAdministrativo = esPrivilegiado && 
                                           finalChkCambioAdministrativo != null && 
                                           finalChkCambioAdministrativo.isSelected();

            // Verificación de contraseña según el tipo de cambio
            if (!esCambioAdministrativo) {
                if (contrasenaActual.isEmpty()) {
                    mostrarError(formBox, "Debe ingresar la contraseña actual.");
                    return;
                }

                // Para usuarios privilegiados, verificar la contraseña del usuario objetivo
                String usuarioParaVerificar = esPrivilegiado ? usuarioObjetivo : usuario;
                if (!usuarioService.verificarCredenciales(usuarioParaVerificar, contrasenaActual)) {
                    mostrarError(formBox, "Contraseña actual incorrecta.");
                    return;
                }
            }

            // Realizar el cambio
            try {
                usuarioService.cambiarCredenciales(
                    usuarioObjetivo,
                    nuevoUsuario,
                    null // No cambiar la contraseña
                );
                
                String mensaje = esCambioAdministrativo ? 
                    "Nombre de usuario cambiado exitosamente (cambio administrativo)." : 
                    "Nombre de usuario cambiado exitosamente.";
                
                DialogUtils.mostrarAviso(formBox, mensaje, true, stageCambio::close);
            } catch (Exception ex) {
                mostrarError(formBox, "Error al cambiar el nombre de usuario: " + ex.getMessage());
            }
        });

        stageCambio.showAndWait();
    }

    private void mostrarError(VBox parent, String mensaje) {
        DialogUtils.mostrarAviso(parent, mensaje, false, null);
    }
}