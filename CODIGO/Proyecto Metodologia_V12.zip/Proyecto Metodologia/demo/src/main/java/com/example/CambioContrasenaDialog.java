package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CambioContrasenaDialog {
    private final UsuarioService usuarioService;
    private final String usuario;
    private final String rol;
    private final Stage parentStage;

    public CambioContrasenaDialog(UsuarioService usuarioService, String usuario, String rol, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.usuario = usuario;
        this.rol = rol;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stageCambio = new Stage();
        stageCambio.setTitle("Cambiar contraseña");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);
        
        Label titulo = new Label("Cambiar contraseña");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");
        
        Label lblUsuario = new Label("Usuario:");
        ComboBox<String> comboUsuario = new ComboBox<>();
        comboUsuario.setPrefWidth(220);

        // Configuración según el rol
        boolean esPrivilegiado = rol.equalsIgnoreCase("Tester") || rol.equalsIgnoreCase("Administradora");
        
        if (esPrivilegiado) {
            for (String u : usuarioService.getTodosLosUsuarios()) {
                comboUsuario.getItems().add(u);
            }
            comboUsuario.setEditable(false);
            comboUsuario.setPromptText("Seleccione usuario");
            comboUsuario.setStyle("-fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 6 10 6 10;");
        } else {
            comboUsuario.getItems().add(usuario);
            comboUsuario.setValue(usuario);
            comboUsuario.setDisable(true);
        }

        // Campos de contraseña
        Label lblContrasenaActual = new Label("Contraseña actual:");
        PasswordField txtContrasenaActual = new PasswordField();
        txtContrasenaActual.setPrefWidth(220);
        
        Label lblNuevaContrasena = new Label("Nueva contraseña:");
        PasswordField txtNuevaContrasena = new PasswordField();
        txtNuevaContrasena.setPrefWidth(220);
        
        Label lblRepetirContrasena = new Label("Repetir nueva contraseña:");
        PasswordField txtRepetirContrasena = new PasswordField();
        txtRepetirContrasena.setPrefWidth(220);

        VBox campos = new VBox(10, lblUsuario, comboUsuario);
        
        // Para usuarios privilegiados, mostrar opción de cambiar sin contraseña actual
        CheckBox chkCambioAdministrativo = null;
        if (esPrivilegiado) {
            chkCambioAdministrativo = new CheckBox("Cambio administrativo (sin verificar contraseña actual)");
            chkCambioAdministrativo.setStyle("-fx-text-fill: #2c3e50; -fx-font-size: 12px;");
            campos.getChildren().add(chkCambioAdministrativo);
            
            // Listener para habilitar/deshabilitar campo de contraseña actual
            final CheckBox finalChk = chkCambioAdministrativo;
            chkCambioAdministrativo.setOnAction(e -> {
                txtContrasenaActual.setDisable(finalChk.isSelected());
                lblContrasenaActual.setDisable(finalChk.isSelected());
                if (finalChk.isSelected()) {
                    txtContrasenaActual.clear();
                }
            });
        }
        
        campos.getChildren().addAll(lblContrasenaActual, txtContrasenaActual);
        campos.getChildren().addAll(lblNuevaContrasena, txtNuevaContrasena, lblRepetirContrasena, txtRepetirContrasena);
        formBox.getChildren().addAll(titulo, campos);

        // Botones
        Button btnCambiar = new Button("Cambiar");
        btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setOnAction(e -> stageCambio.close());
        
        HBox hboxBotones = new HBox(16, btnCambiar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        Scene scene = new Scene(formBox);
        stageCambio.setScene(scene);

        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stageCambio.close();
            }
        });

        final CheckBox finalChkCambioAdministrativo = chkCambioAdministrativo;
        
        btnCambiar.setOnAction(e -> {
            String usuarioObjetivo = comboUsuario.getValue();
            String contrasenaActual = txtContrasenaActual.getText();
            String nuevaContrasena = txtNuevaContrasena.getText();
            String repetirContrasena = txtRepetirContrasena.getText();
            
            // Validaciones básicas
            if (usuarioObjetivo == null || usuarioObjetivo.isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "Debe seleccionar un usuario.", false, () -> {});
                return;
            }
            
            if (nuevaContrasena == null || nuevaContrasena.isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "Debe ingresar la nueva contraseña.", false, () -> {});
                return;
            }
            
            if (repetirContrasena == null || repetirContrasena.isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "Debe repetir la nueva contraseña.", false, () -> {});
                return;
            }

            // Verificar que las nuevas contraseñas coincidan
            if (!nuevaContrasena.equals(repetirContrasena)) {
                DialogUtils.mostrarAviso(formBox, "Las nuevas contraseñas no coinciden.", false, () -> {});
                return;
            }

            // Verificación de contraseña actual según el tipo de cambio
            boolean esCambioAdministrativo = esPrivilegiado && finalChkCambioAdministrativo != null && finalChkCambioAdministrativo.isSelected();
            
            if (!esCambioAdministrativo) {
                // Verificación normal de contraseña
                if (contrasenaActual == null || contrasenaActual.isEmpty()) {
                    DialogUtils.mostrarAviso(formBox, "Debe ingresar la contraseña actual.", false, () -> {});
                    return;
                }
                
                // Para usuarios privilegiados cambiando otros usuarios, verificar la contraseña del usuario objetivo
                String usuarioParaVerificar = esPrivilegiado ? usuarioObjetivo : usuario;
                if (!usuarioService.verificarCredenciales(usuarioParaVerificar, contrasenaActual)) {
                    DialogUtils.mostrarAviso(formBox, "Contraseña actual incorrecta.", false, () -> {});
                    return;
                }
                
                // Verificar que la nueva contraseña sea diferente
                if (nuevaContrasena.equals(contrasenaActual)) {
                    DialogUtils.mostrarAviso(formBox, "La nueva contraseña no puede ser igual a la actual.", false, () -> {});
                    return;
                }
            }

            try {
                usuarioService.cambiarCredenciales(usuarioObjetivo, null, nuevaContrasena);
                String mensaje = esCambioAdministrativo ? 
                    "Contraseña cambiada exitosamente (cambio administrativo)." : 
                    "Contraseña cambiada exitosamente.";
                DialogUtils.mostrarAviso(formBox, mensaje, true, () -> stageCambio.close());
            } catch (Exception ex) {
                DialogUtils.mostrarAviso(formBox, "Error al cambiar la contraseña: " + ex.getMessage(), false, () -> {});
            }
        });

        stageCambio.initOwner(parentStage);
        stageCambio.showAndWait();
    }
}