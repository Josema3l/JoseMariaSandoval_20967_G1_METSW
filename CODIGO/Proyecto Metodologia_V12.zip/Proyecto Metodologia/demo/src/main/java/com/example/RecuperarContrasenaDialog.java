package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.security.SecureRandom;

public class RecuperarContrasenaDialog {
    private final UsuarioService usuarioService;
    private final Stage parentStage;

    public RecuperarContrasenaDialog(UsuarioService usuarioService, Stage parentStage) {
        this.usuarioService = usuarioService;
        this.parentStage = parentStage;
    }

    public void mostrar() {
        Stage stage = new Stage();
        stage.setTitle("Recuperar contraseña");
        VBox formBox = new VBox(18);
        formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 30 30 20 30; -fx-border-radius: 12; -fx-background-radius: 12;");
        formBox.setAlignment(Pos.CENTER);

        Label titulo = new Label("Recuperar contraseña");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 0 0 10 0;");

        Label instruccion = new Label("Ingrese su nombre de usuario o correo electrónico:");
        instruccion.setStyle("-fx-font-size: 14px; -fx-text-fill: #34495e; -fx-text-alignment: center;");
        instruccion.setWrapText(true);

        TextField txtIdentificador = new TextField();
        txtIdentificador.setPrefWidth(250);
        txtIdentificador.setPromptText("Usuario o correo electrónico");

        VBox campos = new VBox(10, instruccion, txtIdentificador);
        campos.setAlignment(Pos.CENTER);
        formBox.getChildren().addAll(titulo, campos);

        Button btnEnviar = new Button("Enviar nueva contraseña");
        btnEnviar.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 15px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");
        btnCancelar.setOnAction(e -> stage.close());

        HBox hboxBotones = new HBox(16, btnEnviar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        formBox.getChildren().add(hboxBotones);

        Scene scene = new Scene(formBox);
        stage.setScene(scene);

        scene.setOnKeyPressed(ke -> {
            if (ke.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                stage.close();
            }
        });

        btnEnviar.setOnAction(e -> {
            String identificador = txtIdentificador.getText();
            if (identificador == null || identificador.trim().isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "Debe ingresar un usuario o correo electrónico", false, null);
                return;
            }

            procesarRecuperacion(identificador.trim(), formBox, stage);
        });

        stage.initOwner(parentStage);
        stage.showAndWait();
    }

    private void procesarRecuperacion(String identificador, VBox formBox, Stage stage) {
        try {
            // Buscar usuario por nombre o correo
            String usuario = null;
            String correo = null;

            // Verificar si es un correo electrónico
            if (UsuarioService.esCorreoValido(identificador)) {
                usuario = usuarioService.obtenerUsuarioPorCorreo(identificador);
                correo = identificador;
            } else {
                // Es un nombre de usuario
                if (usuarioService.existeUsuario(identificador)) {
                    usuario = identificador;
                    correo = usuarioService.getCorreo(identificador);
                }
            }

            if (usuario == null) {
                DialogUtils.mostrarAviso(formBox, "Usuario o correo electrónico no encontrado", false, null);
                return;
            }

            if (correo == null || correo.trim().isEmpty()) {
                DialogUtils.mostrarAviso(formBox, "El usuario no tiene un correo electrónico registrado", false, null);
                return;
            }

            // Generar nueva contraseña temporal
            String nuevaContrasena = generarContrasenaTemporal();

            // Actualizar contraseña en la base de datos
            usuarioService.actualizarContrasena(usuario, nuevaContrasena);

            // Usar credenciales del administrador (ya configuradas en el sistema)
            String remitenteAdmin = usuarioService.obtenerCorreoAdministradora();
            String passwordAdmin = "mtxxorlkbnpwjdkt"; // Contraseña de aplicación ya configurada

            if (remitenteAdmin == null) {
                DialogUtils.mostrarAviso(formBox, "Error: No se encontró el correo del administrador", false, null);
                return;
            }

            String asunto = "Recuperación de contraseña - Sistema";
            String cuerpo = String.format(
                "Hola %s,\n\n" +
                "Su nueva contraseña temporal es: %s\n\n" +
                "Por favor, cambie esta contraseña después de iniciar sesión.\n\n" +
                "Saludos,\n" +
                "Equipo del Sistema",
                usuario, nuevaContrasena
            );

            // Enviar correo automáticamente
            boolean enviado = CorreoUtils.enviarRecordatorio(remitenteAdmin, passwordAdmin, correo, asunto, cuerpo);

            if (enviado) {
                DialogUtils.mostrarAviso(formBox, 
                    "Nueva contraseña enviada exitosamente a " + correo + 
                    "\n\nRevise su correo electrónico para obtener la contraseña temporal.", 
                    true, stage::close);
            } else {
                DialogUtils.mostrarAviso(formBox, 
                    "Error al enviar el correo.\n\n" +
                    "Por favor, contacte al administrador para obtener una nueva contraseña.", 
                    false, null);
            }

        } catch (Exception ex) {
            DialogUtils.mostrarAviso(formBox, "Error al procesar la recuperación: " + ex.getMessage(), false, null);
        }
    }

    private String generarContrasenaTemporal() {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        SecureRandom random = new SecureRandom();
        StringBuilder contrasena = new StringBuilder(8);

        for (int i = 0; i < 8; i++) {
            contrasena.append(caracteres.charAt(random.nextInt(caracteres.length())));
        }

        return contrasena.toString();
    }
}
