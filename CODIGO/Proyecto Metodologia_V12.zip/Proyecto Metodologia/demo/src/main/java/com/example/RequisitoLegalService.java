package com.example;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;

public class RequisitoLegalService {
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "sistema_requisitos_legales";
    private static final String COLLECTION_NAME = "requisitos_legales";
    
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;
    private GridFSBucket gridFSBucket;

    public RequisitoLegalService() {
        connect();
    }

    // Convierte un String de fecha a java.sql.Date, o devuelve la cadena "NV" si corresponde.
    private Object parseFechaString(String fecha) {
        if (fecha == null) return null;
        if ("NV".equals(fecha)) return fecha;
        if ("No Vence".equalsIgnoreCase(fecha)) return "NV";
        try {
            return java.sql.Date.valueOf(fecha);
        } catch (Exception e) {
            return null;
        }
    }

    private void connect() {
        try {
            mongoClient = MongoClients.create(CONNECTION_STRING);
            database = mongoClient.getDatabase(DATABASE_NAME);
            collection = database.getCollection(COLLECTION_NAME);
            gridFSBucket = GridFSBuckets.create(database, "requisitos_archivos");
        } catch (Exception e) {
            System.err.println("Error al conectar con MongoDB: " + e.getMessage());
            throw new RuntimeException("No se pudo conectar a la base de datos", e);
        }
    }

    private ObjectId subirArchivo(File archivo) {
        try (FileInputStream streamArchivo = new FileInputStream(archivo)) {
            GridFSUploadOptions options = new GridFSUploadOptions()
                .metadata(new Document("originalName", archivo.getName())
                         .append("contentType", determinarTipoContenido(archivo.getName())));
            
            return gridFSBucket.uploadFromStream(archivo.getName(), streamArchivo, options);
        } catch (IOException e) {
            System.err.println("Error al subir archivo " + archivo.getName() + ": " + e.getMessage());
            return null;
        }
    }

    private String determinarTipoContenido(String nombreArchivo) {
        String extension = nombreArchivo.substring(nombreArchivo.lastIndexOf('.') + 1).toLowerCase();
        switch (extension) {
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "txt": return "text/plain";
            default: return "application/octet-stream";
        }
    }

    public boolean descargarArchivo(ObjectId archivoId, String rutaDestino) {
        try (FileOutputStream streamDestino = new FileOutputStream(rutaDestino)) {
            gridFSBucket.downloadToStream(archivoId, streamDestino);
            return true;
        } catch (IOException e) {
            System.err.println("Error al descargar archivo: " + e.getMessage());
            return false;
        }
    }

    public String guardarRequisitoLegal(String nombreRequisitoLegal, LocalDate fechaEmision, 
                                      LocalDate fechaVencimiento, LocalDate fechaProximaRenovacion, 
                                      List<File> archivos) {
        try {
            Document requisitoLegal = new Document();
            requisitoLegal.append("nombreRequisitoLegal", nombreRequisitoLegal);
            requisitoLegal.append("fechaEmision", fechaEmision != null ? java.sql.Date.valueOf(fechaEmision) : null);

            // Manejo especial para fechas que pueden ser "No Vence"
            if (fechaVencimiento != null) {
                requisitoLegal.append("fechaVencimiento", java.sql.Date.valueOf(fechaVencimiento));
            } else {
                requisitoLegal.append("fechaVencimiento", "NV");
            }

            if (fechaProximaRenovacion != null) {
                requisitoLegal.append("fechaProximaRenovacion", java.sql.Date.valueOf(fechaProximaRenovacion));
            } else {
                requisitoLegal.append("fechaProximaRenovacion", "NV");
            }

            requisitoLegal.append("fechaCreacion", new Date());

            // Subir archivos
            List<ObjectId> archivosIds = new ArrayList<>();
            List<String> nombresArchivos = new ArrayList<>();
            
            for (File archivo : archivos) {
                ObjectId archivoId = subirArchivo(archivo);
                if (archivoId != null) {
                    archivosIds.add(archivoId);
                    nombresArchivos.add(archivo.getName());
                }
            }
            
            requisitoLegal.append("archivosIds", archivosIds);
            requisitoLegal.append("nombresArchivos", nombresArchivos);

            collection.insertOne(requisitoLegal);
            return "Requisito legal guardado exitosamente";
        } catch (Exception e) {
            System.err.println("Error al guardar requisito legal: " + e.getMessage());
            return "Error al guardar requisito legal: " + e.getMessage();
        }
    }

    public List<Document> obtenerTodosLosRequisitosLegales() {
        List<Document> requisitosLegales = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                requisitosLegales.add(cursor.next());
            }
        } catch (Exception e) {
            System.err.println("Error al obtener requisitos legales: " + e.getMessage());
        }
        return requisitosLegales;
    }

    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
