package com.example;

import java.time.LocalDate;
import java.util.List;

import org.bson.Document;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TablaRequisitoLegalView {
    private final Stage parentStage;
    private final RequisitoLegalService requisitoLegalService;
    private TableView<RequisitoLegalTableRow> tableView;
    private ObservableList<RequisitoLegalTableRow> data;

    public TablaRequisitoLegalView(Stage parentStage) {
        this.parentStage = parentStage;
        this.requisitoLegalService = new RequisitoLegalService();
        this.data = FXCollections.observableArrayList();
    }

    public void mostrar() {
        Stage tablaStage = new Stage();
        tablaStage.setTitle("Requisitos Legales");
        tablaStage.setWidth(1000);
        tablaStage.setHeight(600);

        // Crear tabla
        tableView = new TableView<>();
        
        // Columnas de la tabla
        TableColumn<RequisitoLegalTableRow, String> colNombre = new TableColumn<>("Requisito Legal");
        colNombre.setCellValueFactory(cellData -> cellData.getValue().nombreRequisitoLegal);
        colNombre.setPrefWidth(250);

        TableColumn<RequisitoLegalTableRow, String> colFechaEmision = new TableColumn<>("Fecha Emisión");
        colFechaEmision.setCellValueFactory(cellData -> cellData.getValue().fechaEmision);
        colFechaEmision.setPrefWidth(130);

        TableColumn<RequisitoLegalTableRow, String> colFechaVencimiento = new TableColumn<>("Fecha Vencimiento");
        colFechaVencimiento.setCellValueFactory(cellData -> cellData.getValue().fechaVencimiento);
        colFechaVencimiento.setPrefWidth(140);

        TableColumn<RequisitoLegalTableRow, String> colFechaRenovacion = new TableColumn<>("Próxima Renovación");
        colFechaRenovacion.setCellValueFactory(cellData -> cellData.getValue().fechaProximaRenovacion);
        colFechaRenovacion.setPrefWidth(140);

        TableColumn<RequisitoLegalTableRow, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(cellData -> cellData.getValue().estado);
        colEstado.setPrefWidth(120);

        TableColumn<RequisitoLegalTableRow, String> colArchivos = new TableColumn<>("Archivos");
        colArchivos.setCellValueFactory(cellData -> cellData.getValue().cantidadArchivos);
        colArchivos.setPrefWidth(80);

        tableView.getColumns().addAll(colNombre, colFechaEmision, colFechaVencimiento, 
                                      colFechaRenovacion, colEstado, colArchivos);
        
        tableView.setItems(data);

        // Botones
        Button btnNuevoRequisito = new Button("Nuevo Requisito Legal");
        btnNuevoRequisito.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 6; -fx-padding: 8 16 8 16;");
        btnNuevoRequisito.setOnAction(e -> {
            new RegistroRequisitoLegalDialog(tablaStage).mostrar();
            cargarDatos(); // Recargar datos después de registrar
        });

        Button btnActualizar = new Button("Actualizar");
        btnActualizar.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 6; -fx-padding: 8 16 8 16;");
        btnActualizar.setOnAction(e -> cargarDatos());

        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 6; -fx-padding: 8 16 8 16;");
        btnCerrar.setOnAction(e -> tablaStage.close());

        HBox hboxBotones = new HBox(15, btnNuevoRequisito, btnActualizar, btnCerrar);
        hboxBotones.setAlignment(Pos.CENTER);
        hboxBotones.setStyle("-fx-padding: 15px;");

        // Título
        Label titulo = new Label("Gestión de Requisitos Legales");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-padding: 15px;");

        VBox layout = new VBox(10, titulo, tableView, hboxBotones);
        layout.setStyle("-fx-background-color: #ecf0f1;");

        Scene scene = new Scene(layout);
        tablaStage.setScene(scene);
        tablaStage.initOwner(parentStage);

        // Cargar datos iniciales
        cargarDatos();

        tablaStage.show();
    }

    private void cargarDatos() {
        data.clear();
        List<Document> requisitosLegales = requisitoLegalService.obtenerTodosLosRequisitosLegales();
        
        for (Document req : requisitosLegales) {
            String nombre = req.getString("nombreRequisitoLegal");
            String fechaEmision = formatearFecha(req.get("fechaEmision"));
            String fechaVencimiento = formatearFecha(req.get("fechaVencimiento"));
            String fechaRenovacion = formatearFecha(req.get("fechaProximaRenovacion"));
            String estado = calcularEstado(req.get("fechaVencimiento"));
            
            @SuppressWarnings("unchecked")
            List<String> nombresArchivos = req.getList("nombresArchivos", String.class);
            String cantidadArchivos = (nombresArchivos != null) ? String.valueOf(nombresArchivos.size()) : "0";

            data.add(new RequisitoLegalTableRow(nombre, fechaEmision, fechaVencimiento, 
                                              fechaRenovacion, estado, cantidadArchivos));
        }
    }

    private String formatearFecha(Object fecha) {
        if (fecha == null) return "";
        if ("NV".equals(fecha) || "No Vence".equals(fecha)) return "No vence";
        if (fecha instanceof java.sql.Date) {
            return ((java.sql.Date) fecha).toLocalDate().toString();
        }
        return fecha.toString();
    }

    private String calcularEstado(Object fechaVencimiento) {
        if (fechaVencimiento == null || "NV".equals(fechaVencimiento) || "No Vence".equals(fechaVencimiento)) {
            return "Vigente";
        }
        
        if (fechaVencimiento instanceof java.sql.Date) {
            LocalDate fechaVenc = ((java.sql.Date) fechaVencimiento).toLocalDate();
            LocalDate ahora = LocalDate.now();
            
            if (fechaVenc.isBefore(ahora)) {
                return "VENCIDO";
            } else if (fechaVenc.minusDays(30).isBefore(ahora)) {
                return "Por vencer";
            } else {
                return "Vigente";
            }
        }
        
        return "Vigente";
    }

    // Clase interna para representar las filas de la tabla
    public static class RequisitoLegalTableRow {
        private final SimpleStringProperty nombreRequisitoLegal;
        private final SimpleStringProperty fechaEmision;
        private final SimpleStringProperty fechaVencimiento;
        private final SimpleStringProperty fechaProximaRenovacion;
        private final SimpleStringProperty estado;
        private final SimpleStringProperty cantidadArchivos;

        public RequisitoLegalTableRow(String nombreRequisitoLegal, String fechaEmision, String fechaVencimiento,
                                    String fechaProximaRenovacion, String estado, String cantidadArchivos) {
            this.nombreRequisitoLegal = new SimpleStringProperty(nombreRequisitoLegal);
            this.fechaEmision = new SimpleStringProperty(fechaEmision);
            this.fechaVencimiento = new SimpleStringProperty(fechaVencimiento);
            this.fechaProximaRenovacion = new SimpleStringProperty(fechaProximaRenovacion);
            this.estado = new SimpleStringProperty(estado);
            this.cantidadArchivos = new SimpleStringProperty(cantidadArchivos);
        }

        // Getters para JavaFX
        public SimpleStringProperty nombreRequisitoLegalProperty() { return nombreRequisitoLegal; }
        public SimpleStringProperty fechaEmisionProperty() { return fechaEmision; }
        public SimpleStringProperty fechaVencimientoProperty() { return fechaVencimiento; }
        public SimpleStringProperty fechaProximaRenovacionProperty() { return fechaProximaRenovacion; }
        public SimpleStringProperty estadoProperty() { return estado; }
        public SimpleStringProperty cantidadArchivosProperty() { return cantidadArchivos; }
    }
}
