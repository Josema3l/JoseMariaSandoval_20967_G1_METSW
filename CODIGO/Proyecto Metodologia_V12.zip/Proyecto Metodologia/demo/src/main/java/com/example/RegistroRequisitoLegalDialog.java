package com.example;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class RegistroRequisitoLegalDialog {
    private final Stage parentStage;
    private final RequisitoLegalService requisitoLegalService;
    private List<File> archivosSeleccionados;

    public RegistroRequisitoLegalDialog(Stage parentStage) {
        this.parentStage = parentStage;
        this.requisitoLegalService = new RequisitoLegalService();
        this.archivosSeleccionados = new ArrayList<>();
    }

    public void mostrar() {
        Stage registroStage = new Stage();
        registroStage.setWidth(550); 
        registroStage.setHeight(450);
        registroStage.setTitle("Registrar Requisito Legal");

        TextField txtNombreRequisitoLegal = new TextField();
        txtNombreRequisitoLegal.setPromptText("Ej: Licencia Ambiental, Permiso Sanitario, etc.");
        txtNombreRequisitoLegal.setPrefWidth(250);

        DatePicker dtpFechaEmision = new DatePicker();
        DatePicker dtpFechaVencimiento = new DatePicker();
        DatePicker dtpFechaProximaRenovacion = new DatePicker();
        CheckBox chkNoVence = new CheckBox("No vence");

        // Manejo de checkbox para deshabilitar fechas
        chkNoVence.setOnAction(e -> {
            if (chkNoVence.isSelected()) {
                dtpFechaVencimiento.setDisable(true);
                dtpFechaVencimiento.setValue(null);
                dtpFechaProximaRenovacion.setDisable(true);
                dtpFechaProximaRenovacion.setValue(null);
            } else {
                dtpFechaVencimiento.setDisable(false);
                dtpFechaProximaRenovacion.setDisable(false);
            }
        });

        // Sección para archivos
        Label lblArchivos = new Label("Documentos adjuntos:");
        ListView<String> listViewArchivos = new ListView<>();
        listViewArchivos.setPrefHeight(100);

        Button btnSeleccionarArchivos = new Button("Seleccionar documentos");
        btnSeleccionarArchivos.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 12px; -fx-background-radius: 6;");
        btnSeleccionarArchivos.setOnAction(e -> seleccionarArchivos(listViewArchivos));

        Button btnEliminarArchivo = new Button("Eliminar seleccionado");
        btnEliminarArchivo.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 12px; -fx-background-radius: 6;");
        btnEliminarArchivo.setOnAction(e -> eliminarArchivoSeleccionado(listViewArchivos));

        HBox hboxArchivos = new HBox(10, btnSeleccionarArchivos, btnEliminarArchivo);
        hboxArchivos.setAlignment(Pos.CENTER_LEFT);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setStyle("-fx-padding: 25px;");

        grid.add(new Label("Nombre del Requisito Legal:"), 0, 0);
        grid.add(txtNombreRequisitoLegal, 1, 0);
        grid.add(new Label("Fecha de emisión:"), 0, 1);
        grid.add(dtpFechaEmision, 1, 1);
        grid.add(new Label("Fecha de vencimiento:"), 0, 2);
        HBox hboxVencimiento = new HBox(10, dtpFechaVencimiento, chkNoVence);
        grid.add(hboxVencimiento, 1, 2);
        grid.add(new Label("Fecha próxima de renovación:"), 0, 3);
        grid.add(dtpFechaProximaRenovacion, 1, 3);
        grid.add(lblArchivos, 0, 4);
        grid.add(listViewArchivos, 1, 4);
        grid.add(hboxArchivos, 1, 5);

        Button btnGuardar = new Button("Guardar Requisito Legal");
        btnGuardar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8; -fx-padding: 10 20 10 20;");
        btnGuardar.setOnAction(e -> {
            String nombreRequisitoLegal = txtNombreRequisitoLegal.getText();
            LocalDate fechaEmision = dtpFechaEmision.getValue();
            LocalDate fechaVencimiento = chkNoVence.isSelected() ? null : dtpFechaVencimiento.getValue();
            LocalDate fechaProximaRenovacion = chkNoVence.isSelected() ? null : dtpFechaProximaRenovacion.getValue();

            if (nombreRequisitoLegal == null || nombreRequisitoLegal.trim().isEmpty()) {
                DialogUtils.mostrarAviso(grid, "Debe ingresar el nombre del requisito legal", false, null);
                return;
            }

            if (fechaEmision == null) {
                DialogUtils.mostrarAviso(grid, "Debe seleccionar la fecha de emisión", false, null);
                return;
            }

            if (!chkNoVence.isSelected() && fechaVencimiento == null) {
                DialogUtils.mostrarAviso(grid, "Debe seleccionar la fecha de vencimiento o marcar 'No vence'", false, null);
                return;
            }

            // Validaciones de fechas
            if (!chkNoVence.isSelected()) {
                // Validar que la fecha de vencimiento no sea anterior a la fecha de emisión
                if (fechaVencimiento != null && fechaVencimiento.isBefore(fechaEmision)) {
                    DialogUtils.mostrarAviso(grid, "La fecha de vencimiento no puede ser anterior a la fecha de emisión", false, null);
                    return;
                }

                // Validar que la fecha de próxima renovación no sea anterior a la fecha de emisión
                if (fechaProximaRenovacion != null && fechaProximaRenovacion.isBefore(fechaEmision)) {
                    DialogUtils.mostrarAviso(grid, "La fecha de próxima renovación no puede ser anterior a la fecha de emisión", false, null);
                    return;
                }

                // Validar que la fecha de próxima renovación esté entre la fecha de emisión y la fecha de vencimiento
                if (fechaProximaRenovacion != null && fechaVencimiento != null) {
                    if (fechaProximaRenovacion.isAfter(fechaVencimiento)) {
                        DialogUtils.mostrarAviso(grid, "La fecha de próxima renovación no puede ser posterior a la fecha de vencimiento", false, null);
                        return;
                    }
                }
            }

            String resultado = requisitoLegalService.guardarRequisitoLegal(
                nombreRequisitoLegal.trim(), 
                fechaEmision, 
                fechaVencimiento, 
                fechaProximaRenovacion, 
                archivosSeleccionados
            );

            boolean exito = resultado.contains("exitosamente");
            DialogUtils.mostrarAviso(grid, resultado, exito, exito ? registroStage::close : null);
        });

        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8; -fx-padding: 10 20 10 20;");
        btnCancelar.setOnAction(e -> registroStage.close());

        HBox hboxBotones = new HBox(15, btnGuardar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        grid.add(hboxBotones, 0, 6, 2, 1);

        Scene scene = new Scene(grid);
        registroStage.setScene(scene);
        registroStage.initOwner(parentStage);
        registroStage.show();
    }

    private void seleccionarArchivos(ListView<String> listViewArchivos) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar documentos del requisito legal");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Documentos PDF", "*.pdf"),
            new FileChooser.ExtensionFilter("Documentos Word", "*.doc", "*.docx"),
            new FileChooser.ExtensionFilter("Hojas de cálculo", "*.xls", "*.xlsx"),
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif"),
            new FileChooser.ExtensionFilter("Todos los archivos", "*.*")
        );

        List<File> archivosSeleccionadosAhora = fileChooser.showOpenMultipleDialog(parentStage);
        if (archivosSeleccionadosAhora != null) {
            for (File archivo : archivosSeleccionadosAhora) {
                if (!archivosSeleccionados.contains(archivo)) {
                    archivosSeleccionados.add(archivo);
                    listViewArchivos.getItems().add(archivo.getName());
                }
            }
        }
    }

    private void eliminarArchivoSeleccionado(ListView<String> listViewArchivos) {
        int indiceSeleccionado = listViewArchivos.getSelectionModel().getSelectedIndex();
        if (indiceSeleccionado >= 0) {
            archivosSeleccionados.remove(indiceSeleccionado);
            listViewArchivos.getItems().remove(indiceSeleccionado);
        } else {
            DialogUtils.mostrarAviso(listViewArchivos, "Seleccione un archivo para eliminar", false, null);
        }
    }
}
