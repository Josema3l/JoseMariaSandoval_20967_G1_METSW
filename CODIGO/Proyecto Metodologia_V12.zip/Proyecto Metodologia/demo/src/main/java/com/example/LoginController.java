package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController {
    private UsuarioService usuarioService = new UsuarioService();
    private int intentos = 0;
    private long tiempoBloqueo = 0; // tiempo en milisegundos

    public void mostrarPantallaLogin(Stage stage) {
        Image logoImg = new Image(getClass().getResourceAsStream("/logo.png"));
        ImageView logoView = new ImageView(logoImg);
        logoView.setFitWidth(120);
        logoView.setPreserveRatio(true);

        Label lblUsuario = new Label("Usuario:");
        TextField txtUsuario = new TextField();
        txtUsuario.setMaxWidth(160);
        Label lblContrasena = new Label("Contraseña:");
        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setMaxWidth(160);
        Button btnLogin = new Button("Iniciar sesión");
        Button btnRecuperar = new Button("Recuperar contraseña");
        btnRecuperar.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-size: 12px; -fx-background-radius: 6; -fx-padding: 6 12 6 12;");
        Label lblMensaje = new Label();
        btnLogin.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage, btnLogin));
        txtContrasena.setOnAction(_ -> verificarLogin(txtUsuario, txtContrasena, lblMensaje, stage, btnLogin));
        btnRecuperar.setOnAction(_ -> mostrarRecuperarContrasena(stage));
        VBox vbox = new VBox(12, logoView, lblUsuario, txtUsuario, lblContrasena, txtContrasena, btnLogin, btnRecuperar, lblMensaje);
        vbox.setAlignment(Pos.CENTER);
        StackPane root = new StackPane(vbox);
        root.setStyle("-fx-background-color: #f0f0f0;");
        Scene scene = new Scene(root, 400, 340);
        stage.setTitle("Login JavaFX");
        stage.setScene(scene);
        stage.setMaximized(false);
        stage.setWidth(400);
        stage.setHeight(500);
        stage.centerOnScreen();
        stage.show();
    }

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error de inicio de sesión");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void verificarLogin(TextField txtUsuario, PasswordField txtContrasena, Label lblMensaje, Stage stage, Button btnLogin) {
        long ahora = System.currentTimeMillis();
        if (ahora < tiempoBloqueo) {
            mostrarError("Demasiados intentos. Intenta de nuevo en 5 minutos.");
            btnLogin.setDisable(true);
            return;
        } else {
            btnLogin.setDisable(false);
        }

        String usuario = txtUsuario.getText();
        String contrasena = txtContrasena.getText();
        if (usuarioService.verificarUsuario(usuario, contrasena)) {
            intentos = 0;
            String rol = usuarioService.getRol(usuario);
            if (rol == null || rol.isEmpty()) {
                mostrarError("El usuario no tiene un rol asignado o no es válido.");
                return;
            }
            
            // Verificar si está usando una contraseña temporal
            if (usuarioService.esContrasenaTemporal(contrasena)) {
                mostrarDialogoCambioContrasenaObligatorio(usuario, stage, rol);
            } else {
                new PanelController(usuarioService).mostrarPantallaPanel(stage, usuario, rol);
            }
        } else {
            intentos++;
            if (intentos >= 3) {
                mostrarError("Demasiados intentos. Intenta de nuevo en 5 minutos.");
                tiempoBloqueo = System.currentTimeMillis() + 5 * 60 * 1000; // 5 minutos
                btnLogin.setDisable(true);
                new Thread(() -> {
                    try {
                        Thread.sleep(5 * 60 * 1000);
                    } catch (InterruptedException e) {
                        // Ignorar
                    }
                    javafx.application.Platform.runLater(() -> {
                        intentos = 0;
                        btnLogin.setDisable(false);
                        lblMensaje.setText("");
                    });
                }).start();
            } else {
                mostrarError("Usuario o contraseña incorrectos. Intento " + intentos + " de 3.");
            }
        }
    }

    private void mostrarRecuperarContrasena(Stage stage) {
        new RecuperarContrasenaDialog(usuarioService, stage).mostrar();
    }

    private void mostrarDialogoCambioContrasenaObligatorio(String usuario, Stage stage, String rol) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Contraseña temporal");
        alert.setHeaderText("Debe cambiar su contraseña");
        alert.setContentText("Está utilizando una contraseña temporal. Por seguridad, debe cambiar su contraseña antes de continuar.");
        
        alert.showAndWait().ifPresent(response -> {
            // Crear diálogo para cambio de contraseña
            Stage cambioStage = new Stage();
            cambioStage.setTitle("Cambiar contraseña");
            VBox formBox = new VBox(15);
            formBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 25 25 20 25; -fx-border-radius: 12; -fx-background-radius: 12;");
            formBox.setAlignment(javafx.geometry.Pos.CENTER);

            Label titulo = new Label("Cambiar contraseña");
            titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

            Label lblNuevaContrasena = new Label("Nueva contraseña:");
            PasswordField txtNuevaContrasena = new PasswordField();
            txtNuevaContrasena.setPrefWidth(200);

            Label lblConfirmarContrasena = new Label("Confirmar contraseña:");
            PasswordField txtConfirmarContrasena = new PasswordField();
            txtConfirmarContrasena.setPrefWidth(200);

            Button btnCambiar = new Button("Cambiar contraseña");
            btnCambiar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 8; -fx-padding: 8 24 8 24;");

            formBox.getChildren().addAll(titulo, lblNuevaContrasena, txtNuevaContrasena, 
                                        lblConfirmarContrasena, txtConfirmarContrasena, btnCambiar);

            btnCambiar.setOnAction(e -> {
                String nuevaContrasena = txtNuevaContrasena.getText();
                String confirmarContrasena = txtConfirmarContrasena.getText();

                if (nuevaContrasena == null || nuevaContrasena.trim().isEmpty() ||
                    confirmarContrasena == null || confirmarContrasena.trim().isEmpty()) {
                    mostrarError("Debe completar todos los campos");
                    return;
                }

                if (!nuevaContrasena.equals(confirmarContrasena)) {
                    mostrarError("Las contraseñas no coinciden");
                    return;
                }

                if (nuevaContrasena.length() < 6) {
                    mostrarError("La contraseña debe tener al menos 6 caracteres");
                    return;
                }

                usuarioService.actualizarContrasena(usuario, nuevaContrasena);
                cambioStage.close();
                new PanelController(usuarioService).mostrarPantallaPanel(stage, usuario, rol);
            });

            javafx.scene.Scene cambioScene = new javafx.scene.Scene(formBox);
            cambioStage.setScene(cambioScene);
            cambioStage.initOwner(stage);
            cambioStage.setOnCloseRequest(event -> {
                event.consume(); // Prevenir cerrar sin cambiar contraseña
                mostrarError("Debe cambiar su contraseña temporal antes de continuar");
            });
            cambioStage.showAndWait();
        });
    }

    public java.util.Map<String, String[]> getUsuarios() {
        return usuarioService.getUsuarios();
    }
}
