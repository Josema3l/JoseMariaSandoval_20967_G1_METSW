package com.example;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class CorreoPersonalizadoDialog {
    public void mostrar(Stage parentStage) {
        Stage correoStage = new Stage();
        correoStage.setTitle("Enviar Correo Personalizado");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setStyle("-fx-padding: 20px;");

        TextField txtPara = new TextField();
        txtPara.setPrefWidth(300);
        TextField txtAsunto = new TextField();
        txtAsunto.setPrefWidth(300);
        TextArea txtMensaje = new TextArea();
        txtMensaje.setPrefWidth(300);
        txtMensaje.setPrefHeight(150);
        txtMensaje.setWrapText(true);
        Label lblEstado = new Label();

        grid.add(new Label("Para:"), 0, 0);
        grid.add(txtPara, 1, 0);
        grid.add(new Label("Asunto:"), 0, 1);
        grid.add(txtAsunto, 1, 1);
        grid.add(new Label("Mensaje:"), 0, 2);
        grid.add(txtMensaje, 1, 2);
        grid.add(lblEstado, 0, 4, 2, 1);

        Button btnEnviar = new Button("Enviar");
        btnEnviar.setOnAction(_ -> {
            String para = txtPara.getText();
            String asunto = txtAsunto.getText();
            String mensaje = txtMensaje.getText();
            // Configura tus credenciales y servidor SMTP aquí
            String username = "santy.rojas.2005.santylol@gmail.com";
            String password = "mtxxorlkbnpwjdkt";
            String host = "smtp.gmail.com";
            String port = "587";
            CorreoPersonalizado correo = new CorreoPersonalizado(username, password, host, port);
            boolean enviado = correo.enviarCorreo(para, asunto, mensaje);
            if (enviado) {
                lblEstado.setText("Correo enviado correctamente.");
            } else {
                lblEstado.setText("Error al enviar el correo.");
            }
        });
        Button btnCancelar = new Button("Cancelar");
        btnCancelar.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 6; -fx-padding: 8 16 8 16;");
        btnCancelar.setOnAction(e -> correoStage.close());
        btnEnviar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 6; -fx-padding: 8 16 8 16;");
        HBox hboxBotones = new HBox(15, btnEnviar, btnCancelar);
        hboxBotones.setAlignment(Pos.CENTER);
        grid.add(hboxBotones, 0, 3, 2, 1);

        Scene scene = new Scene(grid, 500, 450);
        correoStage.setScene(scene);
        correoStage.initOwner(parentStage);
        correoStage.show();
    }
}
